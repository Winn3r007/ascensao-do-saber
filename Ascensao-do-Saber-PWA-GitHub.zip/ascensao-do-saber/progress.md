# progress.md

## 2026-11-11 — Etapa 0 e Etapa 1

- Etapa 0 (auditoria/plano) aprovada pelo usuário.
- Etapa 1 implementada: projeto Vite + React 19 + TS strict, ESLint com regras de segurança, Prettier, Vitest, Playwright, CSP/cabeçalhos, documentação.
- Resultados reais: ver `TEST_RESULTS.md`. Problemas pendentes: ver `SECURITY.md` (exceções) e limitações de teste.

## Próximo passo

Etapa 2 — Design system e layout principal (aguardando aprovação do usuário).

## 2026-11-11 — Núcleo de domínio

- Implementados e testados (unitários): máquina de estados do cronômetro (`src/domain/timer`) e regras de XP/nível com ledger idempotente (`src/domain/progression`).
- Ainda não implementado: teto diário de XP, atributos, habilidades por matéria, conquistas, estatísticas, persistência, UI do cronômetro, design system.

## Próximo passo

Etapa 2 (design system e layout) e, em seguida, persistência (IndexedDB) ligada ao cronômetro.

## 2026-11-11 — Persistência

- Implementados: schema IndexedDB v1 (subjects, sessions, xpLedger, activeTimer), validação Zod nas fronteiras, repositórios com transação atômica e idempotência.
- Próximo: design system e layout, depois UI do cronômetro/matérias ligada aos repositórios, dashboard, estatísticas, organização, atributos/conquistas, backup.

## 2026-11-11 — UI base

- Implementados: tokens do design system, layout responsivo com navegação, telas Painel (nível, XP, tempo hoje, últimas sessões), Estudo (iniciar/pausar/retomar/finalizar/cancelar, restaura após reload) e Matérias (criar/excluir). Itens futuros rotulados "em breve".
- Faltam: modo Pomodoro e duração personalizada, assuntos, histórico completo, organização (agenda, calendário, provas, trabalhos, lembretes, metas, revisões, anotações), estatísticas, atributos/habilidades, conquistas, configurações/backup, auditoria de segurança final.

## 2026-11-11 — Módulos restantes

- Todos os módulos do MVP implementados em versão enxuta. Ver ROADMAP.md (lista do que não foi feito) e TEST_RESULTS.md (o que NÃO foi testado).
- Próximos passos sugeridos: auditoria de segurança final (Semgrep, ZAP, revisão de dependências), testes de limites dos formulários, assunto por sessão, notificações, contraste medido, teste em navegador real.

## 2026-11-12 — Fechamento do MVP

- Assunto por sessão, avisos do Pomodoro, testes de limites e contraste, auditoria (Semgrep, segredos). BLOCKED: audit signatures e ZAP.
- MVP considerado concluído na versão enxuta; pendências em ROADMAP.md e TEST_RESULTS.md.

## Próximo passo

Testar em navegador real no seu computador (`npm ci && npm run dev`), depois decidir a fase 2 (talentos/classes, missões) ou melhorias de design.

## 2026-11-12 — Reformulação visual + funcionalidades novas

- Concluídas e testadas: ver TEST_RESULTS.md. Próximo: testar no navegador e no Windows reais; avaliar mais retratos e composições por aba.
