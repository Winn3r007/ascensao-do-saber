# ARCHITECTURE.md

## Camadas

```
ui (React) → application (casos de uso) → domain (regras puras)
infrastructure (IndexedDB, backup) implementa interfaces definidas pelo domínio
validation (Zod) nas fronteiras
```

Estrutura de pastas: `src/{domain,application,infrastructure,validation,ui}`, `tests/{unit,integration,e2e,security}`.
Em 2026-11-11 (Etapa 1) só `src/ui` tem código (placeholder); as demais pastas estão vazias de propósito.

## Decisões técnicas e dependências (versões exatas)

| Pacote                                                                        | Versão                                      | Motivo                                                                       |
| ----------------------------------------------------------------------------- | ------------------------------------------- | ---------------------------------------------------------------------------- |
| react, react-dom                                                              | 19.1.10                                     | UI                                                                           |
| idb                                                                           | 8.0.4                                       | wrapper pequeno do IndexedDB                                                 |
| zod                                                                           | 4.6.7                                       | validação nas fronteiras                                                     |
| vite / @vitejs/plugin-react                                                   | 8.3.5 / 6.1.2                               | build e dev server                                                           |
| typescript                                                                    | **6.0.3**                                   | `typescript-eslint` 8.72.1 exige TS `<6.1`; TS 7.0.x não é suportado por ele |
| vitest / fake-indexeddb / jsdom                                               | 4.1.12 / 6.2.6 / 30.1.3                     | testes unitários e de integração                                             |
| eslint / typescript-eslint / eslint-plugin-react-hooks / @eslint/js / globals | 10.13.0 / 8.72.1 / 7.1.1 / 10.0.1 / 17.13.0 | análise estática                                                             |
| prettier                                                                      | 3.9.10                                      | formatação                                                                   |
| @playwright/test                                                              | 1.64.1                                      | E2E                                                                          |

Todas as versões escolhidas foram publicadas há ≥ 14 dias na data da instalação (2026-11-11).
Total de 253 pacotes no lockfile; dependências de produção diretas: 4 (react, react-dom, idb, zod).

## Notas de instalação (reais)

- Instalar `vitest` com o npm 10.9.9 falhou com erro interno do arborist (`Cannot read properties of null (reading 'edgesOut')`).
  Contorno: `npm install --legacy-peer-deps vitest@4.1.12`. O lockfile resultante funciona com `npm ci` normal (verificado).
- `overrides.minimatch = 11.0.2` em `package.json`: ver `SECURITY.md` (vulnerabilidade GHSA-g3hv-75wg-m249).

## Cronômetro (a implementar na Etapa 4)

Máquina de estados `idle → running ⇄ paused → completed | cancelled | interrupted`. Tempo derivado de `startedAt` e do
acumulado de pausas (nunca por contagem de ticks). Estado persistido a cada transição.
Limite: depende do relógio do sistema.

## Datas

Timestamps em UTC + fuso IANA. Dia da sessão = dia local do início; estatísticas diárias dividem sessões na meia-noite.
