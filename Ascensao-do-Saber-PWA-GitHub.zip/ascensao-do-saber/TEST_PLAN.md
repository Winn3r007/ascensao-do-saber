# TEST_PLAN.md

Estados: NOT_STARTED, PASS, FAIL, BLOCKED, NOT_APPLICABLE. Cada teste: id, módulo, objetivo, procedimento, esperado, observado, status, evidência (ver `tests.json`).

## Camadas

- Unitários e integração: Vitest (`tests/unit`, `tests/integration`), IndexedDB via fake-indexeddb.
- Segurança do build: `tests/security` (requer `npm run build`).
- E2E: Playwright contra o build de produção (desktop e mobile Pixel 7).
- Estática: `tsc --noEmit`, ESLint (com regras de segurança), Prettier, `npm audit`.

## Por etapa (critérios de aceite resumidos)

| Etapa | Aceite                                                                                                |
| ----- | ----------------------------------------------------------------------------------------------------- |
| 1     | typecheck, lint, format, testes, build, testes de segurança do build, E2E e audit passam              |
| 2     | tokens centralizados, teclado, contraste AA, 4 larguras, prefers-reduced-motion                       |
| 3     | dashboard sem dado fictício; estados vazio/carregando/erro                                            |
| 4     | iniciar/pausar/retomar/finalizar/cancelar, reload no meio, aba em segundo plano, sem duplicação       |
| 5     | CRUD de matérias; estatísticas corretas após editar/excluir                                           |
| 6     | schema versionado, migração, dado corrompido tratado                                                  |
| 7     | CRUD de agenda/calendário/provas/trabalhos/lembretes/metas/revisões/anotações com validação e limites |
| 8     | dias sem estudo, meia-noite, fusos, sequências                                                        |
| 9     | idempotência, cancelada = 0 XP, passagem de nível, extremos                                           |
| 10    | conquistas só com condição real, sem duplicar                                                         |
| 11    | exportar/importar, rejeitar inválido/grande/adulterado, versão antiga, exclusão confirmada            |
| 12    | fluxo E2E completo                                                                                    |
| 13    | XSS, backup malicioso, audit, análise estática, segredos                                              |
| 14    | documentação e riscos residuais                                                                       |

Regra adicional: após cada alteração relevante, rodar o teste específico; ao fim da sessão, `check`, build, segurança, E2E e audit.
