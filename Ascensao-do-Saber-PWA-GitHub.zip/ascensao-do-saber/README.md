# Ascensão do Saber

> "Cada conhecimento adquirido é um poder desbloqueado. Cada objetivo alcançado constrói sua lenda."

Aplicação web **local** que transforma estudo real em evolução de personagem:
Estudar → Ganhar XP → Habilidades → Atributos → Talentos → Classes → Medalhas.

**Estado atual: MVP funcional em versão enxuta** (ver `ROADMAP.md` e `TEST_RESULTS.md`).
Veja `progress.md` e `ROADMAP.md`.

## Requisitos

- Node.js 20.19 ou superior (testado com Node 22) e npm.
- Nenhum serviço externo, conta ou hospedagem.

## Instalação e execução

```bash
npm ci            # instala exatamente as versões do package-lock.json
npm run dev       # servidor de desenvolvimento em http://127.0.0.1:5173
npm run build     # verificação de tipos + build de produção em dist/
npm run preview   # serve o build em http://127.0.0.1:4173 (com CSP estrita)
```

## Verificações

```bash
npm run check          # typecheck + lint + format:check + testes unitários/integração
npm run build && npm run test:security   # testes de segurança do build
npx playwright install chromium          # uma vez, para os testes E2E
npm run test:e2e       # E2E contra o build de produção
npm audit              # auditoria de dependências
```

Se o Playwright não encontrar o navegador, defina `PW_CHROMIUM_PATH` com o caminho de um Chromium/Chrome instalado.

## Aviso sobre dados

Os dados ficam no IndexedDB do seu navegador, **sem criptografia**. Quem tem acesso ao seu perfil do navegador
pode ler e editar esses dados. Veja `SECURITY.md`.

## Documentação

`CLAUDE.md` (regras do projeto) · `ARCHITECTURE.md` · `SECURITY.md` · `TEST_PLAN.md` · `TEST_RESULTS.md` · `ROADMAP.md` · `progress.md` · `tests.json`

## Publicar no Android como aplicativo (PWA)

O projeto inclui manifest, ícones, service worker e workflow de deploy para GitHub Pages.

1. Envie o conteúdo desta pasta para um repositório GitHub (branch `main` ou `master`).
2. Em **Settings → Pages**, selecione **GitHub Actions** como origem de publicação.
3. Aguarde o workflow **Deploy PWA to GitHub Pages** concluir em **Actions**.
4. Abra o endereço publicado no Chrome do Android, toque no menu ⋮ e escolha **Instalar app** ou **Adicionar à tela inicial**.

O build usa caminhos relativos para funcionar em repositórios de projeto do GitHub Pages. O service worker mantém recursos já visitados em cache; a primeira abertura exige internet. Os dados do app permanecem no armazenamento local do navegador deste dispositivo.
