# Ascensão do Saber

> "Cada conhecimento adquirido é um poder desbloqueado. Cada objetivo alcançado constrói sua lenda."

Aplicação web **local** que transforma estudo real em evolução de personagem:
Estudar → Ganhar XP → Habilidades → Atributos → Talentos → Classes → Medalhas.

**Estado atual: MVP funcional em versão enxuta** (ver `ROADMAP.md` e `TEST_RESULTS.md`).
Veja `progress.md` e `ROADMAP.md`.

## Requisitos

- Node.js 20.19 ou superior (testado com Node 22) e npm.
- Nenhum serviço externo, conta ou hospedagem.

## Instalação e execução

```bash
npm ci            # instala exatamente as versões do package-lock.json
npm run dev       # servidor de desenvolvimento em http://127.0.0.1:5173
npm run build     # verificação de tipos + build de produção em dist/
npm run preview   # serve o build em http://127.0.0.1:4173 (com CSP estrita)
```

## Verificações

```bash
npm run check          # typecheck + lint + format:check + testes unitários/integração
npm run build && npm run test:security   # testes de segurança do build
npx playwright install chromium          # uma vez, para os testes E2E
npm run test:e2e       # E2E contra o build de produção
npm audit              # auditoria de dependências
```

Se o Playwright não encontrar o navegador, defina `PW_CHROMIUM_PATH` com o caminho de um Chromium/Chrome instalado.

## Aviso sobre dados

Os dados ficam no IndexedDB do seu navegador, **sem criptografia**. Quem tem acesso ao seu perfil do navegador
pode ler e editar esses dados. Veja `SECURITY.md`.

## Documentação

`CLAUDE.md` (regras do projeto) · `ARCHITECTURE.md` · `SECURITY.md` · `TEST_PLAN.md` · `TEST_RESULTS.md` · `ROADMAP.md` · `progress.md` · `tests.json`

## Windows: versão portátil (duplo clique)

O pacote `Ascensao-do-Saber-Portatil.zip` traz o app já compilado. Instale o Node.js LTS (https://nodejs.org) uma vez e dê dois cliques em
`Iniciar Ascensao do Saber.bat`; o navegador abre em http://127.0.0.1:4173. Não é um `.exe` (não há como compilar um aqui); veja `LEIA-ME.txt`.
O código-fonte do pacote está em `launcher/`.


## Publicação no GitHub Pages e instalação no celular

O build usa o caminho-base `/ascensao-do-saber/`, preservando o endereço do projeto. O manifesto e o service worker habilitam instalação como PWA e cache offline básico após a primeira abertura com internet.

Para publicar pelo fluxo existente do repositório, compacte a pasta do projeto no arquivo `Ascensao-do-Saber-PWA-GitHub.zip` na raiz do repositório. O workflow `.github/workflows/deploy.yml` extrai o ZIP, executa `npm ci` e `npm run build` e publica `dist/`.

Endereço: https://winn3r007.github.io/ascensao-do-saber/
