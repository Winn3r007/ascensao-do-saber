// Servidor local mínimo do Ascensão do Saber (somente módulos nativos do Node, sem dependências).
// Serve apenas a pasta ./app, em 127.0.0.1 (acessível só neste computador), com cabeçalhos de segurança.
import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { exec } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), 'app');
const HOST = '127.0.0.1';
const PORT = Number(process.env.PORT ?? 4173); // porta fixa: os dados do navegador ficam atrelados a ela
const URL_APP = `http://${HOST}:${String(PORT)}/`;
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.ico': 'image/x-icon',
};
const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self'",
  "img-src 'self' data: blob:",
  "font-src 'self'",
  "connect-src 'self'",
  "object-src 'none'",
  "base-uri 'none'",
  "form-action 'self'",
  "frame-ancestors 'none'",
].join('; ');
const SEC = {
  'Content-Security-Policy': CSP,
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
};

function send(res, code, body, type = 'text/plain; charset=utf-8', extra = {}) {
  res.writeHead(code, { ...SEC, 'Content-Type': type, ...extra });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD')
    return send(res, 405, 'Método não permitido', undefined, { Allow: 'GET, HEAD' });
  let rel;
  try {
    rel = decodeURIComponent(new URL(req.url ?? '/', URL_APP).pathname);
  } catch {
    return send(res, 400, 'Requisição inválida');
  }
  if (rel.includes('\0')) return send(res, 400, 'Requisição inválida');
  const file = path.normalize(path.join(ROOT, rel === '/' ? 'index.html' : rel));
  if (file !== ROOT && !file.startsWith(ROOT + path.sep)) return send(res, 403, 'Acesso negado'); // bloqueia ../
  try {
    if (!(await stat(file)).isFile()) return send(res, 404, 'Não encontrado');
    const data = await readFile(file);
    const ext = path.extname(file).toLowerCase();
    const cache = ext === '.html' ? 'no-cache' : 'public, max-age=31536000, immutable';
    res.writeHead(200, {
      ...SEC,
      'Content-Type': MIME[ext] ?? 'application/octet-stream',
      'Cache-Control': cache,
    });
    res.end(req.method === 'HEAD' ? undefined : data);
  } catch {
    send(res, 404, 'Não encontrado');
  }
});

const open = () => {
  if (process.platform === 'win32') exec(`start "" "${URL_APP}"`);
  else if (process.env.OPEN_BROWSER) exec(`xdg-open "${URL_APP}"`);
};
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.log(`O app já parece estar aberto em ${URL_APP}. Abrindo o navegador...`);
    open();
    return;
  }
  console.error('Não foi possível iniciar o servidor:', e.message);
  process.exit(1);
});
server.listen(PORT, HOST, () => {
  console.log(`Ascensão do Saber rodando em ${URL_APP}\nFeche esta janela para encerrar.`);
  open();
});
