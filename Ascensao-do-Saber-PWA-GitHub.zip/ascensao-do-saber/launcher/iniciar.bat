@echo off
chcp 65001 >nul
title Ascensao do Saber
cd /d "%~dp0"
set NODE_EXE=node
if exist "runtime\node.exe" set NODE_EXE=runtime\node.exe
%NODE_EXE% --version >nul 2>nul
if errorlevel 1 (
  echo.
  echo O Node.js nao foi encontrado neste computador.
  echo Instale a versao LTS em https://nodejs.org e abra este arquivo de novo.
  echo.
  start https://nodejs.org/
  pause
  exit /b 1
)
echo Iniciando o Ascensao do Saber...
%NODE_EXE% server.mjs
echo.
echo O app foi encerrado. Pode fechar esta janela.
pause
