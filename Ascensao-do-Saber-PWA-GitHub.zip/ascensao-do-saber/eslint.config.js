import js from '@eslint/js';
import globals from 'globals';
import tseslint from 'typescript-eslint';
import reactHooks from 'eslint-plugin-react-hooks';

export default tseslint.config(
  { ignores: ['dist', 'coverage', 'playwright-report', 'test-results', 'node_modules'] },
  js.configs.recommended,
  ...tseslint.configs.strictTypeChecked,
  {
    languageOptions: {
      globals: { ...globals.browser, ...globals.node },
      parserOptions: { projectService: true, tsconfigRootDir: import.meta.dirname },
    },
    plugins: { 'react-hooks': reactHooks },
    rules: {
      ...reactHooks.configs.recommended.rules,
      // Regras de segurança (ver SECURITY.md)
      'no-eval': 'error',
      'no-implied-eval': 'error',
      'no-new-func': 'error',
      'no-script-url': 'error',
      'no-restricted-properties': [
        'error',
        { property: 'innerHTML', message: 'Proibido: use texto puro (risco de XSS).' },
        { property: 'outerHTML', message: 'Proibido: risco de XSS.' },
        { property: 'insertAdjacentHTML', message: 'Proibido: risco de XSS.' },
        { object: 'document', property: 'write', message: 'Proibido: risco de XSS.' },
      ],
      'no-restricted-globals': [
        'error',
        { name: 'localStorage', message: 'Use IndexedDB (infrastructure/db).' },
        { name: 'sessionStorage', message: 'Use IndexedDB (infrastructure/db).' },
      ],
      'no-restricted-syntax': [
        'error',
        {
          selector: "JSXAttribute[name.name='dangerouslySetInnerHTML']",
          message: 'Proibido: dangerouslySetInnerHTML (risco de XSS).',
        },
      ],
      '@typescript-eslint/no-explicit-any': 'error',
    },
  },
  { files: ['*.js', '*.config.ts', 'launcher/*.mjs'], ...tseslint.configs.disableTypeChecked },
);
