import { defineConfig } from 'vitest/config';

// Testes de segurança que inspecionam o build (requer `npm run build` antes).
export default defineConfig({
  test: { include: ['tests/security/**/*.test.ts'], environment: 'node' },
});
