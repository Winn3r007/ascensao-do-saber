# CLAUDE.md — regras permanentes do projeto Ascensão do Saber

Leia este arquivo, `progress.md` e `tests.json` no início de TODA sessão.

## Escopo

- MVP é web local (React + TypeScript strict + Vite + IndexedDB). Sem backend, sem multiplayer, sem login fictício.
- Funcionalidades da fase 2 (clãs, PvP, talentos, classes, história etc.) NÃO são implementadas; só roadmap.
- Nunca criar botões ou telas que finjam funcionalidades inexistentes. Itens futuros devem estar rotulados como "em breve".

## Regras inegociáveis

1. Segurança é requisito de arquitetura. Nunca desabilitar proteções (CSP, regras de lint de segurança) para facilitar.
2. Testar CADA alteração imediatamente (botão → testar; formulário → válido/inválido/limites; função → unitário;
   integração → teste de integração; mudou XP → rodar testes de progressão; mudou persistência → CRUD;
   mudou segurança → testes de segurança).
3. Não avançar de etapa com falha crítica ou teste obrigatório reprovado.
4. Nunca inventar resultado de teste. Nunca marcar PASS sem executar. Nunca remover/enfraquecer teste para passar.
5. Dados falsos nunca são apresentados como reais. Sem seeds de demonstração.
6. Sem comandos destrutivos (`git reset --hard`, force push, exclusões em massa) sem autorização. Sem alterações fora do diretório do projeto.
7. Sem segredos, tokens ou dados pessoais em código/logs. Nunca guardar tokens em localStorage.

## Arquitetura (resumo)

- `ui → application → domain`; `infrastructure` implementa as interfaces do domínio.
- `domain/` é TypeScript puro (sem React, sem IndexedDB).
- Fonte única de verdade: XP e atributos vêm de ledgers imutáveis; totais/níveis são derivados.
- Nenhum componente visual concede XP. Idempotência por `(sessionId, ruleId)`.
- Validação com Zod em toda fronteira (IndexedDB lido, importação, formulários). Texto sempre como texto puro.
- Proibidos (o ESLint bloqueia): innerHTML, dangerouslySetInnerHTML, eval, new Function, localStorage, sessionStorage.

## Antes de encerrar cada sessão

`npm run check` · `npm run build && npm run test:security` · `npm run test:e2e` (se aplicável) · `npm audit`.
Registrar resultados REAIS em `TEST_RESULTS.md` e `tests.json`; atualizar `progress.md`.

## Dependências

Versões exatas (sem ^). Preferir versões publicadas há mais de 14 dias. Avaliar procedência, licença e vulnerabilidades
antes de adicionar. Manter `package-lock.json`. Ver notas de instalação em `ARCHITECTURE.md`.
