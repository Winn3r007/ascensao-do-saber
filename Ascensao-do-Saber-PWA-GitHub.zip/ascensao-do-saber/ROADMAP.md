# ROADMAP.md

## Implementado (testado conforme TEST_RESULTS.md)

Painel; Estudo (livre, Pomodoro, duração personalizada, assunto opcional, registro automático, aviso opt-in); Matérias; Organização (agenda, calendário mensal, provas, trabalhos, lembretes, metas, revisões, anotações em texto);
Estatísticas; Progressão (XP, nível, habilidades por matéria, 4 atributos derivados); Conquistas (6); Configurações (perfil, Pomodoro, exportar/importar, exclusão com confirmação).

## Não implementado do MVP (decisão consciente ou falta de tempo)

- Anexo de imagem em anotações (adiado por risco de segurança).
- Teto diário de XP.
- Sessões "interrompidas" detectadas automaticamente (o estado existe, mas nenhuma tela o gera).
- PWA.

## Fase 2 (somente roadmap; itens "em breve" na interface)

Talentos e classes, clãs, chat, salas, ranking, desafios, PvP, multiplicadores, situações, história (Asterion, Academia, O Vazio, Destino), missões, playlists.

## Inviável na web

Modo Foco com bloqueio de apps; playlists do Spotify (integração externa).
