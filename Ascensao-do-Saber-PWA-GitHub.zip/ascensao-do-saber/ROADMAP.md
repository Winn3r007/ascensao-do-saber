# ROADMAP.md

## Implementado (testado conforme TEST_RESULTS.md)

Painel; Estudo (livre, Pomodoro, duração personalizada, assunto opcional, registro automático, aviso opt-in); Matérias; Organização (agenda, calendário mensal, provas, trabalhos, lembretes, metas, revisões, anotações em texto);
Estatísticas; Progressão (XP, nível, habilidades por matéria, 4 atributos derivados); Conquistas (6); Configurações (perfil, Pomodoro, exportar/importar, exclusão com confirmação).

## Entregue na reformulação visual (2026-11-12)

Navegação em 6 abas; criação e edição de personagem (nome + 4 variações de cor do retrato); excluir sessões; excluir matérias preservando o histórico em "Sessão apagada";
tipos de agenda personalizados e recoloríveis; quadro de post-its; pacote portátil Windows (.bat + servidor local).

## Não implementado do MVP (decisão consciente ou falta de tempo)

- Anexo de imagem em anotações (adiado por risco de segurança).
- Teto diário de XP.
- Sessões "interrompidas" detectadas automaticamente (o estado existe, mas nenhuma tela o gera).
- PWA.

## Fase 2 (somente roadmap; itens "em breve" na interface)

Talentos e classes, clãs, chat, salas, ranking, desafios, PvP, multiplicadores, situações, história (Asterion, Academia, O Vazio, Destino), missões, playlists.

## Inviável na web

Modo Foco com bloqueio de apps; playlists do Spotify (integração externa).

## Pendências da reformulação visual

- Só existe 1 arte de personagem (as "aparências" são variações de cor dela); mais retratos exigem novas ilustrações.
- Telas além do Santuário/Expedição seguem o estilo geral, não uma composição específica de cada referência.
- Executável `.exe` real: não gerado (sem compilador para Windows no ambiente); o `.bat` não foi testado no Windows.
- Itens "em breve" (talentos, classes, clãs, PvP, missões) deixaram de aparecer no menu.
