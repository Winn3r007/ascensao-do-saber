# TEST_RESULTS.md — somente resultados realmente executados

## Etapa 1 — 2026-11-11 (ambiente de nuvem, Node 22, Chrome for Testing 153)

| Verificação                                                                                                           | Resultado                                                                                |
| --------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------- |
| `npm run typecheck` (TS 6.0.3 strict)                                                                                 | PASS                                                                                     |
| `npm run lint`                                                                                                        | PASS                                                                                     |
| `npm run format:check`                                                                                                | PASS                                                                                     |
| `npm test` (Vitest)                                                                                                   | PASS — 2 arquivos, 4 testes                                                              |
| `npm run build`                                                                                                       | PASS (183 kB JS, 58 kB gzip)                                                             |
| `npm run test:security`                                                                                               | PASS — 7 testes                                                                          |
| `npm run test:e2e`                                                                                                    | PASS — 4 testes (2 testes × desktop e mobile)                                            |
| `npm audit`                                                                                                           | PASS — 0 vulnerabilidades                                                                |
| `npm ci` em instalação limpa                                                                                          | PASS                                                                                     |
| Prova negativa do lint (arquivo descartável com innerHTML, eval, new Function, localStorage, dangerouslySetInnerHTML) | PASS — 5/5 padrões bloqueados; arquivo removido; execução MANUAL, ainda não automatizada |

### Falhas encontradas e corrigidas nesta etapa

1. **Instalação do vitest falhou** (erro interno do npm). Contornado com `--legacy-peer-deps`; `npm ci` verificado depois.
2. **`npm audit`: minimatch (moderado)**. Tratado com override (ver SECURITY.md).
3. **E2E T-E2E-001 FAIL (2 vezes)**: não havia o navegador esperado pelo Playwright (revisão 1248; instalada: 1243). Contornado com `PW_CHROMIUM_PATH`.
4. **T-E2E-001 FAIL**: o teste encontrou erros reais de console — `frame-ancestors` dentro de `<meta>` (ignorada pelo navegador) e um 404 de favicon.
   Correção: `frame-ancestors` removida da meta e mantida no cabeçalho (com asserção nova no E2E), favicon adicionado. O teste de segurança foi ajustado
   para exigir a ausência da diretiva na meta; nenhuma verificação foi removida ou enfraquecida.

### Limitações

- Testado só neste ambiente de nuvem; não no seu computador nem em navegadores além do Chromium.
- Os testes cobrem apenas o ferramental e a configuração de segurança; ainda não há regras de negócio para testar.

## Núcleo de domínio (cronômetro, XP, níveis) — 2026-11-11

- `npm test`: 4 arquivos, 22 testes PASS (18 novos: timer 6, progression 12).
- Primeira execução: typecheck OK; lint 1 erro (função de seta retornando void em um teste) — corrigido; testes passaram de primeira.
- Ainda NÃO testado: persistência do cronômetro (reload/fechar aba), integração com IndexedDB, UI. São partes das Etapas 4 e 6.

## Persistência (IndexedDB, repositórios, validação) — 2026-11-11

- `npm test`: 5 arquivos, 35 testes PASS (13 novos em `repository.test.ts`). check, build, segurança (7), E2E (4) e audit também PASS.
- **Falha encontrada e corrigida:** 2 testes de finalização reprovaram na 1ª execução. Causa real: o id do lançamento de XP (`sessão:regra`, 73 caracteres)
  excedia o limite de 64 do schema, então o dado gravado era rejeitado na leitura. Correção: limite do campo ampliado e validação do lançamento ANTES de gravar;
  teste de regressão T-DB-005 adicionado. Nenhum teste foi removido ou enfraquecido.
- Política decidida: matéria com sessões registradas não pode ser excluída (preserva histórico e estatísticas).
- Ainda NÃO testado: migração entre versões do schema (só existe a v1), concorrência entre abas, quota de armazenamento cheia, navegador real (usa fake-indexeddb).

## Design system, layout e telas (Painel, Estudo, Matérias) — 2026-11-11

- Resultados: typecheck, lint, formatação OK; `npm test` 6 arquivos/38 testes PASS; build OK; segurança do build 7 PASS; E2E 22 PASS (desktop + mobile); audit 0.
- Falhas encontradas e corrigidas: (1) erro de tipo em `loadActiveTimer` (retornava `undefined`); (2) o lint do React reprovou `Date.now()` durante a renderização
  (Dashboard e Estudo) e `setState` síncrono em efeito (`useData`) — refatorado, nenhuma regra desligada; (3) 4 testes E2E reprovaram porque o localizador do teste casava com 2 elementos
  (nome e botão "Excluir …"); corrigido o localizador, mantendo a mesma asserção.
- O cronômetro foi testado no E2E com relógio simulado (`page.clock`), não em 6 minutos reais.
- NÃO verificado: contraste calculado (cores escolhidas, sem medição automática), leitor de tela, `prefers-reduced-motion` (regra CSS existe, sem teste), Firefox/Safari, dispositivos reais, avaliação visual por captura de tela.
- Limitação conhecida: a divisão de sessões na meia-noite ainda não existe (dia = dia local do início).

## Módulos restantes (versão enxuta) — 2026-11-11

- Entregues: Organização (agenda, calendário mensal, provas/trabalhos/lembretes, metas, revisões, anotações), Estatísticas, Progressão (habilidades por matéria, atributos), Conquistas, Configurações (perfil, Pomodoro, exportar/importar, exclusão), Estudo com Pomodoro e duração personalizada.
- Resultados: typecheck, lint (0 erros, 0 avisos), formatação OK; Vitest 9 arquivos; build OK; segurança do build 7 PASS; E2E 30 PASS; `npm audit` 0.
- **Bug real encontrado pelo E2E e corrigido:** o `<select>` de estado da revisão lia `e.target.value` dentro da ação assíncrona, depois de o React devolver o campo controlado ao valor antigo; "dominado" nunca era salvo.
- Outras correções: lint de pureza do React (`Date.now()` na renderização), tipo obsoleto, aviso de dependências do efeito.
- Testes novos foram poucos, por decisão do usuário (foco em completar o produto); os testes anteriores foram mantidos integralmente.
- NÃO testado: formulários com todos os limites (só o caminho principal e a validação Zod), calendário com muitos eventos, importação via interface (só a função), Firefox/Safari, dispositivos reais, contraste medido, leitor de tela, Semgrep/OWASP ZAP, concorrência entre abas.

## Fechamento do MVP e auditoria de segurança — 2026-11-12

- Entregue: assunto opcional por sessão, aviso ao concluir (som WebAudio + notificação do navegador, opt-in em Configurações), testes de limites, medição de contraste.
- Resultados finais: Vitest 10 arquivos / 61 testes PASS; segurança do build 7 PASS; E2E 32 PASS (desktop + mobile); typecheck, lint (0 erros/0 avisos), formatação, build OK; `npm audit` 0 vulnerabilidades.
- Contraste: os 11 pares testados atendem WCAG AA (≥ 4.5:1) — cálculo nos tokens reais.
- **Semgrep 1.185.0** (regras do repositório oficial semgrep-rules, usadas localmente porque o registro online não é acessível aqui; não foi usado `--config auto`): 33 arquivos, 100 achados =
  91 INFO "não internacionalizado" (app só em português; não se aplica), 8 INFO "props spreading" (estilo), 1 WARNING `html-in-template-string` em `vite.config.ts:43`
  (monta a meta de CSP com uma constante do próprio arquivo, sem entrada de usuário; **falso positivo triado**, sem supressão no código).
- Varredura de segredos (grep + regras genéricas) e de APIs perigosas no `src`: nada encontrado.
- **BLOCKED:** `npm audit signatures` (erro de rede) e OWASP ZAP (indisponível aqui). Não afirmo nada sobre esses itens.
- Ainda NÃO verificado: Firefox/Safari, dispositivo real, leitor de tela, notificações/som em navegador real (a função existe, mas o E2E não a exercita), concorrência entre abas, quota de armazenamento cheia, fuzzing do importador, avaliação visual por captura de tela.

### Critérios finais de aceite (spec) — situação honesta

| #     | Critério                                                               | Situação                                                                                        |
| ----- | ---------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------- |
| 1     | inicia localmente seguindo o README                                    | PASS (`npm ci`, `build`, `preview` executados; `npm run dev` não foi aberto num navegador real) |
| 2-5   | dashboard real, cronômetro, sessões persistidas, histórico consistente | PASS (E2E com relógio simulado)                                                                 |
| 6-7   | XP e níveis                                                            | PASS (unitários + E2E)                                                                          |
| 8-11  | matérias, estatísticas, metas, conquistas                              | PASS no caminho principal; estatísticas com testes unitários                                    |
| 12    | dados sobrevivem a reinício                                            | PASS (reload no E2E e reabrir banco nos testes; não testado "fechar navegador" real)            |
| 13    | exportar/importar                                                      | PASS na função (T-BKP-001); botão de importar não exercitado no E2E                             |
| 14    | testes obrigatórios passam                                             | PASS neste ambiente (E2E usa `PW_CHROMIUM_PATH`)                                                |
| 15    | auditoria de dependências                                              | PARCIAL: `npm audit` PASS; `audit signatures` BLOCKED                                           |
| 16    | testes de segurança definidos executados                               | PARCIAL: Semgrep, segredos, CSP, XSS armazenado, backup malicioso executados; ZAP BLOCKED       |
| 17    | sem vulnerabilidade crítica/alta conhecida sem tratamento              | nenhuma conhecida; não é garantia de ausência                                                   |
| 18-19 | documentação e riscos residuais                                        | atualizados (este arquivo, SECURITY.md, ROADMAP.md)                                             |
