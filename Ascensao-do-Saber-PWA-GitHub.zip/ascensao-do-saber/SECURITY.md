# SECURITY.md

Referência de verificação: OWASP ASVS 5.0.0, adaptado a um MVP local sem backend. **Isto não é uma declaração de que o sistema é seguro**;
descreve o que foi verificado e o que não foi.

## Limites de confiança

- Sem servidor, quem controla o navegador pode editar o IndexedDB e o relógio do sistema. O MVP impede manipulação acidental ou via
  interface, não adulteração deliberada.
- Os dados locais **não são criptografados**. Não há promessa de criptografia.

## Modelo de ameaças (resumo)

| Ameaça                   | Tratamento                                                                             | Estado                                       |
| ------------------------ | -------------------------------------------------------------------------------------- | -------------------------------------------- |
| XSS / injeção de HTML    | texto puro, ESLint proíbe innerHTML/dangerouslySetInnerHTML/eval/Function, CSP estrita | configurado; testes de XSS reais na Etapa 13 |
| Backup malicioso         | limite de tamanho, Zod estrito, versão de formato                                      | planejado (Etapa 11)                         |
| Manipulação de XP        | ledger imutável, idempotência                                                          | planejado (Etapa 9)                          |
| Corrupção de dados       | validação na leitura, migrações                                                        | planejado (Etapa 6)                          |
| Dependência comprometida | versões exatas, lockfile, npm audit, versões ≥ 14 dias                                 | em vigor                                     |
| Vazamento                | sem rede, sem telemetria, sem segredos                                                 | em vigor                                     |

## Medidas em vigor (Etapa 1)

- CSP no build (meta) e por cabeçalho no preview: sem `unsafe-inline`/`unsafe-eval`; `object-src 'none'`, `base-uri 'none'`; `frame-ancestors 'none'` apenas por cabeçalho.
- Cabeçalhos: `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy: no-referrer`, `Permissions-Policy`, `Cross-Origin-Opener-Policy`.
- Regras ESLint de segurança (testadas com arquivo de prova): ver `CLAUDE.md`.
- `npm audit`: 0 vulnerabilidades (2026-11-11).

## Exceções e riscos conhecidos

1. **CSP do servidor de DESENVOLVIMENTO é mais frouxa** (`'unsafe-inline'` em script/style e `ws://localhost:*`), porque o HMR do Vite e o
   React Refresh precisam. Não vale para build/preview, e os testes E2E rodam contra o preview.
2. **Override do minimatch 11.0.2.** O `npm audit` apontou GHSA-g3hv-75wg-m249 (DoS moderado, `>=7.0.0 <11.0.1`) em `minimatch` 10.2.6,
   usado só pelas ferramentas de lint (eslint e typescript-eslint), nunca no bundle. A correção automática sugerida era rebaixar
   o ESLint para 9.39.5 (breaking). Preferi um `override` para a versão corrigida. Risco: eslint e typescript-eslint declaram `minimatch ^10`; o lint
   e o typecheck passam com a 11, mas a combinação não é a testada pelos mantenedores. Revisar quando houver release que dispense o override.
3. **Licenças**: 253 pacotes; dependências de produção são permissivas. Há MPL-2.0 (lightningcss, ferramenta de build), CC-BY-4.0 (caniuse-lite)
   e CC0 (mdn-data), apenas de build/dados. 23 pacotes são binários nativos opcionais de outras plataformas, não instalados aqui, cuja licença não foi lida.
4. Não foi feita revisão individual de manutenção/reputação de cada pacote transitivo; fica para a Etapa 13 (junto com Semgrep e verificação de proveniência, se disponíveis).
5. Os testes foram executados em ambiente de nuvem, não no navegador do usuário.

## Auditoria (2026-11-12)

- Semgrep 1.185.0 com regras locais de JS/TS/HTML/segredos: 1 achado de segurança (falso positivo triado em `vite.config.ts:43`); detalhes em `TEST_RESULTS.md`.
- `npm audit`: 0 vulnerabilidades. `npm audit signatures`: BLOCKED (rede). OWASP ZAP: BLOCKED (ferramenta indisponível no ambiente de teste).
- Avisos de som/notificação são opt-in e usam apenas APIs do navegador (sem rede). Importação de backup: XP e conquistas são recalculados, nunca lidos do arquivo.
- Riscos residuais: dados locais sem criptografia; manipulação deliberada do IndexedDB/relógio não é impedida; importador sem fuzzing; cadeia de suprimentos sem verificação de proveniência.

## Atualização (2026-11-12): reformulação visual e pacote portátil

- Novas dependências: `@fontsource/eb-garamond`, `@fontsource/inter`, `@fontsource/jetbrains-mono` 5.3.0 (fontes, licença OFL-1.1, arquivos servidos localmente: a CSP continua sem fontes externas). `npm audit`: 0.
- `launcher/server.mjs`: usa apenas módulos nativos do Node; escuta só em 127.0.0.1; aceita só GET/HEAD; bloqueia `..` e bytes nulos; mesmos cabeçalhos/CSP do preview. Testado manualmente (T-SRV-001). Risco residual: qualquer programa deste computador pode acessar a porta 4173; dados do navegador seguem sem criptografia.
- O launcher NÃO baixa nem embute o Node.js (binários não oficiais seriam um risco de cadeia de suprimentos): exige o Node LTS oficial instalado, ou um `runtime\node.exe` oficial colocado pelo usuário.
- Excluir matéria é transacional (sessões, metas, eventos, revisões e notas passam juntos para "Sessão apagada"); excluir sessão remove o XP dela. Importar backup continua recalculando o XP.
