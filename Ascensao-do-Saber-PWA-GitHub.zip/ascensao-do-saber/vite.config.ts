import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import type { Plugin } from 'vite';

// CSP estrita para o build de produção (sem 'unsafe-inline' e sem 'unsafe-eval').
const STRICT_CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self'",
  "img-src 'self' data: blob:",
  "font-src 'self'",
  "connect-src 'self'",
  "object-src 'none'",
  "base-uri 'none'",
  "form-action 'self'",
  "frame-ancestors 'none'",
].join('; ');

// frame-ancestors só funciona por cabeçalho HTTP (é ignorada em <meta>), então fica fora da meta.
const META_CSP = STRICT_CSP.replace("; frame-ancestors 'none'", '');

// Somente o servidor de DESENVOLVIMENTO precisa relaxar script/style/connect (HMR do Vite e
// preâmbulo do React Refresh). Isso é documentado em SECURITY.md e NÃO vale para produção/preview.
const DEV_CSP = STRICT_CSP.replace("script-src 'self'", "script-src 'self' 'unsafe-inline'")
  .replace("style-src 'self'", "style-src 'self' 'unsafe-inline'")
  .replace("connect-src 'self'", "connect-src 'self' ws://localhost:* ws://127.0.0.1:*");

const baseHeaders = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'X-Frame-Options': 'DENY',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
};

// Embute a CSP como <meta> apenas no HTML gerado pelo build (cobre quem abrir sem servidor de headers).
const cspMeta = (): Plugin => ({
  name: 'ascensao-csp-meta',
  transformIndexHtml: {
    order: 'post',
    handler(html, ctx) {
      if (ctx.server) return html;
      const tag = `<meta http-equiv="Content-Security-Policy" content="${META_CSP}" />`;
      return html.replace('<head>', `<head>\n    ${tag}`);
    },
  },
});

export default defineConfig({
  base: '/ascensao-do-saber/',
  plugins: [react(), cspMeta()],
  build: { assetsInlineLimit: 0, sourcemap: false, target: 'es2022' },
  server: { host: '127.0.0.1', headers: { ...baseHeaders, 'Content-Security-Policy': DEV_CSP } },
  preview: {
    host: '127.0.0.1',
    port: 4173,
    strictPort: true,
    headers: { ...baseHeaders, 'Content-Security-Policy': STRICT_CSP },
  },
  test: {
    include: ['tests/unit/**/*.test.ts', 'tests/integration/**/*.test.ts'],
    environment: 'node',
  },
});
