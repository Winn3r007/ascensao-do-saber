import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';

const dist = join(process.cwd(), 'dist');
const html = readFileSync(join(dist, 'index.html'), 'utf8');

describe('T-SEC-001 build: CSP embutida e estrita', () => {
  const csp = /http-equiv="Content-Security-Policy" content="([^"]+)"/.exec(html)?.[1] ?? '';
  it('existe uma meta CSP no HTML do build', () => {
    expect(csp).not.toBe('');
  });
  it('não permite unsafe-inline nem unsafe-eval', () => {
    expect(csp).not.toContain('unsafe-inline');
    expect(csp).not.toContain('unsafe-eval');
  });
  it('bloqueia objetos e base', () => {
    expect(csp).toContain("object-src 'none'");
    expect(csp).toContain("base-uri 'none'");
  });
  it('não inclui frame-ancestors na meta (só vale por cabeçalho; coberto no E2E)', () => {
    expect(csp).not.toContain('frame-ancestors');
  });
});

describe('T-SEC-002 build: sem scripts inline nem handlers inline no HTML', () => {
  it('nenhum <script> sem src', () => {
    const inline = [...html.matchAll(/<script\b([^>]*)>/g)].filter(
      (m) => !/\bsrc=/.test(m[1] ?? ''),
    );
    expect(inline).toHaveLength(0);
  });
  it('nenhum atributo on*= inline', () => {
    expect(/\son[a-z]+\s*=/i.test(html)).toBe(false);
  });
});

describe('T-SEC-003 build: bundle sem eval/new Function próprios', () => {
  it('assets JS do app não contêm eval( nem new Function(', () => {
    const files = readdirSync(join(dist, 'assets')).filter((f) => f.endsWith('.js'));
    expect(files.length).toBeGreaterThan(0);
    for (const f of files) {
      const code = readFileSync(join(dist, 'assets', f), 'utf8');
      expect(/\beval\s*\(/.test(code), `${f} contém eval(`).toBe(false);
      expect(/new Function\s*\(/.test(code), `${f} contém new Function(`).toBe(false);
    }
  });
});
