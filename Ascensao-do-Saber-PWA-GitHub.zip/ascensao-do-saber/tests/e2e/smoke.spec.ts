import { expect, test } from '@playwright/test';

test('T-E2E-001 app carrega sem erros de console e abre na criação de personagem', async ({
  page,
}) => {
  const errors: string[] = [];
  page.on('console', (m) => {
    if (m.type() === 'error') errors.push(m.text());
  });
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('/');
  await expect(page).toHaveTitle('Ascensão do Saber');
  await expect(page.getByRole('heading', { level: 1, name: 'Crie seu personagem' })).toBeVisible();
  expect(errors).toEqual([]);
});

test('T-E2E-002 servidor envia cabeçalhos de segurança', async ({ request }) => {
  const h = (await request.get('/')).headers();
  expect(h['content-security-policy']).toContain("default-src 'self'");
  expect(h['content-security-policy']).not.toContain('unsafe-inline');
  expect(h['content-security-policy']).toContain("frame-ancestors 'none'");
  expect(h['x-content-type-options']).toBe('nosniff');
  expect(h['x-frame-options']).toBe('DENY');
  expect(h['referrer-policy']).toBe('no-referrer');
});
