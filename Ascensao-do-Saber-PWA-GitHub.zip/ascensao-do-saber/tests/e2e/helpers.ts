import { expect, type Page } from '@playwright/test';

export async function createCharacter(page: Page, name = 'Aria') {
  await page.goto('/');
  await page.getByLabel('Nome do personagem').fill(name);
  await page.getByRole('button', { name: 'Entrar no Santuário' }).click();
  await expect(page.getByRole('heading', { level: 1, name })).toBeVisible();
}
export const tab = (page: Page, name: string) =>
  page
    .getByRole('navigation', { name: 'Principal' })
    .getByRole('button', { name, exact: true })
    .click();
export const sub = (page: Page, name: string) =>
  page.getByRole('tab', { name, exact: true }).click();
export async function addSubject(page: Page, name: string) {
  await tab(page, 'Grimório');
  await sub(page, 'Matérias');
  await page.getByLabel('Nome da matéria').fill(name);
  await page.getByRole('button', { name: 'Adicionar matéria' }).click();
  await expect(page.getByRole('listitem').filter({ hasText: name })).toBeVisible();
}
export async function studyMinutes(page: Page, clock: string, finish = true) {
  await tab(page, 'Expedição');
  await page.getByRole('button', { name: 'Iniciar sessão' }).click();
  await page.clock.fastForward(clock);
  await page.getByRole('button', { name: finish ? 'Finalizar sessão' : 'Cancelar sessão' }).click();
  await expect(page.getByRole('button', { name: 'Iniciar sessão' })).toBeVisible();
}
