import { expect, test } from '@playwright/test';

test('T-E2E-020 todas as páginas abrem sem erro de console', async ({ page }) => {
  const errors: string[] = [];
  page.on('console', (m) => {
    if (m.type() === 'error') errors.push(m.text());
  });
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('/');
  for (const nome of [
    'Estudo',
    'Matérias',
    'Organização',
    'Estatísticas',
    'Progressão',
    'Conquistas',
    'Configurações',
    'Painel',
  ]) {
    await page.getByRole('button', { name: nome, exact: true }).click();
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  }
  expect(errors).toEqual([]);
});

test('T-E2E-021 meta, revisão dominada e conquista', async ({ page }) => {
  await page.clock.install({ time: new Date('2026-01-10T12:00:00') });
  await page.goto('/');
  await page.getByRole('button', { name: 'Organização', exact: true }).click();
  await page.getByRole('tab', { name: 'Revisões' }).click();
  await page.getByLabel('Assunto a revisar').fill('Equações');
  await page.getByRole('button', { name: 'Adicionar revisão' }).click();
  await page.getByLabel('Estado de Equações').selectOption('dominado');
  await page.getByRole('button', { name: 'Conquistas', exact: true }).click();
  await expect(page.getByRole('listitem').filter({ hasText: 'Assunto dominado' })).toContainText(
    'Desbloqueada',
  );
  await expect(page.getByRole('listitem').filter({ hasText: 'Primeira sessão' })).toContainText(
    'Bloqueada',
  );
});

test('T-E2E-022 configurações: nome do personagem aparece no painel; exclusão exige confirmação', async ({
  page,
}) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Configurações', exact: true }).click();
  await page.getByLabel('Nome do personagem').fill('Aria');
  await page.getByRole('button', { name: 'Salvar configurações' }).click();
  await page.getByRole('button', { name: 'Painel', exact: true }).click();
  await expect(page.getByRole('heading', { name: /Aria, nível 1/ })).toBeVisible();
  await page.getByRole('button', { name: 'Configurações', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Excluir tudo' })).toBeDisabled();
  await page.getByLabel('Confirmação').fill('EXCLUIR');
  await page.getByRole('button', { name: 'Excluir tudo' }).click();
  await page.getByRole('button', { name: 'Painel', exact: true }).click();
  await expect(page.getByRole('heading', { name: /Aprendiz, nível 1/ })).toBeVisible();
});

test('T-E2E-023 Pomodoro encerra e registra sozinho ao atingir a duração', async ({ page }) => {
  await page.clock.install({ time: new Date('2026-01-10T12:00:00') });
  await page.goto('/');
  await page.getByRole('button', { name: 'Matérias', exact: true }).click();
  await page.getByLabel('Nome da matéria').fill('Português');
  await page.getByRole('button', { name: 'Adicionar matéria' }).click();
  await page.getByRole('button', { name: 'Estudo', exact: true }).click();
  await page.getByLabel('Modo').selectOption('pomodoro');
  await page.getByRole('button', { name: 'Iniciar sessão' }).click();
  await page.clock.fastForward('26:00');
  await expect(page.getByRole('button', { name: 'Iniciar sessão' })).toBeVisible();
  await page.getByRole('button', { name: 'Painel', exact: true }).click();
  await expect(page.getByText('25 min, concluída')).toBeVisible();
  await expect(page.getByText('25 / 60 XP')).toBeVisible();
});

test('T-E2E-024 assunto da sessão é salvo e aparece no painel', async ({ page }) => {
  await page.clock.install({ time: new Date('2026-01-10T12:00:00') });
  await page.goto('/');
  await page.getByRole('button', { name: 'Matérias', exact: true }).click();
  await page.getByLabel('Nome da matéria').fill('Cálculo');
  await page.getByRole('button', { name: 'Adicionar matéria' }).click();
  await page.getByRole('button', { name: 'Estudo', exact: true }).click();
  await page.getByLabel('Assunto (opcional)').fill('Limites');
  await page.getByRole('button', { name: 'Iniciar sessão' }).click();
  await page.clock.fastForward('06:00');
  await page.getByRole('button', { name: 'Finalizar sessão' }).click();
  await page.getByRole('button', { name: 'Painel', exact: true }).click();
  await expect(page.getByText('Cálculo · Limites')).toBeVisible();
});
