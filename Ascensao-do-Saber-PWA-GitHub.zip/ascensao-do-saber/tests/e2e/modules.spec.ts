import { expect, test } from '@playwright/test';
import { addSubject, createCharacter, sub, tab } from './helpers';

test('T-E2E-020 todas as abas e seções abrem sem erro de console', async ({ page }) => {
  const errors: string[] = [];
  page.on('console', (m) => {
    if (m.type() === 'error') errors.push(m.text());
  });
  page.on('pageerror', (e) => errors.push(e.message));
  await createCharacter(page);
  for (const nome of [
    'Expedição',
    'Grimório',
    'Diário',
    'Conquistas',
    'Configurações',
    'Santuário',
  ]) {
    await tab(page, nome);
    await expect(page.getByRole('heading', { level: 1 }).first()).toBeVisible();
  }
  await tab(page, 'Grimório');
  for (const s of ['Habilidades', 'Estatísticas', 'Matérias']) await sub(page, s);
  await tab(page, 'Diário');
  for (const s of ['Agenda', 'Calendário', 'Metas', 'Revisões', 'Quadro', 'Histórico'])
    await sub(page, s);
  expect(errors).toEqual([]);
});

test('T-E2E-021 revisão dominada desbloqueia conquista', async ({ page }) => {
  await createCharacter(page);
  await tab(page, 'Diário');
  await sub(page, 'Revisões');
  await page.getByLabel('Assunto a revisar').fill('Equações');
  await page.getByRole('button', { name: 'Adicionar revisão' }).click();
  await page.getByLabel('Estado de Equações').selectOption('dominado');
  await tab(page, 'Conquistas');
  await expect(page.getByRole('listitem').filter({ hasText: 'Assunto dominado' })).toContainText(
    'Desbloqueada',
  );
  await expect(page.getByRole('listitem').filter({ hasText: 'Primeira sessão' })).toContainText(
    'Bloqueada',
  );
});

test('T-E2E-022 excluir tudo exige confirmação e volta à criação de personagem', async ({
  page,
}) => {
  await createCharacter(page, 'Aria');
  await tab(page, 'Configurações');
  await expect(page.getByRole('button', { name: 'Excluir tudo' })).toBeDisabled();
  await page.getByLabel('Confirmação').fill('EXCLUIR');
  await page.getByRole('button', { name: 'Excluir tudo' }).click();
  await expect(page.getByRole('heading', { level: 1, name: 'Crie seu personagem' })).toBeVisible();
});

test('T-E2E-023 Pomodoro registra sozinho ao atingir a duração', async ({ page }) => {
  await page.clock.install({ time: new Date('2026-01-10T12:00:00') });
  await createCharacter(page);
  await addSubject(page, 'Português');
  await tab(page, 'Expedição');
  await page.getByLabel('Modo').selectOption('pomodoro');
  await page.getByRole('button', { name: 'Iniciar sessão' }).click();
  await expect(page.getByRole('button', { name: 'Pausar' })).toBeVisible(); // sessão já está rodando
  await page.clock.fastForward('26:00');
  await expect(page.getByRole('button', { name: 'Iniciar sessão' })).toBeVisible();
  await tab(page, 'Santuário');
  await expect(page.getByText('25 min, concluída')).toBeVisible();
  await expect(page.getByText('25 / 60 XP')).toBeVisible();
});

test('T-E2E-024 assunto da sessão é salvo e exibido', async ({ page }) => {
  await page.clock.install({ time: new Date('2026-01-10T12:00:00') });
  await createCharacter(page);
  await addSubject(page, 'Cálculo');
  await tab(page, 'Expedição');
  await page.getByLabel('Assunto (opcional)').fill('Limites');
  await page.getByRole('button', { name: 'Iniciar sessão' }).click();
  await page.clock.fastForward('06:00');
  await page.getByRole('button', { name: 'Finalizar sessão' }).click();
  await tab(page, 'Santuário');
  await expect(page.getByText('Cálculo · Limites')).toBeVisible();
});
