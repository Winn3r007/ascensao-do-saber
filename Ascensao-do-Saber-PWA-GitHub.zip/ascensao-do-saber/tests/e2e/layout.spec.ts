import { expect, test } from '@playwright/test';
import { createCharacter, sub, tab } from './helpers';

for (const width of [360, 768, 1280]) {
  test(`T-UI-001 sem rolagem horizontal em ${String(width)}px (todas as abas e seções)`, async ({
    page,
  }) => {
    await page.setViewportSize({ width, height: 800 });
    await createCharacter(page);
    const check = async (label: string) => {
      const o = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
      expect(o, `${label} em ${String(width)}px`).toBeLessThanOrEqual(0);
    };
    await check('Criação/Santuário');
    for (const nome of ['Expedição', 'Grimório', 'Diário', 'Conquistas', 'Configurações']) {
      await tab(page, nome);
      await check(nome);
    }
    await tab(page, 'Diário');
    for (const s of ['Agenda', 'Calendário', 'Metas', 'Revisões', 'Quadro']) {
      await sub(page, s);
      await check(`Diário/${s}`);
    }
  });
}

test('T-UI-002 navegação por teclado mostra foco visível', async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 800 });
  await createCharacter(page);
  await page.keyboard.press('Tab');
  const outline = await page.evaluate(
    () => getComputedStyle(document.activeElement as Element).outlineStyle,
  );
  expect(outline).not.toBe('none');
});
