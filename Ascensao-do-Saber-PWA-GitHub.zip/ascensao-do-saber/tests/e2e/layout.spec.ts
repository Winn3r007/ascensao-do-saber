import { expect, test } from '@playwright/test';

for (const width of [360, 768, 1280]) {
  test(`T-UI-001 sem rolagem horizontal em ${String(width)}px (todas as páginas)`, async ({
    page,
  }) => {
    await page.setViewportSize({ width, height: 800 });
    await page.goto('/');
    for (const nome of ['Painel', 'Estudo', 'Matérias']) {
      await page.getByRole('button', { name: nome, exact: true }).click();
      const overflow = await page.evaluate(
        () => document.documentElement.scrollWidth - window.innerWidth,
      );
      expect(overflow, `${nome} em ${String(width)}px`).toBeLessThanOrEqual(0);
    }
  });
}

test('T-UI-002 navegação por teclado mostra foco visível', async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto('/');
  await page.keyboard.press('Tab');
  const outline = await page.evaluate(
    () => getComputedStyle(document.activeElement as Element).outlineStyle,
  );
  expect(outline).not.toBe('none');
  await page.keyboard.press('Enter');
  await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
});
