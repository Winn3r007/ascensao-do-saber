import { expect, test } from '@playwright/test';
import { addSubject, createCharacter, studyMinutes, sub, tab } from './helpers';

const T = { time: new Date('2026-01-10T12:00:00') };

test('T-E2E-010 sessão de 6 min concede 6 XP e aparece no Santuário', async ({ page }) => {
  await page.clock.install(T);
  await createCharacter(page);
  await expect(page.getByText('Nenhuma sessão ainda')).toBeVisible();
  await addSubject(page, 'Matemática');
  await studyMinutes(page, '06:00');
  await tab(page, 'Santuário');
  await expect(page.getByText('6 / 60 XP')).toBeVisible();
  await expect(page.getByText('6 min, concluída')).toBeVisible();
});

test('T-E2E-011 sessão cancelada não concede XP', async ({ page }) => {
  await page.clock.install(T);
  await createCharacter(page);
  await addSubject(page, 'Física');
  await studyMinutes(page, '10:00', false);
  await tab(page, 'Santuário');
  await expect(page.getByText('0 / 60 XP')).toBeVisible();
  await expect(page.getByText('cancelada')).toBeVisible();
});

test('T-E2E-012 recarregar no meio da sessão mantém o cronômetro e o personagem', async ({
  page,
}) => {
  await createCharacter(page);
  await addSubject(page, 'Química');
  await tab(page, 'Expedição');
  await page.getByRole('button', { name: 'Iniciar sessão' }).click();
  await page.reload();
  await tab(page, 'Expedição');
  await expect(page.getByRole('button', { name: 'Pausar' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Finalizar sessão' })).toBeVisible();
});

test('T-E2E-013 nome com HTML é texto puro e não executa script', async ({ page }) => {
  await createCharacter(page);
  const payload = '<img src=x onerror="window.__xss=1">';
  await addSubject(page, payload);
  expect(
    await page.evaluate(() => (window as unknown as { __xss?: number }).__xss),
  ).toBeUndefined();
  expect(await page.locator('main img').count()).toBe(0);
});

test('T-E2E-015 personagem persiste, não reaparece a criação e pode ser editado', async ({
  page,
}) => {
  await createCharacter(page, 'Ghis');
  await page.reload();
  await expect(page.getByRole('heading', { level: 1, name: 'Ghis' })).toBeVisible();
  await tab(page, 'Configurações');
  await page.getByLabel('Nome do personagem').fill('Ghis, a Colossal');
  await page.getByLabel('Brasa', { exact: false }).check({ force: true });
  await page.getByRole('button', { name: 'Salvar personagem' }).click();
  await expect(
    page.getByRole('button', { name: 'Abrir configurações do personagem' }),
  ).toContainText('Ghis, a Colossal');
  await page.reload();
  await expect(
    page.getByRole('button', { name: 'Abrir configurações do personagem' }),
  ).toContainText('Ghis, a Colossal');
});

test('T-E2E-016 excluir sessão com confirmação remove também o XP', async ({ page }) => {
  await page.clock.install(T);
  await createCharacter(page);
  await addSubject(page, 'História');
  await studyMinutes(page, '06:00');
  await tab(page, 'Diário');
  await sub(page, 'Histórico');
  await page.getByRole('button', { name: 'Excluir sessão' }).click();
  await page.getByRole('button', { name: 'Cancelar' }).click();
  await expect(page.getByRole('listitem')).toHaveCount(1);
  await page.getByRole('button', { name: 'Excluir sessão' }).click();
  await page.getByRole('button', { name: 'Confirmar exclusão da sessão' }).click();
  await expect(page.getByText('Nenhuma sessão registrada ainda')).toBeVisible();
  await tab(page, 'Santuário');
  await expect(page.getByText('0 / 60 XP')).toBeVisible();
});

test('T-E2E-017 excluir matéria move as sessões para "Sessão apagada" sem perder tempo', async ({
  page,
}) => {
  await page.clock.install(T);
  await createCharacter(page);
  await addSubject(page, 'Matemática');
  await studyMinutes(page, '06:00');
  await tab(page, 'Grimório');
  await page.getByRole('button', { name: 'Excluir Matemática' }).click();
  await page.getByRole('button', { name: 'Confirmar exclusão de Matemática' }).click();
  const item = page.getByRole('listitem').filter({ hasText: 'Sessão apagada' });
  await expect(item).toContainText('6 min');
  await expect(page.getByRole('listitem').filter({ hasText: 'Matemática' })).toHaveCount(0);
  await tab(page, 'Santuário');
  await expect(page.getByText('6 / 60 XP')).toBeVisible();
  await expect(page.getByText('Sessão apagada')).toBeVisible();
});

test('T-E2E-018 tipos de agenda personalizados e cores persistem', async ({ page }) => {
  await createCharacter(page);
  await tab(page, 'Diário');
  await sub(page, 'Agenda');
  await page.getByText('Tipos de atividade e cores').click();
  await page.getByLabel('Novo tipo').fill('Monitoria');
  await page.getByRole('button', { name: 'Criar tipo' }).click();
  await page.getByLabel('Cor do tipo Monitoria').fill('#00ff00');
  await page.getByLabel('Cor do tipo Prova').fill('#123456');
  await page.getByLabel('Título').fill('Aula extra');
  await page
    .locator('select')
    .filter({ has: page.locator('option', { hasText: 'Compromisso' }) })
    .selectOption({ label: 'Monitoria' });
  await page.getByRole('button', { name: 'Adicionar à agenda' }).click();
  await expect(page.getByRole('listitem').filter({ hasText: 'Aula extra' })).toContainText(
    'Monitoria',
  );
  await page.reload();
  await tab(page, 'Diário');
  await sub(page, 'Agenda');
  await page.getByText('Tipos de atividade e cores').click();
  await expect(page.getByLabel('Cor do tipo Monitoria')).toHaveValue('#00ff00');
  await expect(page.getByLabel('Cor do tipo Prova')).toHaveValue('#123456');
  await expect(
    page
      .locator('select')
      .filter({ has: page.locator('option', { hasText: 'Compromisso' }) })
      .locator('option'),
  ).toHaveText(['Compromisso', 'Prova', 'Trabalho', 'Lembrete', 'Monitoria']);
});

test('T-E2E-019 quadro de post-its: criar, escrever, arrastar, persistir e excluir', async ({
  page,
}) => {
  await createCharacter(page);
  await tab(page, 'Diário');
  await sub(page, 'Quadro');
  await page.getByRole('button', { name: 'Novo post-it' }).click();
  await page.getByLabel('Texto do post-it Post-it').fill('Revisar limites');
  await page.getByLabel('Texto do post-it Post-it').blur();
  const head = page.getByRole('button', { name: 'Mover post-it Post-it' });
  const note = page.locator('.postit');
  const before = await note.evaluate((e) => [e.style.left, e.style.top]);
  const box = await head.boundingBox();
  if (!box) throw new Error('post-it sem caixa visível');
  await page.mouse.move(box.x + 30, box.y + 8);
  await page.mouse.down();
  await page.mouse.move(box.x + 230, box.y + 128, { steps: 8 });
  await page.mouse.up();
  await expect
    .poll(async () => note.evaluate((e) => [e.style.left, e.style.top]))
    .not.toEqual(before);
  const after = await note.evaluate((e) => [e.style.left, e.style.top]);
  await page.reload();
  await tab(page, 'Diário');
  await sub(page, 'Quadro');
  expect(await page.locator('.postit').evaluate((e) => [e.style.left, e.style.top])).toEqual(after);
  await expect(page.getByLabel('Texto do post-it Post-it')).toHaveValue('Revisar limites');
  await page.getByRole('button', { name: 'Excluir post-it Post-it' }).click();
  await page.getByRole('button', { name: 'Confirmar exclusão do post-it Post-it' }).click();
  await expect(page.locator('.postit')).toHaveCount(0);
});

test('T-E2E-014 a navegação principal tem exatamente as 6 abas', async ({ page }) => {
  await createCharacter(page);
  const nav = page.getByRole('navigation', { name: 'Principal' }).getByRole('button');
  await expect(nav).toHaveText([
    'Santuário',
    'Expedição',
    'Grimório',
    'Diário',
    'Conquistas',
    'Configurações',
  ]);
});
