import { expect, test } from '@playwright/test';

async function addSubject(page: import('@playwright/test').Page, name: string) {
  await page.getByRole('button', { name: 'Matérias' }).click();
  await page.getByLabel('Nome da matéria').fill(name);
  await page.getByRole('button', { name: 'Adicionar matéria' }).click();
  await expect(page.getByRole('listitem').filter({ hasText: name })).toBeVisible();
}

test('T-E2E-010 estado vazio, depois sessão de 6 min concede 6 XP', async ({ page }) => {
  await page.clock.install({ time: new Date('2026-01-10T12:00:00') });
  await page.goto('/');
  await expect(page.getByText('Nenhuma sessão ainda')).toBeVisible();
  await addSubject(page, 'Matemática');
  await page.getByRole('button', { name: 'Estudo' }).click();
  await page.getByRole('button', { name: 'Iniciar sessão' }).click();
  await page.clock.fastForward('06:00');
  await page.getByRole('button', { name: 'Finalizar sessão' }).click();
  await page.getByRole('button', { name: 'Painel' }).click();
  await expect(page.getByText('6 / 60 XP')).toBeVisible();
  await expect(page.getByText('6 min, concluída')).toBeVisible();
});

test('T-E2E-011 sessão cancelada não concede XP', async ({ page }) => {
  await page.clock.install({ time: new Date('2026-01-10T12:00:00') });
  await page.goto('/');
  await addSubject(page, 'Física');
  await page.getByRole('button', { name: 'Estudo' }).click();
  await page.getByRole('button', { name: 'Iniciar sessão' }).click();
  await page.clock.fastForward('10:00');
  await page.getByRole('button', { name: 'Cancelar sessão' }).click();
  await page.getByRole('button', { name: 'Painel' }).click();
  await expect(page.getByText('0 / 60 XP')).toBeVisible();
  await expect(page.getByText('cancelada')).toBeVisible();
});

test('T-E2E-012 recarregar no meio da sessão mantém o cronômetro', async ({ page }) => {
  await page.goto('/');
  await addSubject(page, 'Química');
  await page.getByRole('button', { name: 'Estudo' }).click();
  await page.getByRole('button', { name: 'Iniciar sessão' }).click();
  await expect(page.getByRole('button', { name: 'Pausar' })).toBeVisible();
  await page.reload();
  await page.getByRole('button', { name: 'Estudo' }).click();
  await expect(page.getByRole('button', { name: 'Pausar' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Finalizar sessão' })).toBeVisible();
});

test('T-E2E-013 nome com HTML é exibido como texto e não executa script', async ({ page }) => {
  await page.goto('/');
  const payload = '<img src=x onerror="window.__xss=1">';
  await addSubject(page, payload);
  await page.getByRole('button', { name: 'Painel' }).click();
  await page.getByRole('button', { name: 'Matérias' }).click();
  await expect(page.getByRole('listitem').filter({ hasText: payload })).toBeVisible();
  expect(
    await page.evaluate(() => (window as unknown as { __xss?: number }).__xss),
  ).toBeUndefined();
  expect(await page.locator('main img').count()).toBe(0);
});

test('T-E2E-014 itens futuros estão rotulados e sem ação', async ({ page }) => {
  await page.goto('/');
  const soon = page.getByRole('button', { name: /PvP/ });
  await expect(soon).toHaveAttribute('aria-disabled', 'true');
  await expect(soon).toContainText('em breve');
});
