import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import {
  eventSchema,
  goalSchema,
  noteSchema,
  profileSchema,
  reviewSchema,
  sessionSchema,
} from '../../src/validation/schemas';

describe('T-VAL-001 limites dos formulários (fronteira Zod)', () => {
  const ev = { id: 'e', kind: 'prova', title: 'T', date: '2026-01-10', done: false };
  it('eventos: título, data, hora, tipo e campo extra', () => {
    expect(eventSchema.safeParse(ev).success).toBe(true);
    for (const bad of [
      { title: '' },
      { title: 'x'.repeat(101) },
      { date: '10/01/2026' },
      { date: '2026-1-1' },
      { time: '9:00' },
      { kind: 'festa' },
      { content: 'x'.repeat(1001) },
      { extra: 1 },
    ])
      expect(eventSchema.safeParse({ ...ev, ...bad }).success, JSON.stringify(bad)).toBe(false);
  });
  it('metas: quantidade zero, negativa, fracionária e gigante', () => {
    const g = {
      id: 'g',
      title: 'm',
      metric: 'minutes',
      target: 60,
      deadline: '2026-02-01',
      createdAt: 1,
    };
    expect(goalSchema.safeParse(g).success).toBe(true);
    for (const t of [0, -1, 1.5, 1_000_001, Number.NaN])
      expect(goalSchema.safeParse({ ...g, target: t }).success).toBe(false);
  });
  it('anotações e revisões: texto longo, cor inválida, estado inválido', () => {
    const n = { id: 'n', title: 'a', text: '', color: '#aabbcc', createdAt: 1 };
    expect(noteSchema.safeParse(n).success).toBe(true);
    expect(noteSchema.safeParse({ ...n, text: 'x'.repeat(5001) }).success).toBe(false);
    expect(noteSchema.safeParse({ ...n, color: 'azul' }).success).toBe(false);
    expect(reviewSchema.safeParse({ id: 'r', topic: 't', state: 'talvez' }).success).toBe(false);
  });
  it('perfil: Pomodoro 0 e 181 rejeitados; nome vazio e longo rejeitados; assunto de sessão limitado', () => {
    const p = { key: 'profile', characterName: 'A', pomodoroMinutes: 25 };
    expect(profileSchema.safeParse(p).success).toBe(true);
    for (const bad of [
      { pomodoroMinutes: 0 },
      { pomodoroMinutes: 181 },
      { characterName: '' },
      { characterName: 'x'.repeat(31) },
    ])
      expect(profileSchema.safeParse({ ...p, ...bad }).success).toBe(false);
    const s = {
      id: 's',
      subjectId: 'a',
      startedAt: 1,
      endedAt: 2,
      activeMs: 1,
      status: 'completed',
    };
    expect(sessionSchema.safeParse({ ...s, topic: 'Limites' }).success).toBe(true);
    expect(sessionSchema.safeParse({ ...s, topic: 'x'.repeat(81) }).success).toBe(false);
  });
});

// Contraste WCAG calculado a partir dos tokens reais do design system.
const css = readFileSync('src/ui/tokens.css', 'utf8');
const token = (n: string): string =>
  /--NAME:\s*(#[0-9a-fA-F]{6})/.exec(css.replace(/--(\S+):/g, (m) => m).replace('NAME', n))?.[1] ??
  new RegExp(`--${n}:\\s*(#[0-9a-fA-F]{6})`).exec(css)?.[1] ??
  '';
const lum = (hex: string): number => {
  const c = [1, 3, 5]
    .map((i) => parseInt(hex.slice(i, i + 2), 16) / 255)
    .map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));
  return 0.2126 * (c[0] ?? 0) + 0.7152 * (c[1] ?? 0) + 0.0722 * (c[2] ?? 0);
};
const ratio = (a: string, b: string): number => {
  const [x, y] = [lum(a), lum(b)].sort((m, n) => n - m);
  return ((x ?? 0) + 0.05) / ((y ?? 0) + 0.05);
};
describe('T-UI-003 contraste WCAG AA (texto normal ≥ 4.5)', () => {
  const pairs: [string, string][] = [
    ['text', 'ink'],
    ['text', 'graphite'],
    ['text', 'graphite-2'],
    ['muted', 'ink'],
    ['muted', 'graphite'],
    ['gold', 'ink'],
    ['gold', 'graphite'],
    ['study', 'graphite'],
    ['danger', 'graphite'],
    ['danger', 'ink'],
  ];
  for (const [fg, bg] of pairs)
    it(`${fg} sobre ${bg}`, () => {
      expect(ratio(token(fg), token(bg))).toBeGreaterThanOrEqual(4.5);
    });
  it('texto do botão primário (#17130a) sobre o dourado', () => {
    expect(ratio('#17130a', token('gold'))).toBeGreaterThanOrEqual(4.5);
  });
});
