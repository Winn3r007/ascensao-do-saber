import { describe, expect, it } from 'vitest';
import { z } from 'zod';

describe('T-ENV-001 ferramental: Vitest + TypeScript strict', () => {
  it('executa um teste tipado', () => {
    const soma = (a: number, b: number): number => a + b;
    expect(soma(2, 3)).toBe(5);
  });
});

describe('T-ENV-002 ferramental: Zod rejeita entrada inválida', () => {
  const schema = z.strictObject({ nome: z.string().min(1).max(40) });
  it('aceita entrada válida', () => {
    expect(schema.safeParse({ nome: 'Aria' }).success).toBe(true);
  });
  it('rejeita campo desconhecido, vazio e tipo errado', () => {
    expect(schema.safeParse({ nome: 'Aria', extra: 1 }).success).toBe(false);
    expect(schema.safeParse({ nome: '' }).success).toBe(false);
    expect(schema.safeParse({ nome: 42 }).success).toBe(false);
  });
});
