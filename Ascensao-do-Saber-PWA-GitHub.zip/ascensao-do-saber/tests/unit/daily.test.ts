import { describe, expect, it } from 'vitest';
import { studiedMsOnDay } from '../../src/domain/stats/daily';

const at = (d: number, h: number) => new Date(2026, 0, d, h, 0, 0).getTime();
describe('T-STA-001 tempo estudado no dia', () => {
  const s = (startedAt: number, activeMs: number, status = 'completed') => ({
    startedAt,
    activeMs,
    status,
  });
  it('soma só sessões concluídas do dia local', () => {
    const list = [
      s(at(10, 8), 600_000),
      s(at(10, 20), 300_000),
      s(at(9, 23), 999),
      s(at(10, 9), 777, 'cancelled'),
    ];
    expect(studiedMsOnDay(list, at(10, 12))).toBe(900_000);
  });
  it('dia sem estudo = 0 e lista vazia = 0', () => {
    expect(studiedMsOnDay([s(at(9, 8), 5)], at(10, 12))).toBe(0);
    expect(studiedMsOnDay([], at(10, 12))).toBe(0);
  });
  it('limites 00:00 e 23:59 pertencem ao próprio dia', () => {
    const start = new Date(2026, 0, 10, 0, 0, 0).getTime();
    const end = new Date(2026, 0, 10, 23, 59, 59).getTime();
    expect(studiedMsOnDay([s(start, 1), s(end, 2)], at(10, 12))).toBe(3);
  });
});
