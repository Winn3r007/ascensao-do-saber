import { describe, expect, it } from 'vitest';
import { evaluateAchievements } from '../../src/domain/achievements/achievements';
import { goalProgress } from '../../src/domain/goals/goals';
import { computeStats, splitByDay, streaks } from '../../src/domain/stats/summary';

const L = (y: number, m: number, d: number, h = 12, mi = 0) =>
  new Date(y, m - 1, d, h, mi).getTime();
describe('T-STA-002 estatísticas', () => {
  it('sessão que atravessa a meia-noite é dividida sem perder tempo', () => {
    const parts = splitByDay(L(2026, 1, 10, 23, 30), L(2026, 1, 11, 0, 30), 3_600_000);
    expect([...parts.values()].reduce((a, b) => a + b, 0)).toBeCloseTo(3_600_000);
    expect(parts.size).toBe(2);
  });
  it('sequência atual e maior; hoje sem estudo não quebra; lacuna quebra', () => {
    expect(streaks(new Set(['2026-01-08', '2026-01-09']), '2026-01-10')).toEqual({
      current: 2,
      longest: 2,
    });
    expect(streaks(new Set(['2026-01-05', '2026-01-08']), '2026-01-10')).toEqual({
      current: 0,
      longest: 1,
    });
    expect(streaks(new Set(), '2026-01-10')).toEqual({ current: 0, longest: 0 });
  });
  it('sem sessões tudo zera; só conta concluídas', () => {
    const z = computeStats([], L(2026, 1, 10));
    expect([z.total, z.today, z.bestHour, z.averagePerStudyDay]).toEqual([0, 0, null, 0]);
    const s = [
      {
        subjectId: 'a',
        startedAt: L(2026, 1, 10, 9),
        endedAt: L(2026, 1, 10, 10),
        activeMs: 600_000,
        status: 'completed',
      },
      {
        subjectId: 'a',
        startedAt: L(2026, 1, 10, 11),
        endedAt: L(2026, 1, 10, 12),
        activeMs: 999,
        status: 'cancelled',
      },
    ];
    const r = computeStats(s, L(2026, 1, 10, 15));
    expect([r.today, r.total, r.bestHour]).toEqual([600_000, 600_000, 9]);
  });
});
describe('T-GOL-001 metas e conquistas', () => {
  const goal = {
    id: 'g',
    title: 't',
    metric: 'minutes' as const,
    target: 60,
    deadline: '2026-01-10',
    createdAt: L(2026, 1, 1),
    subjectId: 'a',
  };
  const sess = (min: number, subjectId = 'a', status = 'completed') => ({
    subjectId,
    startedAt: L(2026, 1, 2),
    endedAt: L(2026, 1, 2),
    activeMs: min * 60_000,
    status,
  });
  it('andamento, concluída, atrasada e filtro de matéria', () => {
    expect(goalProgress(goal, [sess(30), sess(40, 'b')], '2026-01-05')).toEqual({
      value: 30,
      status: 'em_andamento',
    });
    expect(goalProgress(goal, [sess(60)], '2026-01-20').status).toBe('concluida');
    expect(goalProgress(goal, [sess(10)], '2026-01-20').status).toBe('atrasada');
    expect(goalProgress(goal, [sess(60, 'a', 'cancelled')], '2026-01-05').value).toBe(0);
  });
  it('conquistas só com condição satisfeita', () => {
    const base = { completed: [], goalsDone: 0, reviewsMastered: 0, longestStreak: 0 };
    expect(evaluateAchievements(base)).toEqual([]);
    expect(
      evaluateAchievements({
        ...base,
        completed: [{ subjectId: 'a', activeMs: 11 * 3_600_000 }],
        longestStreak: 7,
      }),
    ).toEqual(['first-session', 'streak-7', 'subject-10h']);
  });
});
