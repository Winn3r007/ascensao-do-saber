import { describe, expect, it } from 'vitest';
import {
  grantSessionXp,
  levelFromXp,
  levelProgress,
  levelThreshold,
  totalXp,
  xpForSession,
  type XpEntry,
} from '../../src/domain/progression/rules';

const MIN = 60_000;
const done = (id: string, min: number) => ({
  id,
  status: 'completed' as const,
  activeMs: min * MIN,
});

describe('T-XP-001 XP por sessão', () => {
  it('concede 1 XP/min em sessão concluída', () => {
    expect(xpForSession(done('a', 25))).toBe(25);
  });
  it('não concede XP a sessão cancelada nem interrompida', () => {
    expect(xpForSession({ id: 'a', status: 'cancelled', activeMs: 60 * MIN })).toBe(0);
    expect(xpForSession({ id: 'a', status: 'interrupted', activeMs: 60 * MIN })).toBe(0);
  });
  it('não concede XP abaixo do mínimo (5 min)', () => {
    expect(xpForSession(done('a', 4))).toBe(0);
    expect(xpForSession({ id: 'a', status: 'completed', activeMs: 5 * MIN - 1 })).toBe(0);
    expect(xpForSession(done('a', 5))).toBe(5);
  });
  it('rejeita duração inválida e aceita valor extremo', () => {
    expect(() => xpForSession({ id: 'a', status: 'completed', activeMs: -1 })).toThrow(RangeError);
    expect(() => xpForSession({ id: 'a', status: 'completed', activeMs: Number.NaN })).toThrow();
    expect(xpForSession(done('a', 60 * 24 * 365))).toBe(525_600);
  });
});
describe('T-XP-002 ledger idempotente', () => {
  it('a mesma sessão nunca é premiada duas vezes', () => {
    let l: readonly XpEntry[] = [];
    l = grantSessionXp(l, done('s1', 30));
    l = grantSessionXp(l, done('s1', 30));
    l = grantSessionXp(l, done('s2', 10));
    expect(l).toHaveLength(2);
    expect(totalXp(l)).toBe(40);
  });
  it('sessão cancelada não cria lançamento', () => {
    expect(grantSessionXp([], { id: 'x', status: 'cancelled', activeMs: 99 * MIN })).toEqual([]);
  });
  it('não altera o ledger original', () => {
    const base: readonly XpEntry[] = [];
    grantSessionXp(base, done('s1', 30));
    expect(base).toHaveLength(0);
  });
});
describe('T-LVL-001 níveis', () => {
  it('limiares: 60×(L−1)²', () => {
    expect([1, 2, 3, 10].map(levelThreshold)).toEqual([0, 60, 240, 4860]);
  });
  it('passagem de nível nas fronteiras', () => {
    expect(levelFromXp(0)).toBe(1);
    expect(levelFromXp(59)).toBe(1);
    expect(levelFromXp(60)).toBe(2);
    expect(levelFromXp(239)).toBe(2);
    expect(levelFromXp(240)).toBe(3);
    expect(levelFromXp(4860)).toBe(10);
  });
  it('consistente com o limiar para muitos níveis e valores extremos', () => {
    for (let l = 1; l <= 2000; l++) {
      expect(levelFromXp(levelThreshold(l))).toBe(l);
      expect(levelFromXp(levelThreshold(l + 1) - 1)).toBe(l);
    }
    expect(levelFromXp(Number.MAX_SAFE_INTEGER)).toBeGreaterThan(1000);
  });
  it('progresso dentro do nível', () => {
    expect(levelProgress(90)).toEqual({ level: 2, intoLevel: 30, needed: 180, fraction: 30 / 180 });
  });
  it('rejeita entradas inválidas', () => {
    for (const bad of [-1, Number.NaN, Infinity])
      expect(() => levelFromXp(bad)).toThrow(RangeError);
    for (const bad of [0, 1.5, -2]) expect(() => levelThreshold(bad)).toThrow(RangeError);
  });
});
