import { describe, expect, it } from 'vitest';
import {
  cancelTimer,
  elapsedMs,
  finishTimer,
  pauseTimer,
  resumeTimer,
  startTimer,
} from '../../src/domain/timer/timer';

const T0 = 1_000_000;
describe('T-TMR-001 cronômetro: transições', () => {
  it('inicia, pausa, retoma e finaliza excluindo o tempo pausado', () => {
    let s = startTimer(T0);
    s = pauseTimer(s, T0 + 60_000); // 1 min ativo
    expect(elapsedMs(s, T0 + 999_999)).toBe(60_000); // pausado: não corre
    s = resumeTimer(s, T0 + 600_000);
    const { state, session } = finishTimer(s, T0 + 660_000); // +1 min
    expect(session).toEqual({
      startedAt: T0,
      endedAt: T0 + 660_000,
      activeMs: 120_000,
      outcome: 'completed',
    });
    expect(state).toEqual({ status: 'idle' });
  });
  it('cancelar gera resultado cancelled', () => {
    expect(cancelTimer(startTimer(T0), T0 + 5_000).session.outcome).toBe('cancelled');
  });
});
describe('T-TMR-002 cronômetro: transições inválidas e extremos', () => {
  it('rejeita pausar/retomar/finalizar em estado errado', () => {
    const idle = { status: 'idle' } as const;
    expect(() => pauseTimer(idle, T0)).toThrow();
    expect(() => resumeTimer(startTimer(T0), T0)).toThrow();
    expect(() => finishTimer(idle, T0)).toThrow();
    expect(() => cancelTimer(idle, T0)).toThrow();
    expect(() => pauseTimer(pauseTimer(startTimer(T0), T0 + 1), T0 + 2)).toThrow();
  });
  it('rejeita instantes inválidos', () => {
    expect(() => startTimer(Number.NaN)).toThrow(RangeError);
    expect(() => startTimer(-1)).toThrow(RangeError);
    expect(() => startTimer(Infinity)).toThrow(RangeError);
  });
  it('relógio voltando no tempo nunca dá duração negativa', () => {
    expect(elapsedMs(startTimer(T0), T0 - 5_000)).toBe(0);
  });
  it('aba em segundo plano por horas mantém a precisão (derivado do relógio)', () => {
    const s = startTimer(T0);
    expect(elapsedMs(s, T0 + 3 * 3_600_000 + 123)).toBe(10_800_123);
  });
});
