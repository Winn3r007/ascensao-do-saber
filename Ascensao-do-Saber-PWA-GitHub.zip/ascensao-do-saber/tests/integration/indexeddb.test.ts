import 'fake-indexeddb/auto';
import { openDB } from 'idb';
import { describe, expect, it } from 'vitest';

describe('T-ENV-003 ferramental: IndexedDB (idb + fake-indexeddb)', () => {
  it('grava, lê, atualiza e exclui um registro', async () => {
    const db = await openDB('env-check', 1, {
      upgrade(d) {
        d.createObjectStore('itens', { keyPath: 'id' });
      },
    });
    await db.put('itens', { id: 'a', valor: 1 });
    expect(await db.get('itens', 'a')).toEqual({ id: 'a', valor: 1 });
    await db.put('itens', { id: 'a', valor: 2 });
    expect(await db.get('itens', 'a')).toEqual({ id: 'a', valor: 2 });
    await db.delete('itens', 'a');
    expect(await db.get('itens', 'a')).toBeUndefined();
    db.close();
  });
});
