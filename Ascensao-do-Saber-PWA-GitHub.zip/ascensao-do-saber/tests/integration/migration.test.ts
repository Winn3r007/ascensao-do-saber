import 'fake-indexeddb/auto';
import { openDB } from 'idb';
import { describe, expect, it } from 'vitest';
import { openAppDb } from '../../src/infrastructure/db/db';
import { getProfile, listItems } from '../../src/infrastructure/db/items';
import { listSubjects } from '../../src/infrastructure/db/repository';

describe('T-DB-006 migração v1 → v2 preserva os dados existentes', () => {
  it('mantém matérias da v1 e cria as novas áreas vazias', async () => {
    const v1 = await openDB('migra', 1, {
      upgrade(d) {
        d.createObjectStore('subjects', { keyPath: 'id' });
        d.createObjectStore('sessions', { keyPath: 'id' }).createIndex('bySubject', 'subjectId');
        d.createObjectStore('xpLedger', { keyPath: 'id' });
        d.createObjectStore('activeTimer', { keyPath: 'key' });
      },
    });
    await v1.put('subjects', { id: 'a', name: 'Antiga', color: '#123456', createdAt: 1 });
    v1.close();
    const v2 = await openAppDb('migra');
    expect((await listSubjects(v2)).map((s) => s.name)).toEqual(['Antiga']);
    expect(await listItems(v2, 'goals')).toEqual([]);
    expect((await getProfile(v2)).characterName).toBe('Aprendiz');
    v2.close();
  });
});
