import 'fake-indexeddb/auto';
import { describe, expect, it } from 'vitest';
import { openAppDb } from '../../src/infrastructure/db/db';
import {
  CorruptDataError,
  addSubject,
  deleteSubject,
  finalizeSession,
  listSubjects,
  loadActiveTimer,
  renameSubject,
  saveActiveTimer,
  totalXpStored,
} from '../../src/infrastructure/db/repository';
import {
  cancelTimer,
  elapsedMs,
  finishTimer,
  pauseTimer,
  startTimer,
} from '../../src/domain/timer/timer';

let n = 0;
const fresh = () => openAppDb(`test-db-${String(++n)}`);
const MIN = 60_000;
const T0 = 1_700_000_000_000;

describe('T-DB-001 matérias: CRUD e persistência', () => {
  it('cria, lista, renomeia e sobrevive a fechar/reabrir o banco', async () => {
    const name = `persist-${String(++n)}`;
    let db = await openAppDb(name);
    const m = await addSubject(db, { name: '  Matemática ', color: '#3366ff' });
    expect(m.name).toBe('Matemática');
    await renameSubject(db, m.id, { name: 'Física', color: '#00aa55' });
    db.close();
    db = await openAppDb(name);
    expect((await listSubjects(db)).map((s) => s.name)).toEqual(['Física']);
    await deleteSubject(db, m.id);
    expect(await listSubjects(db)).toEqual([]);
    db.close();
  });
  it('rejeita entradas inválidas', async () => {
    const db = await fresh();
    const bad = [
      { name: '', color: '#000000' },
      { name: '   ', color: '#000000' },
      { name: 'x'.repeat(61), color: '#000000' },
      { name: 'ok', color: 'red' },
      { name: 'ok', color: '#12345' },
    ];
    for (const b of bad) await expect(addSubject(db, b)).rejects.toThrow();
    expect(await listSubjects(db)).toEqual([]);
    db.close();
  });
  it('trata texto malicioso como texto puro (armazenado sem alteração)', async () => {
    const db = await fresh();
    const payload = '<img src=x onerror=alert(1)>';
    const m = await addSubject(db, { name: payload, color: '#000000' });
    expect((await listSubjects(db))[0]?.name).toBe(payload);
    expect(m.name).toBe(payload);
    db.close();
  });
  it('renomear matéria inexistente falha', async () => {
    const db = await fresh();
    await expect(
      renameSubject(db, 'nao-existe', { name: 'a', color: '#000000' }),
    ).rejects.toThrow();
    db.close();
  });
});

describe('T-DB-002 cronômetro: sobrevive a recarregar', () => {
  it('restaura o estado pausado e calcula o tempo corretamente', async () => {
    const name = `timer-${String(++n)}`;
    let db = await openAppDb(name);
    const m = await addSubject(db, { name: 'Química', color: '#aa0000' });
    await saveActiveTimer(db, m.id, pauseTimer(startTimer(T0), T0 + 10 * MIN));
    db.close(); // "recarregar a página"
    db = await openAppDb(name);
    const restored = await loadActiveTimer(db);
    expect(restored?.subjectId).toBe(m.id);
    expect(restored && elapsedMs(restored.state, T0 + 999 * MIN)).toBe(10 * MIN);
    db.close();
  });
  it('sem sessão ativa retorna null; estado idle não é salvo', async () => {
    const db = await fresh();
    expect(await loadActiveTimer(db)).toBeNull();
    await expect(saveActiveTimer(db, 'x', { status: 'idle' })).rejects.toThrow();
    db.close();
  });
});

describe('T-DB-003 finalizar sessão: XP, duplicação e atomicidade', () => {
  it('concluída: grava sessão, concede XP e limpa o cronômetro ativo', async () => {
    const db = await fresh();
    const m = await addSubject(db, { name: 'História', color: '#775500' });
    await saveActiveTimer(db, m.id, startTimer(T0));
    const { session, duplicate } = await finalizeSession(
      db,
      m.id,
      finishTimer(startTimer(T0), T0 + 30 * MIN).session,
    );
    expect(duplicate).toBe(false);
    expect(session.status).toBe('completed');
    expect(await totalXpStored(db)).toBe(30);
    expect(await loadActiveTimer(db)).toBeNull();
    db.close();
  });
  it('finalizar duas vezes não duplica sessão nem XP', async () => {
    const db = await fresh();
    const m = await addSubject(db, { name: 'Biologia', color: '#007744' });
    const f = finishTimer(startTimer(T0), T0 + 20 * MIN).session;
    await finalizeSession(db, m.id, f);
    expect((await finalizeSession(db, m.id, f)).duplicate).toBe(true);
    expect(await totalXpStored(db)).toBe(20);
    db.close();
  });
  it('cancelada e interrompida: registra a sessão mas não concede XP', async () => {
    const db = await fresh();
    const m = await addSubject(db, { name: 'Geografia', color: '#004477' });
    await finalizeSession(db, m.id, cancelTimer(startTimer(T0), T0 + 40 * MIN).session);
    const f = finishTimer(startTimer(T0 + 1), T0 + 1 + 40 * MIN).session;
    const r = await finalizeSession(db, m.id, f, true);
    expect(r.session.status).toBe('interrupted');
    expect(await totalXpStored(db)).toBe(0);
    db.close();
  });
  it('matéria inexistente: falha e não grava nada', async () => {
    const db = await fresh();
    const f = finishTimer(startTimer(T0), T0 + 30 * MIN).session;
    await expect(finalizeSession(db, 'fantasma', f)).rejects.toThrow();
    expect(await totalXpStored(db)).toBe(0);
    db.close();
  });
  it('matéria com sessões não pode ser excluída', async () => {
    const db = await fresh();
    const m = await addSubject(db, { name: 'Inglês', color: '#444444' });
    await finalizeSession(db, m.id, finishTimer(startTimer(T0), T0 + 10 * MIN).session);
    await expect(deleteSubject(db, m.id)).rejects.toThrow();
    expect(await listSubjects(db)).toHaveLength(1);
    db.close();
  });
});

describe('T-DB-005 regressão: id de XP com UUID de matéria é legível após gravar', () => {
  it('lançamento gravado volta a ser lido sem corrupção', async () => {
    const db = await fresh();
    const m = await addSubject(db, { name: 'Arte', color: '#222222' });
    await finalizeSession(db, m.id, finishTimer(startTimer(T0), T0 + 15 * MIN).session);
    expect(await totalXpStored(db)).toBe(15);
    db.close();
  });
});

describe('T-DB-004 dados corrompidos', () => {
  it('registro inválido no banco gera CorruptDataError sem vazar conteúdo', async () => {
    const db = await fresh();
    await db.put('subjects', { id: 'x', name: 'segredo-123', color: 'invalida', createdAt: 1 });
    const err = await listSubjects(db).catch((e: unknown) => e);
    expect(err).toBeInstanceOf(CorruptDataError);
    expect((err as Error).message).not.toContain('segredo-123');
    db.close();
  });
});
