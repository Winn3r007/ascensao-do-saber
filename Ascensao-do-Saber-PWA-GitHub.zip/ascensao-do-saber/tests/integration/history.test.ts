import 'fake-indexeddb/auto';
import { describe, expect, it } from 'vitest';
import { resolveTypes } from '../../src/domain/agenda/types';
import { openAppDb } from '../../src/infrastructure/db/db';
import {
  addSubject,
  deleteSession,
  deleteSubject,
  finalizeSession,
  listSessions,
  listSubjects,
  totalXpStored,
} from '../../src/infrastructure/db/repository';
import { finishTimer, startTimer } from '../../src/domain/timer/timer';

let n = 0;
const fresh = () => openAppDb(`hist-${String(++n)}`);
const H = 3_600_000;
const sess = (start: number, ms: number) => finishTimer(startTimer(start), start + ms).session;

describe('T-HIS-001 excluir matéria preserva o histórico em "Sessão apagada"', () => {
  it('Matemática 10h + Física 5h excluídas = uma só categoria com 15h; datas e XP preservados', async () => {
    const db = await fresh();
    const mat = await addSubject(db, { name: 'Matemática', color: '#112233' });
    const fis = await addSubject(db, { name: 'Física', color: '#223344' });
    await finalizeSession(db, mat.id, sess(1_700_000_000_000, 10 * H));
    await finalizeSession(db, fis.id, sess(1_800_000_000_000, 5 * H));
    const xpAntes = await totalXpStored(db);
    await deleteSubject(db, mat.id);
    await deleteSubject(db, fis.id);
    const subs = await listSubjects(db);
    expect(subs.map((s) => s.name)).toEqual(['Sessão apagada']);
    const ss = await listSessions(db);
    expect(ss.every((s) => s.subjectId === subs[0]?.id)).toBe(true);
    expect(ss.reduce((a, s) => a + s.activeMs, 0)).toBe(15 * H);
    expect(ss.map((s) => s.startedAt).sort()).toEqual([1_700_000_000_000, 1_800_000_000_000]);
    expect(await totalXpStored(db)).toBe(xpAntes);
    db.close();
  });
  it('matéria sem nada ligado some sem criar a categoria; nome reservado é rejeitado', async () => {
    const db = await fresh();
    const m = await addSubject(db, { name: 'Vazia', color: '#000000' });
    await deleteSubject(db, m.id);
    expect(await listSubjects(db)).toEqual([]);
    await expect(addSubject(db, { name: 'sessão APAGADA', color: '#000000' })).rejects.toThrow();
    db.close();
  });
  it('não exclui matéria com sessão em andamento nem a própria categoria', async () => {
    const db = await fresh();
    const m = await addSubject(db, { name: 'Química', color: '#000000' });
    await finalizeSession(db, m.id, sess(1_700_000_000_000, H));
    await deleteSubject(db, m.id);
    await expect(deleteSubject(db, 'sessao-apagada')).rejects.toThrow();
    db.close();
  });
});

describe('T-HIS-002 excluir sessão', () => {
  it('remove a sessão e o XP gerado por ela, mantendo as outras', async () => {
    const db = await fresh();
    const m = await addSubject(db, { name: 'Biologia', color: '#000000' });
    const a = await finalizeSession(db, m.id, sess(1_700_000_000_000, 30 * 60_000));
    await finalizeSession(db, m.id, sess(1_800_000_000_000, 20 * 60_000));
    expect(await totalXpStored(db)).toBe(50);
    await deleteSession(db, a.session.id);
    expect(await totalXpStored(db)).toBe(20);
    expect(await listSessions(db)).toHaveLength(1);
    await deleteSession(db, 'inexistente');
    expect(await listSessions(db)).toHaveLength(1);
    db.close();
  });
});

describe('T-AGE-001 tipos de agenda', () => {
  it('originais permanecem; cor dos originais é alterável; personalizados se somam', () => {
    const t = resolveTypes({
      eventTypes: [{ id: 'x1', name: 'Monitoria', color: '#00ff00' }],
      typeColors: { prova: '#123456', x1: '#654321' },
    });
    expect(t.map((x) => x.id)).toEqual(['compromisso', 'prova', 'trabalho', 'lembrete', 'x1']);
    expect(t.find((x) => x.id === 'prova')?.color).toBe('#123456');
    expect(t.find((x) => x.id === 'x1')?.color).toBe('#654321');
    expect(resolveTypes({}).every((x) => x.builtin)).toBe(true);
  });
});
