import 'fake-indexeddb/auto';
import { describe, expect, it } from 'vitest';
import {
  BackupError,
  deleteAllData,
  exportBackup,
  importBackup,
  parseBackup,
} from '../../src/infrastructure/backup/backup';
import { openAppDb } from '../../src/infrastructure/db/db';
import {
  addSubject,
  finalizeSession,
  listSubjects,
  totalXpStored,
} from '../../src/infrastructure/db/repository';
import { cancelTimer, finishTimer, startTimer } from '../../src/domain/timer/timer';

let n = 0;
const fresh = () => openAppDb(`bk-${String(++n)}`);
describe('T-BKP-001 backup', () => {
  it('exporta, apaga e restaura; XP é recalculado das sessões', async () => {
    const a = await fresh();
    const m = await addSubject(a, { name: 'Matemática', color: '#112233' });
    await finalizeSession(
      a,
      m.id,
      finishTimer(startTimer(1_700_000_000_000), 1_700_000_000_000 + 30 * 60_000).session,
    );
    await finalizeSession(
      a,
      m.id,
      cancelTimer(startTimer(1_800_000_000_000), 1_800_000_000_000 + 30 * 60_000).session,
    );
    const text = await exportBackup(a);
    await deleteAllData(a);
    expect(await listSubjects(a)).toEqual([]);
    await importBackup(a, text);
    expect((await listSubjects(a)).length).toBe(1);
    expect(await totalXpStored(a)).toBe(30);
    a.close();
  });
  it('rejeita JSON inválido, estrutura inesperada, versão errada, grande demais e sessão órfã', () => {
    expect(() => parseBackup('{nao json')).toThrow(BackupError);
    expect(() => parseBackup('{"format":"x"}')).toThrow(BackupError);
    expect(() => parseBackup('[]')).toThrow(BackupError);
    expect(() => parseBackup('x'.repeat(5 * 1024 * 1024 + 1))).toThrow(BackupError);
    const base = {
      format: 'ascensao-do-saber-backup',
      version: 2,
      exportedAt: 1,
      profile: { key: 'profile', characterName: 'A', pomodoroMinutes: 25 },
      subjects: [],
      sessions: [
        { id: 's', subjectId: 'x', startedAt: 1, endedAt: 2, activeMs: 1, status: 'completed' },
      ],
      events: [],
      goals: [],
      reviews: [],
      notes: [],
    };
    expect(() => parseBackup(JSON.stringify(base))).toThrow(BackupError);
    expect(() => parseBackup(JSON.stringify({ ...base, version: 1 }))).toThrow(BackupError);
    expect(() => parseBackup(JSON.stringify({ ...base, sessions: [], extra: 1 }))).toThrow(
      BackupError,
    );
  });
});
