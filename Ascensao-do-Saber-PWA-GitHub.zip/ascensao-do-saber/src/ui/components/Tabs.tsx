export function Tabs({
  tabs,
  value,
  onChange,
}: {
  tabs: readonly string[];
  value: string;
  onChange: (t: string) => void;
}) {
  return (
    <div className="tabs" role="tablist" aria-label="Seções">
      {tabs.map((t) => (
        <button
          key={t}
          role="tab"
          aria-selected={value === t}
          className="tab"
          onClick={() => {
            onChange(t);
          }}
        >
          {t}
        </button>
      ))}
    </div>
  );
}
