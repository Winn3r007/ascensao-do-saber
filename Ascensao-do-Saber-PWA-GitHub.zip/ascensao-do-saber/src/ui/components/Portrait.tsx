import imageUrl from "../../assets/personagem.jpg";
export const VARIANTS = [
  { id: 'original', name: 'Viajante Arcano', filter: 'none' },
  { id: 'luar', name: 'Viajante do Luar', filter: 'hue-rotate(160deg) saturate(1.1)' },
  { id: 'brasa', name: 'Viajante da Brasa', filter: 'sepia(0.6) saturate(1.8) hue-rotate(-15deg)' },
  { id: 'floresta', name: 'Viajante da Floresta', filter: 'hue-rotate(70deg) saturate(1.1)' },
] as const;
export type VariantId = (typeof VARIANTS)[number]['id'];

export function Portrait({
  variant = 'original',
  small = false,
}: {
  variant?: VariantId;
  small?: boolean;
}) {
  const v = VARIANTS.find((x) => x.id === variant) ?? VARIANTS[0];
  return (
    <div className={small ? 'portrait small' : 'portrait'}>
      <img src={imageUrl} alt={`Retrato: ${v.name}`} style={{ filter: v.filter }} />
    </div>
  );
}
