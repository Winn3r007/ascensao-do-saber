// Aviso de sessão concluída: som curto (WebAudio, sem arquivos externos) e notificação do navegador, se permitida.
export function announceDone(): void {
  try {
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    osc.frequency.value = 880;
    osc.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.25);
  } catch {
    /* sem áudio disponível */
  }
  if ('Notification' in window && Notification.permission === 'granted') {
    new Notification('Ascensão do Saber', { body: 'Sessão concluída. XP registrado.' });
  }
}
