const two = (n: number): string => String(n).padStart(2, '0');
export function formatClock(ms: number): string {
  const total = Math.floor(Math.max(0, ms) / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return h > 0 ? `${String(h)}:${two(m)}:${two(s)}` : `${two(m)}:${two(s)}`;
}
export function formatMinutes(ms: number): string {
  const m = Math.floor(ms / 60_000);
  return m >= 60 ? `${String(Math.floor(m / 60))} h ${two(m % 60)} min` : `${String(m)} min`;
}
