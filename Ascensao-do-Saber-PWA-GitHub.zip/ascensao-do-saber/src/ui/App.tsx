import { useEffect, useRef, useState } from 'react';
import { openAppDb, type Db } from '../infrastructure/db/db';
import { unlockAchievements } from '../infrastructure/db/items';
import { derive } from './derived';
import { Achievements } from './pages/Achievements';
import { Dashboard } from './pages/Dashboard';
import { Organization } from './pages/Organization';
import { Progress } from './pages/Progress';
import { Settings } from './pages/Settings';
import { Stats } from './pages/Stats';
import { Study } from './pages/Study';
import { Subjects } from './pages/Subjects';
import { useData } from './useData';

const PAGES = [
  { id: 'painel', label: 'Painel' },
  { id: 'estudo', label: 'Estudo' },
  { id: 'materias', label: 'Matérias' },
  { id: 'organizacao', label: 'Organização' },
  { id: 'estatisticas', label: 'Estatísticas' },
  { id: 'progressao', label: 'Progressão' },
  { id: 'conquistas', label: 'Conquistas' },
  { id: 'config', label: 'Configurações' },
] as const;
type PageId = (typeof PAGES)[number]['id'];
// Funcionalidades futuras: claramente rotuladas, sem ação.
const SOON = ['Talentos e classes', 'Clãs', 'PvP', 'Missões'];

function Loaded({ db, page }: { db: Db; page: PageId }) {
  const { data, error, reload } = useData(db);
  const tried = useRef(new Set<string>());
  useEffect(() => {
    if (!data) return;
    const have = new Set(data.achievements.map((a) => a.id));
    const fresh = derive(data, Date.now()).unlockable.filter(
      (id) => !have.has(id) && !tried.current.has(id),
    );
    if (fresh.length === 0) return;
    fresh.forEach((id) => tried.current.add(id));
    unlockAchievements(db, fresh, Date.now())
      .then(reload)
      .catch(() => undefined);
  }, [data, db, reload]);
  if (error)
    return (
      <p className="msg" role="alert">
        {error}
      </p>
    );
  if (!data)
    return (
      <p className="muted" role="status">
        Carregando seus dados…
      </p>
    );
  const p = { db, data, reload };
  switch (page) {
    case 'estudo':
      return <Study {...p} />;
    case 'materias':
      return <Subjects {...p} />;
    case 'organizacao':
      return <Organization {...p} />;
    case 'estatisticas':
      return <Stats data={data} />;
    case 'progressao':
      return <Progress data={data} />;
    case 'conquistas':
      return <Achievements data={data} />;
    case 'config':
      return <Settings {...p} />;
    default:
      return <Dashboard data={data} />;
  }
}

export function App() {
  const [db, setDb] = useState<Db | null>(null);
  const [failed, setFailed] = useState(false);
  const [page, setPage] = useState<PageId>('painel');
  useEffect(() => {
    let alive = true;
    openAppDb()
      .then((d) => {
        if (alive) setDb(d);
        else d.close();
      })
      .catch(() => {
        if (alive) setFailed(true);
      });
    return () => {
      alive = false;
    };
  }, []);
  return (
    <div className="app">
      <nav className="nav" aria-label="Principal">
        <h2>Ascensão do Saber</h2>
        {PAGES.map((p) => (
          <button
            key={p.id}
            aria-current={page === p.id ? 'page' : undefined}
            onClick={() => {
              setPage(p.id);
            }}
          >
            {p.label}
          </button>
        ))}
        {SOON.map((label) => (
          <button key={label} aria-disabled="true" tabIndex={-1}>
            {label}
            <span className="soon">em breve</span>
          </button>
        ))}
      </nav>
      <main className="main">
        {failed ? (
          <p className="msg" role="alert">
            Seu navegador não permitiu salvar dados locais. Verifique se o modo privado está ativo.
          </p>
        ) : db ? (
          <Loaded db={db} page={page} />
        ) : (
          <p className="muted" role="status">
            Abrindo o armazenamento local…
          </p>
        )}
      </main>
    </div>
  );
}
