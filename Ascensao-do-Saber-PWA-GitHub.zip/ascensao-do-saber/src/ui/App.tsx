import { useEffect, useRef, useState } from 'react';
import { openAppDb, type Db } from '../infrastructure/db/db';
import { unlockAchievements } from '../infrastructure/db/items';
import { DELETED_ID } from '../infrastructure/db/repository';
import { Portrait } from './components/Portrait';
import { derive } from './derived';
import { Achievements } from './pages/Achievements';
import { CharacterCreation } from './pages/CharacterCreation';
import { Diario } from './pages/Diario';
import { Grimorio } from './pages/Grimorio';
import { Sanctuary } from './pages/Sanctuary';
import { Settings } from './pages/Settings';
import { Study } from './pages/Study';
import { useData } from './useData';
import imageUrl from '../assets/logo.png';

const PAGES = [
  { id: 'santuario', label: 'Santuário' },
  { id: 'expedicao', label: 'Expedição' },
  { id: 'grimorio', label: 'Grimório' },
  { id: 'diario', label: 'Diário' },
  { id: 'conquistas', label: 'Conquistas' },
  { id: 'config', label: 'Configurações' },
] as const;
type PageId = (typeof PAGES)[number]['id'];

function Game({ db }: { db: Db }) {
  const { data, error, reload } = useData(db);
  const [page, setPage] = useState<PageId>('santuario');
  const [now] = useState(() => Date.now());
  const tried = useRef(new Set<string>());
  useEffect(() => {
    if (!data) return;
    const have = new Set(data.achievements.map((a) => a.id));
    const fresh = derive(data, Date.now()).unlockable.filter(
      (id) => !have.has(id) && !tried.current.has(id),
    );
    if (fresh.length === 0) return;
    fresh.forEach((id) => tried.current.add(id));
    unlockAchievements(db, fresh, Date.now())
      .then(reload)
      .catch(() => undefined);
  }, [data, db, reload]);
  if (error)
    return (
      <main className="main">
        <p className="msg" role="alert">
          {error}
        </p>
      </main>
    );
  if (!data)
    return (
      <main className="main">
        <p className="muted" role="status">
          Carregando seus dados…
        </p>
      </main>
    );
  // Primeiro acesso: o personagem vem antes de qualquer outra tela.
  if (!data.profile.created) return <CharacterCreation db={db} data={data} reload={reload} />;
  const p = { db, data, reload };
  const streak = derive(data, now).stats.current;
  const studyData = { ...data, subjects: data.subjects.filter((s) => s.id !== DELETED_ID) };
  return (
    <div className="app" data-page={page}>
      <header className="topbar">
        <div className="brand">
          <img src={imageUrl} alt="" width="44" height="44" />
          <div>
            <b>Ascensão do Saber</b>
            <span>Acampamento da Clareira</span>
          </div>
        </div>
        <nav className="nav" aria-label="Principal">
          {PAGES.map((x) => (
            <button
              key={x.id}
              aria-current={page === x.id ? 'page' : undefined}
              onClick={() => {
                setPage(x.id);
              }}
            >
              {x.label}
            </button>
          ))}
        </nav>
        <div className="chips">
          <span className="chip" title="Dias seguidos de estudo">
            Chama {streak}d
          </span>
          <button
            className="chip avatar"
            onClick={() => {
              setPage('config');
            }}
            aria-label="Abrir configurações do personagem"
          >
            <Portrait variant={data.profile.appearance?.variant ?? 'original'} small />
            <span>{data.profile.characterName}</span>
          </button>
        </div>
      </header>
      <main className="main">
        {page === 'santuario' && <Sanctuary data={data} go={setPage} />}
        {page === 'expedicao' && <Study db={db} data={studyData} reload={reload} />}
        {page === 'grimorio' && <Grimorio {...p} />}
        {page === 'diario' && <Diario {...p} />}
        {page === 'conquistas' && <Achievements data={data} />}
        {page === 'config' && <Settings {...p} />}
      </main>
    </div>
  );
}

export function App() {
  const [db, setDb] = useState<Db | null>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let alive = true;
    openAppDb()
      .then((d) => {
        if (alive) setDb(d);
        else d.close();
      })
      .catch(() => {
        if (alive) setFailed(true);
      });
    return () => {
      alive = false;
    };
  }, []);
  if (failed)
    return (
      <main className="main">
        <p className="msg" role="alert">
          Seu navegador não permitiu salvar dados locais. Verifique se o modo privado está ativo.
        </p>
      </main>
    );
  return db ? (
    <Game db={db} />
  ) : (
    <main className="main">
      <p className="muted" role="status">
        Abrindo o armazenamento local…
      </p>
    </main>
  );
}
