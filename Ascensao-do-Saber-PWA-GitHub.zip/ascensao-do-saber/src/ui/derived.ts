import { evaluateAchievements } from '../domain/achievements/achievements';
import { goalProgress } from '../domain/goals/goals';
import { computeStats, isoDay } from '../domain/stats/summary';
import type { Data } from './useData';

// Tudo aqui é derivado dos registros persistidos (fonte única de verdade).
export function derive(data: Data, now: number) {
  const stats = computeStats(data.sessions, now);
  const completed = data.sessions.filter((s) => s.status === 'completed');
  const today = isoDay(now);
  const goalsView = data.goals.map((g) => ({ goal: g, ...goalProgress(g, data.sessions, today) }));
  const goalsDone = goalsView.filter((g) => g.status === 'concluida').length;
  const reviewsMastered = data.reviews.filter((r) => r.state === 'dominado').length;
  const tasksDone = data.events.filter((e) => e.kind === 'trabalho' && e.done).length;
  const ctx = { completed, goalsDone, reviewsMastered, longestStreak: stats.longest };
  return {
    stats,
    completed,
    goalsView,
    goalsDone,
    reviewsMastered,
    tasksDone,
    unlockable: evaluateAchievements(ctx),
  };
}
export const subjectName = (data: Data, id: string | undefined): string =>
  data.subjects.find((s) => s.id === id)?.name ?? 'Matéria removida';
export const opt = (subjectId: string): { subjectId?: string } => (subjectId ? { subjectId } : {});
