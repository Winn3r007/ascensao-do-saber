import { useCallback, useEffect, useState } from 'react';
import type { Db } from '../infrastructure/db/db';
import { getProfile, listAchievements, listItems } from '../infrastructure/db/items';
import {
  CorruptDataError,
  listSessions,
  listSubjects,
  loadActiveTimer,
  totalXpStored,
} from '../infrastructure/db/repository';
import type {
  AchievementRow,
  ActiveTimer,
  AppEvent,
  Goal,
  Note,
  Profile,
  Review,
  Session,
  Subject,
} from '../validation/schemas';

export interface Data {
  subjects: Subject[];
  sessions: Session[];
  xp: number;
  active: ActiveTimer | null;
  events: AppEvent[];
  goals: Goal[];
  reviews: Review[];
  notes: Note[];
  achievements: AchievementRow[];
  profile: Profile;
}

async function load(db: Db): Promise<Data> {
  const [subjects, sessions, xp, active, events, goals, reviews, notes, achievements, profile] =
    await Promise.all([
      listSubjects(db),
      listSessions(db),
      totalXpStored(db),
      loadActiveTimer(db),
      listItems(db, 'events'),
      listItems(db, 'goals'),
      listItems(db, 'reviews'),
      listItems(db, 'notes'),
      listAchievements(db),
      getProfile(db),
    ]);
  return { subjects, sessions, xp, active, events, goals, reviews, notes, achievements, profile };
}
const messageFor = (e: unknown): string =>
  e instanceof CorruptDataError
    ? 'Os dados locais estão inválidos. Se tiver um backup, importe-o em Configurações; senão, reinicie os dados.'
    : 'Não foi possível ler os dados locais. Recarregue a página.';

export function useData(db: Db) {
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState<string | null>(null);
  const reload = useCallback(async () => {
    try {
      setData(await load(db));
      setError(null);
    } catch (e) {
      setError(messageFor(e));
    }
  }, [db]);
  useEffect(() => {
    let alive = true;
    load(db)
      .then((d) => {
        if (alive) setData(d);
      })
      .catch((e: unknown) => {
        if (alive) setError(messageFor(e));
      });
    return () => {
      alive = false;
    };
  }, [db]);
  return { data, error, reload };
}
