import { formatMinutes } from '../format';
import { useState } from 'react';
import { derive, subjectName } from '../derived';
import type { Data } from '../useData';

const DAYS = ['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado'];
export function Stats({ data }: { data: Data }) {
  const [now] = useState(() => Date.now());
  const { stats: s, goalsView } = derive(data, now);
  if (data.sessions.every((x) => x.status !== 'completed')) {
    return (
      <>
        <h1>Estatísticas</h1>
        <p className="empty">
          Ainda não há sessões concluídas. As estatísticas aparecem depois da primeira sessão.
        </p>
      </>
    );
  }
  const subs = [...s.bySubject].sort((a, b) => b[1] - a[1]);
  const maxSub = Math.max(...subs.map(([, v]) => v), 1);
  return (
    <>
      <h1>Estatísticas</h1>
      <div className="grid">
        {(
          [
            ['Hoje', s.today],
            ['Últimos 7 dias', s.week],
            ['Neste mês', s.month],
            ['Total', s.total],
            ['Média por dia estudado', s.averagePerStudyDay],
          ] as const
        ).map(([l, v]) => (
          <section key={l} className="panel stat">
            <span className="muted">{l}</span>
            <b>{formatMinutes(v)}</b>
          </section>
        ))}
        <section className="panel stat">
          <span className="muted">Sequência atual</span>
          <b>{s.current} dias</b>
        </section>
        <section className="panel stat">
          <span className="muted">Maior sequência</span>
          <b>{s.longest} dias</b>
        </section>
      </div>
      <section className="panel">
        <h2>Horas por matéria</h2>
        <ul className="list">
          {subs.map(([id, ms]) => (
            <li key={id}>
              <span style={{ minWidth: '8rem' }}>{subjectName(data, id)}</span>
              <span className="bar" aria-hidden="true">
                <i style={{ width: `${String(Math.round((ms / maxSub) * 100))}%` }} />
              </span>
              <span className="muted">
                {formatMinutes(ms)} ({Math.round((ms / s.total) * 100)}%)
              </span>
            </li>
          ))}
        </ul>
      </section>
      <section className="panel">
        <h2>Produtividade</h2>
        <p>
          Dia mais produtivo: <b>{s.bestWeekday === null ? '-' : DAYS[s.bestWeekday]}</b>. Horário
          de maior produtividade: <b>{s.bestHour === null ? '-' : `${String(s.bestHour)}h`}</b>.
        </p>
      </section>
      <section className="panel">
        <h2>Progresso das metas</h2>
        {goalsView.length === 0 ? (
          <p className="muted">Nenhuma meta criada.</p>
        ) : (
          <ul className="list">
            {goalsView.map(({ goal, value, status }) => (
              <li key={goal.id}>
                <span>{goal.title}</span>
                <span className="muted">
                  {value} / {goal.target}, {status.replace('_', ' ')}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
