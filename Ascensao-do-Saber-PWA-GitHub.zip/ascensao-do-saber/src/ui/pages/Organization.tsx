import { useState } from 'react';
import { resolveTypes, typeOf, type EventType } from '../../domain/agenda/types';
import { isoDay } from '../../domain/stats/summary';
import type { Db } from '../../infrastructure/db/db';
import { newId, putItem, removeItem, saveProfile } from '../../infrastructure/db/items';
import { derive, opt, subjectName } from '../derived';
import { useAction } from '../useAction';
import type { Data } from '../useData';

type Props = { db: Db; data: Data; reload: () => Promise<void> };
const REVIEW = {
  precisa_revisar: 'Preciso revisar',
  estudando: 'Estudando',
  dominado: 'Dominado',
} as const;
const STATUS = {
  concluida: 'concluída',
  atrasada: 'atrasada',
  em_andamento: 'em andamento',
} as const;
const submit = (fn: () => void) => (e: { preventDefault: () => void }) => {
  e.preventDefault();
  fn();
};
const SubjectSelect = ({
  data,
  value,
  onChange,
}: {
  data: Data;
  value: string;
  onChange: (v: string) => void;
}) => (
  <label>
    Matéria (opcional)
    <select
      value={value}
      onChange={(e) => {
        onChange(e.target.value);
      }}
    >
      <option value="">Sem matéria</option>
      {data.subjects.map((s) => (
        <option key={s.id} value={s.id}>
          {s.name}
        </option>
      ))}
    </select>
  </label>
);

export function Agenda({ db, data, reload }: Props) {
  const types = resolveTypes(data.profile);
  const { error, run } = useAction(reload);
  const [kind, setKind] = useState('compromisso');
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(() => isoDay(Date.now()));
  const [time, setTime] = useState('');
  const [subject, setSubject] = useState('');
  const [content, setContent] = useState('');
  const items = [...data.events].sort((a, b) =>
    (a.date + (a.time ?? '')).localeCompare(b.date + (b.time ?? '')),
  );
  return (
    <>
      <TypeManager db={db} data={data} reload={reload} types={types} />
      <form
        className="panel row"
        onSubmit={submit(() => {
          run(async () => {
            await putItem(db, 'events', {
              id: newId(),
              kind,
              title,
              date,
              ...(time ? { time } : {}),
              ...opt(subject),
              ...(content ? { content } : {}),
              done: false,
            });
            setTitle('');
            setContent('');
          });
        })}
      >
        <label>
          Tipo
          <select
            value={kind}
            onChange={(e) => {
              setKind(e.target.value);
            }}
          >
            {types.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Título
          <input
            value={title}
            maxLength={100}
            required
            onChange={(e) => {
              setTitle(e.target.value);
            }}
          />
        </label>
        <label>
          Data
          <input
            type="date"
            value={date}
            required
            onChange={(e) => {
              setDate(e.target.value);
            }}
          />
        </label>
        <label>
          Hora
          <input
            type="time"
            value={time}
            onChange={(e) => {
              setTime(e.target.value);
            }}
          />
        </label>
        <SubjectSelect data={data} value={subject} onChange={setSubject} />
        <label>
          Conteúdo ou preparação
          <input
            value={content}
            maxLength={1000}
            onChange={(e) => {
              setContent(e.target.value);
            }}
          />
        </label>
        <button className="btn primary" type="submit">
          Adicionar à agenda
        </button>
      </form>
      {error && (
        <p className="msg" role="alert">
          {error}
        </p>
      )}
      {items.length === 0 ? (
        <p className="empty">
          Nada na agenda. Adicione um compromisso, prova, trabalho ou lembrete.
        </p>
      ) : (
        <ul className="list">
          {items.map((e) => (
            <li key={e.id}>
              <label className="row">
                <input
                  type="checkbox"
                  checked={e.done}
                  aria-label={`Concluído: ${e.title}`}
                  onChange={() => {
                    run(() => putItem(db, 'events', { ...e, done: !e.done }));
                  }}
                />
                <span>
                  <b style={{ color: typeOf(types, e.kind).color }}>{typeOf(types, e.kind).name}</b>
                  : {e.title}{' '}
                  <span className="muted">
                    {e.date}
                    {e.time ? ` ${e.time}` : ''}
                    {e.subjectId ? `, ${subjectName(data, e.subjectId)}` : ''}
                    {e.content ? `, ${e.content}` : ''}
                  </span>
                </span>
              </label>
              <button
                className="btn danger"
                onClick={() => {
                  run(() => removeItem(db, 'events', e.id));
                }}
              >
                Excluir {e.title}
              </button>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

export function Calendar({ data }: { data: Data }) {
  const [cursor, setCursor] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });
  const first = cursor.getDay();
  const days = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
  const key = (d: number) => isoDay(new Date(cursor.getFullYear(), cursor.getMonth(), d).getTime());
  const cells: (number | null)[] = [
    ...Array<null>(first).fill(null),
    ...Array.from({ length: days }, (_, i) => i + 1),
  ];
  const label = cursor.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  return (
    <section className="panel">
      <div className="row">
        <button
          className="btn"
          onClick={() => {
            setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1));
          }}
        >
          Mês anterior
        </button>
        <h2 style={{ margin: 0 }}>{label}</h2>
        <button
          className="btn"
          onClick={() => {
            setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1));
          }}
        >
          Próximo mês
        </button>
      </div>
      <div className="cal" role="grid" aria-label={label}>
        {['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((w, i) => (
          <b key={i} className="muted">
            {w}
          </b>
        ))}
        {cells.map((d, i) =>
          d === null ? (
            <span key={`e${String(i)}`} />
          ) : (
            <div key={d} className="cell" role="gridcell">
              <span>{d}</span>
              {data.events
                .filter((e) => e.date === key(d))
                .map((e) => (
                  <small
                    key={e.id}
                    className="ev"
                    style={{ borderColor: typeOf(resolveTypes(data.profile), e.kind).color }}
                  >
                    {e.title}
                  </small>
                ))}
            </div>
          ),
        )}
      </div>
    </section>
  );
}

export function Goals({ db, data, reload }: Props) {
  const { error, run } = useAction(reload);
  const [title, setTitle] = useState('');
  const [metric, setMetric] = useState<'minutes' | 'sessions'>('minutes');
  const [target, setTarget] = useState(600);
  const [deadline, setDeadline] = useState(() => isoDay(Date.now() + 30 * 86_400_000));
  const [subject, setSubject] = useState('');
  const [now] = useState(() => Date.now());
  const view = derive(data, now).goalsView;
  return (
    <>
      <form
        className="panel row"
        onSubmit={submit(() => {
          run(async () => {
            await putItem(db, 'goals', {
              id: newId(),
              title,
              metric,
              target,
              deadline,
              ...opt(subject),
              createdAt: Date.now(),
            });
            setTitle('');
          });
        })}
      >
        <label>
          Título
          <input
            value={title}
            maxLength={100}
            required
            onChange={(e) => {
              setTitle(e.target.value);
            }}
          />
        </label>
        <label>
          Medir em
          <select
            value={metric}
            onChange={(e) => {
              setMetric(e.target.value as 'minutes' | 'sessions');
            }}
          >
            <option value="minutes">Minutos estudados</option>
            <option value="sessions">Sessões concluídas</option>
          </select>
        </label>
        <label>
          Quantidade desejada
          <input
            type="number"
            min={1}
            value={target}
            onChange={(e) => {
              setTarget(Number(e.target.value));
            }}
          />
        </label>
        <label>
          Prazo
          <input
            type="date"
            value={deadline}
            required
            onChange={(e) => {
              setDeadline(e.target.value);
            }}
          />
        </label>
        <SubjectSelect data={data} value={subject} onChange={setSubject} />
        <button className="btn primary" type="submit">
          Criar meta
        </button>
      </form>
      {error && (
        <p className="msg" role="alert">
          {error}
        </p>
      )}
      {view.length === 0 ? (
        <p className="empty">Nenhuma meta. O progresso é calculado das suas sessões concluídas.</p>
      ) : (
        <ul className="list">
          {view.map(({ goal: g, value, status }) => (
            <li key={g.id}>
              <div style={{ flex: 1 }}>
                <b>{g.title}</b>{' '}
                <span className="muted">
                  {STATUS[status]}, prazo {g.deadline}
                </span>
                <progress
                  max={g.target}
                  value={Math.min(value, g.target)}
                  aria-label={`Progresso de ${g.title}`}
                />
                <span className="muted">
                  {value} / {g.target} {g.metric === 'minutes' ? 'min' : 'sessões'}
                </span>
              </div>
              <button
                className="btn danger"
                onClick={() => {
                  run(() => removeItem(db, 'goals', g.id));
                }}
              >
                Excluir {g.title}
              </button>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

export function Reviews({ db, data, reload }: Props) {
  const { error, run } = useAction(reload);
  const [topic, setTopic] = useState('');
  const [subject, setSubject] = useState('');
  return (
    <>
      <form
        className="panel row"
        onSubmit={submit(() => {
          run(async () => {
            await putItem(db, 'reviews', {
              id: newId(),
              topic,
              ...opt(subject),
              state: 'precisa_revisar',
            });
            setTopic('');
          });
        })}
      >
        <label>
          Assunto a revisar
          <input
            value={topic}
            maxLength={100}
            required
            onChange={(e) => {
              setTopic(e.target.value);
            }}
          />
        </label>
        <SubjectSelect data={data} value={subject} onChange={setSubject} />
        <button className="btn primary" type="submit">
          Adicionar revisão
        </button>
      </form>
      {error && (
        <p className="msg" role="alert">
          {error}
        </p>
      )}
      {data.reviews.length === 0 ? (
        <p className="empty">Nenhum assunto para revisar.</p>
      ) : (
        <ul className="list">
          {data.reviews.map((r) => (
            <li key={r.id}>
              <span>
                {r.topic}{' '}
                <span className="muted">{r.subjectId ? subjectName(data, r.subjectId) : ''}</span>
              </span>
              <span className="row">
                <select
                  aria-label={`Estado de ${r.topic}`}
                  value={r.state}
                  onChange={(e) => {
                    const state = e.target.value; // ler já: o select controlado volta ao valor antigo depois do render
                    run(() => putItem(db, 'reviews', { ...r, state }));
                  }}
                >
                  {Object.entries(REVIEW).map(([k, v]) => (
                    <option key={k} value={k}>
                      {v}
                    </option>
                  ))}
                </select>
                <button
                  className="btn danger"
                  onClick={() => {
                    run(() => removeItem(db, 'reviews', r.id));
                  }}
                >
                  Excluir {r.topic}
                </button>
              </span>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

// Tipos de atividade: os 4 originais ficam sempre (só a cor muda); você cria, recolore e remove os seus.
function TypeManager({ db, data, reload, types }: Props & { types: EventType[] }) {
  const { error, run } = useAction(reload);
  const [name, setName] = useState('');
  const [color, setColor] = useState('#4edea3');
  const save = (patch: {
    eventTypes?: { id: string; name: string; color: string }[];
    typeColors?: Record<string, string>;
  }) => saveProfile(db, { ...data.profile, ...patch });
  const custom = (data.profile.eventTypes ?? []).map((t) => ({
    id: t.id,
    name: t.name,
    color: t.color,
  }));
  return (
    <details className="frame types">
      <summary>Tipos de atividade e cores</summary>
      {error && (
        <p className="msg" role="alert">
          {error}
        </p>
      )}
      <ul className="plain">
        {types.map((t) => (
          <li key={t.id}>
            <span>
              <span className="dot" style={{ background: t.color }} />
              {t.name}
              {t.builtin ? <span className="muted small"> (original)</span> : null}
            </span>
            <span className="row">
              <input
                type="color"
                aria-label={`Cor do tipo ${t.name}`}
                value={t.color}
                onChange={(e) => {
                  const c = e.target.value;
                  run(() => save({ typeColors: { ...data.profile.typeColors, [t.id]: c } }));
                }}
              />
              {!t.builtin && (
                <button
                  className="btn danger"
                  onClick={() => {
                    run(async () => {
                      if (data.events.some((ev) => ev.kind === t.id)) throw new Error('em uso');
                      await save({ eventTypes: custom.filter((c) => c.id !== t.id) });
                    }, 'Este tipo está em uso por atividades da agenda. Remova ou mude essas atividades antes.');
                  }}
                >
                  Excluir tipo {t.name}
                </button>
              )}
            </span>
          </li>
        ))}
      </ul>
      <form
        className="row"
        onSubmit={(e) => {
          e.preventDefault();
          run(async () => {
            await save({
              eventTypes: [...custom, { id: `t-${crypto.randomUUID().slice(0, 8)}`, name, color }],
            });
            setName('');
          }, 'Informe um nome de 1 a 30 caracteres (máximo de 30 tipos).');
        }}
      >
        <label>
          Novo tipo
          <input
            value={name}
            maxLength={30}
            required
            onChange={(e) => {
              setName(e.target.value);
            }}
          />
        </label>
        <label>
          Cor
          <input
            type="color"
            value={color}
            onChange={(e) => {
              setColor(e.target.value);
            }}
          />
        </label>
        <button className="btn primary" type="submit">
          Criar tipo
        </button>
      </form>
    </details>
  );
}
