import { useState } from 'react';
import { isoDay } from '../../domain/stats/summary';
import type { Db } from '../../infrastructure/db/db';
import { newId, putItem, removeItem } from '../../infrastructure/db/items';
import { derive, opt, subjectName } from '../derived';
import { useAction } from '../useAction';
import type { Data } from '../useData';

type Props = { db: Db; data: Data; reload: () => Promise<void> };
const TABS = ['Agenda', 'Calendário', 'Metas', 'Revisões', 'Anotações'] as const;
const KIND = {
  compromisso: 'Compromisso',
  prova: 'Prova',
  trabalho: 'Trabalho',
  lembrete: 'Lembrete',
} as const;
const REVIEW = {
  precisa_revisar: 'Preciso revisar',
  estudando: 'Estudando',
  dominado: 'Dominado',
} as const;
const STATUS = {
  concluida: 'concluída',
  atrasada: 'atrasada',
  em_andamento: 'em andamento',
} as const;
const submit = (fn: () => void) => (e: { preventDefault: () => void }) => {
  e.preventDefault();
  fn();
};
const SubjectSelect = ({
  data,
  value,
  onChange,
}: {
  data: Data;
  value: string;
  onChange: (v: string) => void;
}) => (
  <label>
    Matéria (opcional)
    <select
      value={value}
      onChange={(e) => {
        onChange(e.target.value);
      }}
    >
      <option value="">Sem matéria</option>
      {data.subjects.map((s) => (
        <option key={s.id} value={s.id}>
          {s.name}
        </option>
      ))}
    </select>
  </label>
);

function Agenda({ db, data, reload }: Props) {
  const { error, run } = useAction(reload);
  const [kind, setKind] = useState<keyof typeof KIND>('compromisso');
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(() => isoDay(Date.now()));
  const [time, setTime] = useState('');
  const [subject, setSubject] = useState('');
  const [content, setContent] = useState('');
  const items = [...data.events].sort((a, b) =>
    (a.date + (a.time ?? '')).localeCompare(b.date + (b.time ?? '')),
  );
  return (
    <>
      <form
        className="panel row"
        onSubmit={submit(() => {
          run(async () => {
            await putItem(db, 'events', {
              id: newId(),
              kind,
              title,
              date,
              ...(time ? { time } : {}),
              ...opt(subject),
              ...(content ? { content } : {}),
              done: false,
            });
            setTitle('');
            setContent('');
          });
        })}
      >
        <label>
          Tipo
          <select
            value={kind}
            onChange={(e) => {
              setKind(e.target.value as keyof typeof KIND);
            }}
          >
            {Object.entries(KIND).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </label>
        <label>
          Título
          <input
            value={title}
            maxLength={100}
            required
            onChange={(e) => {
              setTitle(e.target.value);
            }}
          />
        </label>
        <label>
          Data
          <input
            type="date"
            value={date}
            required
            onChange={(e) => {
              setDate(e.target.value);
            }}
          />
        </label>
        <label>
          Hora
          <input
            type="time"
            value={time}
            onChange={(e) => {
              setTime(e.target.value);
            }}
          />
        </label>
        <SubjectSelect data={data} value={subject} onChange={setSubject} />
        <label>
          Conteúdo ou preparação
          <input
            value={content}
            maxLength={1000}
            onChange={(e) => {
              setContent(e.target.value);
            }}
          />
        </label>
        <button className="btn primary" type="submit">
          Adicionar à agenda
        </button>
      </form>
      {error && (
        <p className="msg" role="alert">
          {error}
        </p>
      )}
      {items.length === 0 ? (
        <p className="empty">
          Nada na agenda. Adicione um compromisso, prova, trabalho ou lembrete.
        </p>
      ) : (
        <ul className="list">
          {items.map((e) => (
            <li key={e.id}>
              <label className="row">
                <input
                  type="checkbox"
                  checked={e.done}
                  aria-label={`Concluído: ${e.title}`}
                  onChange={() => {
                    run(() => putItem(db, 'events', { ...e, done: !e.done }));
                  }}
                />
                <span>
                  <b>{KIND[e.kind]}</b>: {e.title}{' '}
                  <span className="muted">
                    {e.date}
                    {e.time ? ` ${e.time}` : ''}
                    {e.subjectId ? `, ${subjectName(data, e.subjectId)}` : ''}
                    {e.content ? `, ${e.content}` : ''}
                  </span>
                </span>
              </label>
              <button
                className="btn danger"
                onClick={() => {
                  run(() => removeItem(db, 'events', e.id));
                }}
              >
                Excluir {e.title}
              </button>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

function Calendar({ data }: { data: Data }) {
  const [cursor, setCursor] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });
  const first = cursor.getDay();
  const days = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
  const key = (d: number) => isoDay(new Date(cursor.getFullYear(), cursor.getMonth(), d).getTime());
  const cells: (number | null)[] = [
    ...Array<null>(first).fill(null),
    ...Array.from({ length: days }, (_, i) => i + 1),
  ];
  const label = cursor.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  return (
    <section className="panel">
      <div className="row">
        <button
          className="btn"
          onClick={() => {
            setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1));
          }}
        >
          Mês anterior
        </button>
        <h2 style={{ margin: 0 }}>{label}</h2>
        <button
          className="btn"
          onClick={() => {
            setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1));
          }}
        >
          Próximo mês
        </button>
      </div>
      <div className="cal" role="grid" aria-label={label}>
        {['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((w, i) => (
          <b key={i} className="muted">
            {w}
          </b>
        ))}
        {cells.map((d, i) =>
          d === null ? (
            <span key={`e${String(i)}`} />
          ) : (
            <div key={d} className="cell" role="gridcell">
              <span>{d}</span>
              {data.events
                .filter((e) => e.date === key(d))
                .map((e) => (
                  <small key={e.id} className={`ev ${e.kind}`}>
                    {e.title}
                  </small>
                ))}
            </div>
          ),
        )}
      </div>
    </section>
  );
}

function Goals({ db, data, reload }: Props) {
  const { error, run } = useAction(reload);
  const [title, setTitle] = useState('');
  const [metric, setMetric] = useState<'minutes' | 'sessions'>('minutes');
  const [target, setTarget] = useState(600);
  const [deadline, setDeadline] = useState(() => isoDay(Date.now() + 30 * 86_400_000));
  const [subject, setSubject] = useState('');
  const [now] = useState(() => Date.now());
  const view = derive(data, now).goalsView;
  return (
    <>
      <form
        className="panel row"
        onSubmit={submit(() => {
          run(async () => {
            await putItem(db, 'goals', {
              id: newId(),
              title,
              metric,
              target,
              deadline,
              ...opt(subject),
              createdAt: Date.now(),
            });
            setTitle('');
          });
        })}
      >
        <label>
          Título
          <input
            value={title}
            maxLength={100}
            required
            onChange={(e) => {
              setTitle(e.target.value);
            }}
          />
        </label>
        <label>
          Medir em
          <select
            value={metric}
            onChange={(e) => {
              setMetric(e.target.value as 'minutes' | 'sessions');
            }}
          >
            <option value="minutes">Minutos estudados</option>
            <option value="sessions">Sessões concluídas</option>
          </select>
        </label>
        <label>
          Quantidade desejada
          <input
            type="number"
            min={1}
            value={target}
            onChange={(e) => {
              setTarget(Number(e.target.value));
            }}
          />
        </label>
        <label>
          Prazo
          <input
            type="date"
            value={deadline}
            required
            onChange={(e) => {
              setDeadline(e.target.value);
            }}
          />
        </label>
        <SubjectSelect data={data} value={subject} onChange={setSubject} />
        <button className="btn primary" type="submit">
          Criar meta
        </button>
      </form>
      {error && (
        <p className="msg" role="alert">
          {error}
        </p>
      )}
      {view.length === 0 ? (
        <p className="empty">Nenhuma meta. O progresso é calculado das suas sessões concluídas.</p>
      ) : (
        <ul className="list">
          {view.map(({ goal: g, value, status }) => (
            <li key={g.id}>
              <div style={{ flex: 1 }}>
                <b>{g.title}</b>{' '}
                <span className="muted">
                  {STATUS[status]}, prazo {g.deadline}
                </span>
                <progress
                  max={g.target}
                  value={Math.min(value, g.target)}
                  aria-label={`Progresso de ${g.title}`}
                />
                <span className="muted">
                  {value} / {g.target} {g.metric === 'minutes' ? 'min' : 'sessões'}
                </span>
              </div>
              <button
                className="btn danger"
                onClick={() => {
                  run(() => removeItem(db, 'goals', g.id));
                }}
              >
                Excluir {g.title}
              </button>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

function Reviews({ db, data, reload }: Props) {
  const { error, run } = useAction(reload);
  const [topic, setTopic] = useState('');
  const [subject, setSubject] = useState('');
  return (
    <>
      <form
        className="panel row"
        onSubmit={submit(() => {
          run(async () => {
            await putItem(db, 'reviews', {
              id: newId(),
              topic,
              ...opt(subject),
              state: 'precisa_revisar',
            });
            setTopic('');
          });
        })}
      >
        <label>
          Assunto a revisar
          <input
            value={topic}
            maxLength={100}
            required
            onChange={(e) => {
              setTopic(e.target.value);
            }}
          />
        </label>
        <SubjectSelect data={data} value={subject} onChange={setSubject} />
        <button className="btn primary" type="submit">
          Adicionar revisão
        </button>
      </form>
      {error && (
        <p className="msg" role="alert">
          {error}
        </p>
      )}
      {data.reviews.length === 0 ? (
        <p className="empty">Nenhum assunto para revisar.</p>
      ) : (
        <ul className="list">
          {data.reviews.map((r) => (
            <li key={r.id}>
              <span>
                {r.topic}{' '}
                <span className="muted">{r.subjectId ? subjectName(data, r.subjectId) : ''}</span>
              </span>
              <span className="row">
                <select
                  aria-label={`Estado de ${r.topic}`}
                  value={r.state}
                  onChange={(e) => {
                    const state = e.target.value; // ler já: o select controlado volta ao valor antigo depois do render
                    run(() => putItem(db, 'reviews', { ...r, state }));
                  }}
                >
                  {Object.entries(REVIEW).map(([k, v]) => (
                    <option key={k} value={k}>
                      {v}
                    </option>
                  ))}
                </select>
                <button
                  className="btn danger"
                  onClick={() => {
                    run(() => removeItem(db, 'reviews', r.id));
                  }}
                >
                  Excluir {r.topic}
                </button>
              </span>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

function Notes({ db, data, reload }: Props) {
  const { error, run } = useAction(reload);
  const [title, setTitle] = useState('');
  const [text, setText] = useState('');
  const [color, setColor] = useState('#c9a24a');
  const [subject, setSubject] = useState('');
  return (
    <>
      <form
        className="panel row"
        onSubmit={submit(() => {
          run(async () => {
            await putItem(db, 'notes', {
              id: newId(),
              title,
              text,
              color,
              ...opt(subject),
              createdAt: Date.now(),
            });
            setTitle('');
            setText('');
          });
        })}
      >
        <label>
          Título
          <input
            value={title}
            maxLength={100}
            required
            onChange={(e) => {
              setTitle(e.target.value);
            }}
          />
        </label>
        <label>
          Texto
          <textarea
            value={text}
            maxLength={5000}
            rows={3}
            onChange={(e) => {
              setText(e.target.value);
            }}
          />
        </label>
        <label>
          Cor
          <input
            type="color"
            value={color}
            onChange={(e) => {
              setColor(e.target.value);
            }}
          />
        </label>
        <SubjectSelect data={data} value={subject} onChange={setSubject} />
        <button className="btn primary" type="submit">
          Salvar anotação
        </button>
      </form>
      {error && (
        <p className="msg" role="alert">
          {error}
        </p>
      )}
      {data.notes.length === 0 ? (
        <p className="empty">Nenhuma anotação ainda.</p>
      ) : (
        <ul className="list">
          {[...data.notes]
            .sort((a, b) => b.createdAt - a.createdAt)
            .map((n) => (
              <li key={n.id} style={{ borderLeft: `4px solid ${n.color}` }}>
                <div>
                  <b>{n.title}</b>{' '}
                  <span className="muted">
                    {new Date(n.createdAt).toLocaleDateString('pt-BR')}
                    {n.subjectId ? `, ${subjectName(data, n.subjectId)}` : ''}
                  </span>
                  <p style={{ whiteSpace: 'pre-wrap' }}>{n.text}</p>
                </div>
                <button
                  className="btn danger"
                  onClick={() => {
                    run(() => removeItem(db, 'notes', n.id));
                  }}
                >
                  Excluir {n.title}
                </button>
              </li>
            ))}
        </ul>
      )}
    </>
  );
}

export function Organization(props: Props) {
  const [tab, setTab] = useState<(typeof TABS)[number]>('Agenda');
  return (
    <>
      <h1>Organização</h1>
      <div className="row tabs" role="tablist" aria-label="Seções">
        {TABS.map((t) => (
          <button
            key={t}
            role="tab"
            aria-selected={tab === t}
            className={`btn${tab === t ? ' primary' : ''}`}
            onClick={() => {
              setTab(t);
            }}
          >
            {t}
          </button>
        ))}
      </div>
      {tab === 'Agenda' && <Agenda {...props} />}
      {tab === 'Calendário' && <Calendar data={props.data} />}
      {tab === 'Metas' && <Goals {...props} />}
      {tab === 'Revisões' && <Reviews {...props} />}
      {tab === 'Anotações' && <Notes {...props} />}
    </>
  );
}
