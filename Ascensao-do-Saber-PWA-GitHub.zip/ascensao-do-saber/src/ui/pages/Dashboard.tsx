import { useState } from 'react';
import { levelProgress } from '../../domain/progression/rules';
import { derive, subjectName } from '../derived';
import { formatMinutes } from '../format';
import type { Data } from '../useData';

const STATUS = {
  completed: 'concluída',
  cancelled: 'cancelada',
  interrupted: 'interrompida',
} as const;
export function Dashboard({ data }: { data: Data }) {
  const [now] = useState(() => Date.now());
  const d = derive(data, now);
  const p = levelProgress(data.xp);
  const recent = [...data.sessions].sort((a, b) => b.startedAt - a.startedAt).slice(0, 5);
  const open = d.goalsView.filter((g) => g.status !== 'concluida').slice(0, 3);
  return (
    <>
      <h1>Ascensão do Saber</h1>
      <section className="panel hero" aria-label="Personagem">
        <h2>
          {data.profile.characterName}, nível {p.level}
        </h2>
        <progress max={p.needed} value={p.intoLevel} aria-label="Progresso para o próximo nível" />
        <p className="muted">
          {p.intoLevel} / {p.needed} XP para o nível {p.level + 1} · {data.xp} XP no total
        </p>
      </section>
      <div className="grid">
        <section className="panel stat">
          <span className="muted">Estudado hoje</span>
          <b>{formatMinutes(d.stats.today)}</b>
        </section>
        <section className="panel stat">
          <span className="muted">Na semana</span>
          <b>{formatMinutes(d.stats.week)}</b>
        </section>
        <section className="panel stat">
          <span className="muted">Sequência de dias</span>
          <b>{d.stats.current}</b>
        </section>
        <section className="panel stat">
          <span className="muted">Sessões registradas</span>
          <b>{data.sessions.length}</b>
        </section>
      </div>
      <section className="panel">
        <h2>Metas em andamento</h2>
        {open.length === 0 ? (
          <p className="empty">Nenhuma meta em andamento. Crie uma em Organização.</p>
        ) : (
          <ul className="list">
            {open.map(({ goal, value }) => (
              <li key={goal.id}>
                <span>{goal.title}</span>
                <span className="muted">
                  {value} / {goal.target}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
      <section className="panel">
        <h2>Resumo das matérias</h2>
        {d.stats.bySubject.size === 0 ? (
          <p className="empty">Nenhum tempo registrado por matéria ainda.</p>
        ) : (
          <ul className="list">
            {[...d.stats.bySubject]
              .sort((a, b) => b[1] - a[1])
              .map(([id, ms]) => (
                <li key={id}>
                  <span>{subjectName(data, id)}</span>
                  <span className="muted">{formatMinutes(ms)}</span>
                </li>
              ))}
          </ul>
        )}
      </section>
      <section className="panel">
        <h2>Últimas sessões</h2>
        {recent.length === 0 ? (
          <p className="empty">Nenhuma sessão ainda. Vá em Estudo e inicie a primeira.</p>
        ) : (
          <ul className="list">
            {recent.map((s) => (
              <li key={s.id}>
                <span>
                  {subjectName(data, s.subjectId)}
                  {s.topic ? ` · ${s.topic}` : ''}
                </span>
                <span className="muted">
                  {formatMinutes(s.activeMs)}, {STATUS[s.status]}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
