import { useEffect, useMemo, useRef, useState } from 'react';
import {
  cancelTimer,
  elapsedMs,
  finishTimer,
  pauseTimer,
  resumeTimer,
  startTimer,
  type TimerState,
} from '../../domain/timer/timer';
import type { Db } from '../../infrastructure/db/db';
import { finalizeSession, saveActiveTimer } from '../../infrastructure/db/repository';
import { announceDone } from '../alerts';
import { formatClock, formatMinutes } from '../format';
import type { Data } from '../useData';

type Mode = 'livre' | 'pomodoro' | 'custom';

export function Study({ db, data, reload }: { db: Db; data: Data; reload: () => Promise<void> }) {
  const [choice, setChoice] = useState('');
  const [mode, setMode] = useState<Mode>('livre');
  const [customMin, setCustomMin] = useState(45);
  const [topic, setTopic] = useState('');
  const [now, setNow] = useState(() => Date.now());
  const [error, setError] = useState<string | null>(null);
  const doneRef = useRef(false);
  const active = data.active;
  const state = useMemo<TimerState>(() => (active ? active.state : { status: 'idle' }), [active]);
  const target = active?.targetMs;

  useEffect(() => {
    if (state.status !== 'running' || !active) {
      doneRef.current = false;
      return;
    }
    const timer = setInterval(() => {
      const n = Date.now();
      setNow(n);
      // Registro automático ao atingir a duração escolhida (limitada ao alvo, mesmo com a aba em segundo plano).
      if (target !== undefined && !doneRef.current && elapsedMs(state, n) >= target) {
        doneRef.current = true;
        const s = finishTimer(state, n).session;
        finalizeSession(
          db,
          active.subjectId,
          { ...s, activeMs: Math.min(s.activeMs, target) },
          false,
          active.topic,
        )
          .then(() => {
            if (data.profile.alerts) announceDone();
          })
          .then(reload)
          .catch(() => {
            setError('Não foi possível registrar a sessão concluída.');
          });
      }
    }, 250);
    return () => {
      clearInterval(timer);
    };
  }, [state, active, target, db, reload, data.profile.alerts]);

  const act = (task: (t: number) => Promise<unknown>) => {
    const t = Date.now();
    setError(null);
    setNow(t);
    task(t)
      .then(reload)
      .catch(() => {
        setError('Não foi possível concluir a ação. Tente de novo.');
      });
  };
  const subjectId = active?.subjectId ?? (choice || data.subjects[0]?.id);
  const subjectName = data.subjects.find((s) => s.id === subjectId)?.name;
  const startTarget =
    mode === 'pomodoro'
      ? data.profile.pomodoroMinutes * 60_000
      : mode === 'custom'
        ? customMin * 60_000
        : undefined;

  if (data.subjects.length === 0)
    return (
      <>
        <h1>Estudo</h1>
        <p className="empty">Crie uma matéria em Matérias antes de iniciar uma sessão.</p>
      </>
    );
  const elapsed = elapsedMs(state, state.status === 'running' ? now : 0);
  return (
    <>
      <h1>Estudo</h1>
      <section className="panel" aria-label="Cronômetro">
        {error && (
          <p className="msg" role="alert">
            {error}
          </p>
        )}
        <div className="row">
          <label>
            Matéria
            <select
              value={subjectId ?? ''}
              disabled={state.status !== 'idle'}
              onChange={(e) => {
                setChoice(e.target.value);
              }}
            >
              {data.subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            Modo
            <select
              value={mode}
              disabled={state.status !== 'idle'}
              onChange={(e) => {
                setMode(e.target.value as Mode);
              }}
            >
              <option value="livre">Cronômetro livre</option>
              <option value="pomodoro">Pomodoro ({data.profile.pomodoroMinutes} min)</option>
              <option value="custom">Duração personalizada</option>
            </select>
          </label>
          <label>
            Assunto (opcional)
            <input
              value={active?.topic ?? topic}
              maxLength={80}
              disabled={state.status !== 'idle'}
              onChange={(e) => {
                setTopic(e.target.value);
              }}
            />
          </label>
          {mode === 'custom' && (
            <label>
              Minutos
              <input
                type="number"
                min={1}
                max={600}
                value={customMin}
                disabled={state.status !== 'idle'}
                onChange={(e) => {
                  setCustomMin(Math.min(600, Math.max(1, Number(e.target.value) || 1)));
                }}
              />
            </label>
          )}
        </div>
        <p className="clock" role="timer" aria-label="Tempo da sessão">
          {formatClock(elapsed)}
        </p>
        <p className="muted">
          {state.status === 'idle' && 'Pronto para começar.'}
          {state.status === 'running' && `Estudando ${subjectName ?? ''}.`}
          {state.status === 'paused' && 'Sessão pausada.'}
          {target !== undefined && ` Duração da sessão: ${formatMinutes(target)}.`}
        </p>
        <div className="row">
          {state.status === 'idle' && subjectId && (
            <button
              className="btn primary"
              onClick={() => {
                act((t) =>
                  saveActiveTimer(
                    db,
                    subjectId,
                    startTimer(t),
                    startTarget,
                    topic.trim() || undefined,
                  ),
                );
              }}
            >
              Iniciar sessão
            </button>
          )}
          {state.status === 'running' && active && (
            <button
              className="btn"
              onClick={() => {
                act((t) =>
                  saveActiveTimer(db, active.subjectId, pauseTimer(state, t), target, active.topic),
                );
              }}
            >
              Pausar
            </button>
          )}
          {state.status === 'paused' && active && (
            <button
              className="btn"
              onClick={() => {
                act((t) =>
                  saveActiveTimer(
                    db,
                    active.subjectId,
                    resumeTimer(state, t),
                    target,
                    active.topic,
                  ),
                );
              }}
            >
              Retomar
            </button>
          )}
          {state.status !== 'idle' && active && (
            <>
              <button
                className="btn primary"
                onClick={() => {
                  act((t) =>
                    finalizeSession(
                      db,
                      active.subjectId,
                      finishTimer(state, t).session,
                      false,
                      active.topic,
                    ),
                  );
                }}
              >
                Finalizar sessão
              </button>
              <button
                className="btn danger"
                onClick={() => {
                  act((t) =>
                    finalizeSession(
                      db,
                      active.subjectId,
                      cancelTimer(state, t).session,
                      false,
                      active.topic,
                    ),
                  );
                }}
              >
                Cancelar sessão
              </button>
            </>
          )}
        </div>
        <p className="muted">
          Sessões com menos de 5 minutos, canceladas ou interrompidas não geram XP.
        </p>
      </section>
    </>
  );
}
