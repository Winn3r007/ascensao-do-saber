import { useState } from 'react';
import { xpForSession } from '../../domain/progression/rules';
import type { Db } from '../../infrastructure/db/db';
import { deleteSession } from '../../infrastructure/db/repository';
import { subjectName } from '../derived';
import { formatMinutes } from '../format';
import { useAction } from '../useAction';
import type { Data } from '../useData';

const STATUS = {
  completed: 'concluída',
  cancelled: 'cancelada',
  interrupted: 'interrompida',
} as const;
export function History({ db, data, reload }: { db: Db; data: Data; reload: () => Promise<void> }) {
  const { error, run } = useAction(reload);
  const [pending, setPending] = useState<string | null>(null);
  const list = [...data.sessions].sort((a, b) => b.startedAt - a.startedAt);
  return (
    <>
      {error && (
        <p className="msg" role="alert">
          {error}
        </p>
      )}
      {list.length === 0 ? (
        <p className="empty">Nenhuma sessão registrada ainda.</p>
      ) : (
        <ul className="plain cards">
          {list.map((s) => (
            <li key={s.id}>
              <span>
                {subjectName(data, s.subjectId)}
                {s.topic ? ` · ${s.topic}` : ''}{' '}
                <span className="muted small">
                  {new Date(s.startedAt).toLocaleString('pt-BR', {
                    dateStyle: 'short',
                    timeStyle: 'short',
                  })}
                  , {formatMinutes(s.activeMs)}, {STATUS[s.status]}
                  {xpForSession(s) > 0 ? `, +${String(xpForSession(s))} XP` : ''}
                </span>
              </span>
              {pending === s.id ? (
                <span className="row">
                  <span className="small">Excluir esta sessão remove também o XP dela.</span>
                  <button
                    className="btn danger"
                    onClick={() => {
                      setPending(null);
                      run(() => deleteSession(db, s.id), 'Não foi possível excluir a sessão.');
                    }}
                  >
                    Confirmar exclusão da sessão
                  </button>
                  <button
                    className="btn"
                    onClick={() => {
                      setPending(null);
                    }}
                  >
                    Cancelar
                  </button>
                </span>
              ) : (
                <button
                  className="btn danger"
                  onClick={() => {
                    setPending(s.id);
                  }}
                >
                  Excluir sessão
                </button>
              )}
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
