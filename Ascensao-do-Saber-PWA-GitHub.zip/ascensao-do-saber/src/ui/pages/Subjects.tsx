import { useState } from 'react';
import type { Db } from '../../infrastructure/db/db';
import { addSubject, deleteSubject } from '../../infrastructure/db/repository';
import type { Data } from '../useData';

export function Subjects({
  db,
  data,
  reload,
}: {
  db: Db;
  data: Data;
  reload: () => Promise<void>;
}) {
  const [name, setName] = useState('');
  const [color, setColor] = useState('#5b9bd5');
  const [error, setError] = useState<string | null>(null);

  const run = (task: Promise<unknown>, failure: string) => {
    setError(null);
    task.then(reload).catch((e: unknown) => {
      setError(e instanceof Error && e.message.includes('sessões') ? e.message : failure);
    });
  };

  return (
    <>
      <h1>Matérias</h1>
      <form
        className="panel row"
        onSubmit={(e) => {
          e.preventDefault();
          run(
            addSubject(db, { name, color }).then(() => {
              setName('');
            }),
            'Informe um nome de 1 a 60 caracteres.',
          );
        }}
      >
        <label>
          Nome da matéria
          <input
            value={name}
            maxLength={60}
            required
            onChange={(e) => {
              setName(e.target.value);
            }}
          />
        </label>
        <label>
          Cor
          <input
            type="color"
            value={color}
            onChange={(e) => {
              setColor(e.target.value);
            }}
          />
        </label>
        <button className="btn primary" type="submit">
          Adicionar matéria
        </button>
      </form>
      {error && (
        <p className="msg" role="alert">
          {error}
        </p>
      )}
      {data.subjects.length === 0 ? (
        <p className="empty">Nenhuma matéria ainda. Adicione a primeira para começar a estudar.</p>
      ) : (
        <ul className="list">
          {data.subjects.map((s) => (
            <li key={s.id}>
              <span>
                <span className="dot" style={{ background: s.color }} />
                {s.name}
              </span>
              <button
                className="btn danger"
                onClick={() => {
                  run(deleteSubject(db, s.id), 'Não foi possível excluir.');
                }}
              >
                Excluir {s.name}
              </button>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
