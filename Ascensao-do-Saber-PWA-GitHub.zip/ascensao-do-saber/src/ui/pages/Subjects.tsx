import { useState } from 'react';
import type { Db } from '../../infrastructure/db/db';
import { DELETED_ID, addSubject, deleteSubject } from '../../infrastructure/db/repository';
import { formatMinutes } from '../format';
import { useAction } from '../useAction';
import type { Data } from '../useData';

export function Subjects({
  db,
  data,
  reload,
}: {
  db: Db;
  data: Data;
  reload: () => Promise<void>;
}) {
  const { error, run } = useAction(reload);
  const [name, setName] = useState('');
  const [color, setColor] = useState('#89ceff');
  const [pending, setPending] = useState<string | null>(null);
  const time = (id: string) =>
    data.sessions
      .filter((s) => s.subjectId === id && s.status === 'completed')
      .reduce((a, s) => a + s.activeMs, 0);
  return (
    <>
      <form
        className="frame row"
        onSubmit={(e) => {
          e.preventDefault();
          run(async () => {
            await addSubject(db, { name, color });
            setName('');
          }, 'Informe um nome de 1 a 60 caracteres (não use "Sessão apagada").');
        }}
      >
        <label>
          Nome da matéria
          <input
            value={name}
            maxLength={60}
            required
            onChange={(e) => {
              setName(e.target.value);
            }}
          />
        </label>
        <label>
          Cor
          <input
            type="color"
            value={color}
            onChange={(e) => {
              setColor(e.target.value);
            }}
          />
        </label>
        <button className="btn primary" type="submit">
          Adicionar matéria
        </button>
      </form>
      {error && (
        <p className="msg" role="alert">
          {error}
        </p>
      )}
      {data.subjects.length === 0 ? (
        <p className="empty">Nenhuma matéria ainda. Adicione a primeira para começar a estudar.</p>
      ) : (
        <ul className="plain cards">
          {data.subjects.map((s) => (
            <li key={s.id}>
              <span>
                <span className="dot" style={{ background: s.color }} />
                {s.name} <span className="muted mono small">{formatMinutes(time(s.id))}</span>
              </span>
              {s.id === DELETED_ID ? (
                <span className="muted small">categoria automática</span>
              ) : pending === s.id ? (
                <span className="row">
                  <span className="small">As sessões serão movidas para "Sessão apagada".</span>
                  <button
                    className="btn danger"
                    onClick={() => {
                      setPending(null);
                      run(
                        () => deleteSubject(db, s.id),
                        'Não foi possível excluir (há uma sessão em andamento nesta matéria?).',
                      );
                    }}
                  >
                    Confirmar exclusão de {s.name}
                  </button>
                  <button
                    className="btn"
                    onClick={() => {
                      setPending(null);
                    }}
                  >
                    Cancelar
                  </button>
                </span>
              ) : (
                <button
                  className="btn danger"
                  onClick={() => {
                    setPending(s.id);
                  }}
                >
                  Excluir {s.name}
                </button>
              )}
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
