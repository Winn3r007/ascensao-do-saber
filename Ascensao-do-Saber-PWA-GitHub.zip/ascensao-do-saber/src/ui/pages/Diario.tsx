import { useState } from 'react';
import type { Db } from '../../infrastructure/db/db';
import { Tabs } from '../components/Tabs';
import type { Data } from '../useData';
import { Board } from './Board';
import { History } from './History';
import { Agenda, Calendar, Goals, Reviews } from './Organization';

const TABS = ['Histórico', 'Agenda', 'Calendário', 'Metas', 'Revisões', 'Quadro'] as const;
export function Diario(props: { db: Db; data: Data; reload: () => Promise<void> }) {
  const [tab, setTab] = useState<string>('Histórico');
  return (
    <>
      <h1>Diário</h1>
      <Tabs tabs={TABS} value={tab} onChange={setTab} />
      {tab === 'Histórico' && <History {...props} />}
      {tab === 'Agenda' && <Agenda {...props} />}
      {tab === 'Calendário' && <Calendar data={props.data} />}
      {tab === 'Metas' && <Goals {...props} />}
      {tab === 'Revisões' && <Reviews {...props} />}
      {tab === 'Quadro' && <Board {...props} />}
    </>
  );
}
