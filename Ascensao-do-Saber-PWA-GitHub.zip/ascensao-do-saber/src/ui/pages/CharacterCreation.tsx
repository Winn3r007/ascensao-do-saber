import { useState } from 'react';
import type { Db } from '../../infrastructure/db/db';
import { saveProfile } from '../../infrastructure/db/items';
import { Portrait, VARIANTS, type VariantId } from '../components/Portrait';
import { useAction } from '../useAction';
import type { Data } from '../useData';
import imageUrl from '../../assets/logo.png';

// Criação (primeiro acesso) e edição posterior do personagem: mesmo formulário, mesma persistência.
export function CharacterCreation({
  db,
  data,
  reload,
  editing = false,
}: {
  db: Db;
  data: Data;
  reload: () => Promise<void>;
  editing?: boolean;
}) {
  const { error, run } = useAction(reload);
  const [name, setName] = useState(data.profile.created ? data.profile.characterName : '');
  const [variant, setVariant] = useState<VariantId>(data.profile.appearance?.variant ?? 'original');
  const form = (
    <form
      className={editing ? 'frame' : 'frame creation'}
      onSubmit={(e) => {
        e.preventDefault();
        run(
          () =>
            saveProfile(db, {
              ...data.profile,
              key: 'profile',
              characterName: name,
              appearance: { variant },
              created: true,
            }),
          'Escolha um nome de 1 a 30 caracteres.',
        );
      }}
    >
      {!editing && <img className="creation-logo" src={imageUrl} alt="Ascensão do Saber" />}
      <h1>{editing ? 'Seu personagem' : 'Crie seu personagem'}</h1>
      {!editing && (
        <p className="muted">
          Todo grande escriba começa com um nome. Escolha o seu e a aparência que o acompanhará pelo
          Reino.
        </p>
      )}
      {error && (
        <p className="msg" role="alert">
          {error}
        </p>
      )}
      <label>
        Nome do personagem
        <input
          value={name}
          maxLength={30}
          required
          autoFocus={!editing}
          onChange={(e) => {
            setName(e.target.value);
          }}
        />
      </label>
      <fieldset className="variants">
        <legend>Aparência</legend>
        {VARIANTS.map((v) => (
          <label key={v.id} className={variant === v.id ? 'variant on' : 'variant'}>
            <input
              type="radio"
              name="variant"
              value={v.id}
              checked={variant === v.id}
              onChange={() => {
                setVariant(v.id);
              }}
            />
            <Portrait variant={v.id} small />
            <span>{v.name}</span>
          </label>
        ))}
      </fieldset>
      <button className="btn primary" type="submit">
        {editing ? 'Salvar personagem' : 'Entrar no Santuário'}
      </button>
    </form>
  );
  return editing ? form : <main className="creation-screen">{form}</main>;
}
