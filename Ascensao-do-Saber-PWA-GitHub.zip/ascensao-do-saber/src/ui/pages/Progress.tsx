import { useState } from 'react';
import { ATTRIBUTE_RULES, computeAttributes } from '../../domain/attributes/attributes';
import { levelFromXp, levelProgress, xpForSession } from '../../domain/progression/rules';
import { derive, subjectName } from '../derived';
import type { Data } from '../useData';

export function Progress({ data }: { data: Data }) {
  const [now] = useState(() => Date.now());
  const d = derive(data, now);
  const p = levelProgress(data.xp);
  const attrs = computeAttributes({
    completedSessions: d.completed,
    reviewsMastered: d.reviewsMastered,
    goalsDone: d.goalsDone,
    tasksDone: d.tasksDone,
    longestStreak: d.stats.longest,
  });
  const bySubject = new Map<string, number>();
  for (const s of data.sessions)
    bySubject.set(s.subjectId, (bySubject.get(s.subjectId) ?? 0) + xpForSession(s));
  return (
    <>
      <h1>Progressão</h1>
      <section className="panel hero">
        <h2>
          {data.profile.characterName}, nível {p.level}
        </h2>
        <progress max={p.needed} value={p.intoLevel} aria-label="Progresso para o próximo nível" />
        <p className="muted">
          {p.intoLevel} / {p.needed} XP para o nível {p.level + 1}. XP total: {data.xp}.
        </p>
      </section>
      <section className="panel">
        <h2>Habilidades (uma por matéria)</h2>
        {data.subjects.length === 0 ? (
          <p className="empty">Crie matérias para desenvolver habilidades.</p>
        ) : (
          <ul className="list">
            {data.subjects.map((s) => {
              const xp = bySubject.get(s.id) ?? 0;
              return (
                <li key={s.id}>
                  <span>
                    <span className="dot" style={{ background: s.color }} />
                    {subjectName(data, s.id)}
                  </span>
                  <span className="muted">
                    nível {levelFromXp(xp)}, {xp} XP
                  </span>
                </li>
              );
            })}
          </ul>
        )}
      </section>
      <section className="panel">
        <h2>Atributos</h2>
        <ul className="list">
          {ATTRIBUTE_RULES.map((a) => (
            <li key={a.id}>
              <span>
                <b>{a.name}</b> <span className="muted">{a.rule}</span>
              </span>
              <b>{attrs[a.id]}</b>
            </li>
          ))}
        </ul>
      </section>
      <p className="muted">
        Talentos e classes ainda não existem: estão previstos para uma fase futura.
      </p>
    </>
  );
}
