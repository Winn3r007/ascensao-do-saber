import { useState } from 'react';
import { ATTRIBUTE_RULES, computeAttributes } from '../../domain/attributes/attributes';
import { levelProgress } from '../../domain/progression/rules';
import { isoDay } from '../../domain/stats/summary';
import { Portrait } from '../components/Portrait';
import { derive, subjectName } from '../derived';
import { formatMinutes } from '../format';
import type { Data } from '../useData';

const STATUS = {
  completed: 'concluída',
  cancelled: 'cancelada',
  interrupted: 'interrompida',
} as const;

export function Sanctuary({
  data,
  go,
}: {
  data: Data;
  go: (page: 'expedicao' | 'diario') => void;
}) {
  const [now] = useState(() => Date.now());
  const d = derive(data, now);
  const p = levelProgress(data.xp);
  const attrs = computeAttributes({
    completedSessions: d.completed,
    reviewsMastered: d.reviewsMastered,
    goalsDone: d.goalsDone,
    tasksDone: d.tasksDone,
    longestStreak: d.stats.longest,
  });
  const recent = [...data.sessions].sort((a, b) => b.startedAt - a.startedAt).slice(0, 5);
  const open = d.goalsView.filter((g) => g.status !== 'concluida').slice(0, 3);
  const today = isoDay(now);
  const due = data.events
    .filter((e) => (e.kind === 'prova' || e.kind === 'trabalho') && !e.done && e.date >= today)
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, 3);
  return (
    <div className="sanctuary">
      <section className="char" aria-label="Personagem">
        <h1>{data.profile.characterName}</h1>
        <p className="lvl">
          <span className="badge">Nv. {p.level}</span> <span className="muted">Escriba Arcano</span>
        </p>
        <progress max={p.needed} value={p.intoLevel} aria-label="Progresso para o próximo nível" />
        <p className="mono small">
          {p.intoLevel} / {p.needed} XP · {data.xp} XP no total
        </p>
        <div className="frame">
          <Portrait variant={data.profile.appearance?.variant ?? 'original'} />
          <h2 className="eyebrow">Atributos</h2>
          <ul className="attrs">
            {ATTRIBUTE_RULES.map((a) => (
              <li key={a.id} title={a.rule}>
                <span>{a.name}</span>
                <b className="mono">{attrs[a.id]}</b>
              </li>
            ))}
          </ul>
        </div>
      </section>
      <section className="center" aria-label="Expedição">
        <h2 className="hero-title">Pronto para a próxima expedição?</h2>
        <button
          className="btn primary big"
          onClick={() => {
            go('expedicao');
          }}
        >
          Iniciar expedição
        </button>
        <h2 className="eyebrow">Últimas expedições</h2>
        {recent.length === 0 ? (
          <p className="muted">Nenhuma sessão ainda. Inicie a primeira expedição.</p>
        ) : (
          <ul className="plain">
            {recent.map((s) => (
              <li key={s.id}>
                <span>
                  {subjectName(data, s.subjectId)}
                  {s.topic ? ` · ${s.topic}` : ''}
                </span>
                <span className="muted">
                  {formatMinutes(s.activeMs)}, {STATUS[s.status]}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
      <aside className="missions frame" aria-label="Missões ativas">
        <h2>Missões ativas</h2>
        {open.length === 0 && due.length === 0 ? (
          <p className="muted">Nenhuma meta ou prova em aberto. Crie metas no Diário.</p>
        ) : (
          <ul className="plain">
            {open.map(({ goal, value }) => (
              <li key={goal.id}>
                <span>{goal.title}</span>
                <span className="mono small">
                  {value} / {goal.target}
                </span>
              </li>
            ))}
            {due.map((e) => (
              <li key={e.id}>
                <span>{e.title}</span>
                <span className="muted small">{e.date}</span>
              </li>
            ))}
          </ul>
        )}
        <div className="stats3">
          <div>
            <b className="mono">{formatMinutes(d.stats.total)}</b>
            <span>Tempo foco</span>
          </div>
          <div>
            <b className="mono">{d.stats.current}d</b>
            <span>Dias chama</span>
          </div>
          <div>
            <b className="mono">{data.xp}</b>
            <span>XP</span>
          </div>
        </div>
        <button
          className="btn"
          onClick={() => {
            go('diario');
          }}
        >
          Abrir o Diário
        </button>
      </aside>
    </div>
  );
}
