import { useState } from 'react';
import type { Db } from '../../infrastructure/db/db';
import { Tabs } from '../components/Tabs';
import type { Data } from '../useData';
import { Progress } from './Progress';
import { Stats } from './Stats';
import { Subjects } from './Subjects';

const TABS = ['Matérias', 'Habilidades', 'Estatísticas'] as const;
export function Grimorio(props: { db: Db; data: Data; reload: () => Promise<void> }) {
  const [tab, setTab] = useState<string>('Matérias');
  return (
    <>
      <h1>Grimório</h1>
      <Tabs tabs={TABS} value={tab} onChange={setTab} />
      {tab === 'Matérias' && <Subjects {...props} />}
      {tab === 'Habilidades' && <Progress data={props.data} />}
      {tab === 'Estatísticas' && <Stats data={props.data} />}
    </>
  );
}
