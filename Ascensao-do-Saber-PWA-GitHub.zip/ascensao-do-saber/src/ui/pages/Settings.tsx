import { useState } from 'react';
import {
  BackupError,
  MAX_BACKUP_BYTES,
  deleteAllData,
  exportBackup,
  importBackup,
} from '../../infrastructure/backup/backup';
import type { Db } from '../../infrastructure/db/db';
import { saveProfile } from '../../infrastructure/db/items';
import { useAction } from '../useAction';
import type { Data } from '../useData';

export function Settings({
  db,
  data,
  reload,
}: {
  db: Db;
  data: Data;
  reload: () => Promise<void>;
}) {
  const { error, run } = useAction(reload);
  const [name, setName] = useState(data.profile.characterName);
  const [pomo, setPomo] = useState(data.profile.pomodoroMinutes);
  const [alerts, setAlerts] = useState(data.profile.alerts ?? false);
  const [msg, setMsg] = useState<string | null>(null);
  const [confirm, setConfirm] = useState('');
  const [replace, setReplace] = useState(false);

  const download = () => {
    exportBackup(db)
      .then((text) => {
        const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
        const a = document.createElement('a');
        a.href = url;
        a.download = `ascensao-do-saber-backup-${new Date().toISOString().slice(0, 10)}.json`;
        a.click();
        URL.revokeObjectURL(url);
        setMsg('Backup exportado.');
      })
      .catch(() => {
        setMsg('Não foi possível exportar.');
      });
  };
  const upload = (file: File | undefined) => {
    if (!file) return;
    if (file.size > MAX_BACKUP_BYTES) {
      setMsg('Arquivo grande demais (máximo 5 MB).');
      return;
    }
    file
      .text()
      .then((t) => importBackup(db, t))
      .then(reload)
      .then(() => {
        setMsg('Backup importado.');
        setReplace(false);
      })
      .catch((e: unknown) => {
        setMsg(e instanceof BackupError ? e.message : 'Não foi possível importar o arquivo.');
      });
  };
  return (
    <>
      <h1>Configurações</h1>
      {error && (
        <p className="msg" role="alert">
          {error}
        </p>
      )}
      <form
        className="panel row"
        onSubmit={(e) => {
          e.preventDefault();
          run(() =>
            saveProfile(db, { key: 'profile', characterName: name, pomodoroMinutes: pomo, alerts }),
          );
        }}
      >
        <label>
          Nome do personagem
          <input
            value={name}
            maxLength={30}
            required
            onChange={(e) => {
              setName(e.target.value);
            }}
          />
        </label>
        <label>
          Duração do Pomodoro (min)
          <input
            type="number"
            min={1}
            max={180}
            value={pomo}
            onChange={(e) => {
              setPomo(Number(e.target.value));
            }}
          />
        </label>
        <label>
          <span>
            <input
              type="checkbox"
              checked={alerts}
              onChange={(e) => {
                setAlerts(e.target.checked);
                if (
                  e.target.checked &&
                  'Notification' in window &&
                  Notification.permission === 'default'
                ) {
                  void Notification.requestPermission();
                }
              }}
            />{' '}
            Avisar ao concluir uma sessão (som e notificação do navegador)
          </span>
        </label>
        <button className="btn primary" type="submit">
          Salvar configurações
        </button>
      </form>
      <section className="panel">
        <h2>Backup</h2>
        <p className="muted">
          Seus dados ficam apenas neste navegador, sem criptografia. XP e conquistas são
          recalculados a partir das sessões ao importar.
        </p>
        {msg && <p role="status">{msg}</p>}
        <div className="row">
          <button className="btn" onClick={download}>
            Exportar backup
          </button>
        </div>
        <label>
          <span>
            <input
              type="checkbox"
              checked={replace}
              onChange={(e) => {
                setReplace(e.target.checked);
              }}
            />{' '}
            Entendo que importar substitui todos os dados atuais
          </span>
        </label>
        <label>
          Arquivo de backup (.json)
          <input
            type="file"
            accept="application/json,.json"
            disabled={!replace}
            onChange={(e) => {
              upload(e.target.files?.[0]);
              e.target.value = '';
            }}
          />
        </label>
      </section>
      <section className="panel">
        <h2>Excluir todos os dados</h2>
        <p className="muted">Ação permanente. Digite EXCLUIR para confirmar.</p>
        <div className="row">
          <input
            aria-label="Confirmação"
            value={confirm}
            onChange={(e) => {
              setConfirm(e.target.value);
            }}
          />
          <button
            className="btn danger"
            disabled={confirm !== 'EXCLUIR'}
            onClick={() => {
              run(async () => {
                await deleteAllData(db);
                setConfirm('');
                setMsg('Dados excluídos.');
              });
            }}
          >
            Excluir tudo
          </button>
        </div>
      </section>
    </>
  );
}
