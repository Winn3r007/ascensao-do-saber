import { useRef, useState, type KeyboardEvent, type PointerEvent } from 'react';
import type { Db } from '../../infrastructure/db/db';
import { newId, putItem, removeItem } from '../../infrastructure/db/items';
import type { Note } from '../../validation/schemas';
import { useAction } from '../useAction';
import type { Data } from '../useData';

const SWATCHES = ['#fff3a3', '#ffc6d9', '#bde8ff', '#c8f5c0', '#ffd9a8', '#e3d1ff'];
const W = 190;

// Quadro branco de post-its: arrastar (mouse/toque/teclado), editar no próprio papel, cor, excluir. Tudo persiste.
export function Board({ db, data, reload }: { db: Db; data: Data; reload: () => Promise<void> }) {
  const { error, run } = useAction(reload);
  const boardRef = useRef<HTMLDivElement>(null);
  const off = useRef({ dx: 0, dy: 0 });
  const [drag, setDrag] = useState<{ id: string; x: number; y: number } | null>(null);
  const [color, setColor] = useState(SWATCHES[0] ?? '#fff3a3');
  const [pendingDel, setPendingDel] = useState<string | null>(null);
  const place = (n: Note, i: number) => ({
    x: n.x ?? 20 + (i % 4) * (W + 20),
    y: n.y ?? 20 + Math.floor(i / 4) * 200,
  });
  const clamp = (x: number, y: number) => {
    const b = boardRef.current;
    return {
      x: Math.round(Math.min(Math.max(0, x), (b?.clientWidth ?? 900) - W)),
      y: Math.round(Math.min(Math.max(0, y), (b?.clientHeight ?? 500) - 60)),
    };
  };
  const down = (e: PointerEvent<HTMLDivElement>, n: Note, i: number) => {
    const r = boardRef.current?.getBoundingClientRect();
    if (!r) return;
    const p = place(n, i);
    off.current = { dx: e.clientX - r.left - p.x, dy: e.clientY - r.top - p.y };
    e.currentTarget.setPointerCapture(e.pointerId);
    setDrag({ id: n.id, ...p });
  };
  const move = (e: PointerEvent<HTMLDivElement>, n: Note) => {
    const r = boardRef.current?.getBoundingClientRect();
    if (drag?.id === n.id && r)
      setDrag({
        id: n.id,
        ...clamp(e.clientX - r.left - off.current.dx, e.clientY - r.top - off.current.dy),
      });
  };
  const up = (n: Note) => {
    if (drag?.id !== n.id) return;
    const { x, y } = drag;
    setDrag(null);
    run(() => putItem(db, 'notes', { ...n, x, y }));
  };
  const key = (e: KeyboardEvent<HTMLDivElement>, n: Note, i: number) => {
    const step = e.shiftKey ? 40 : 10;
    const d: Record<string, [number, number]> = {
      ArrowLeft: [-step, 0],
      ArrowRight: [step, 0],
      ArrowUp: [0, -step],
      ArrowDown: [0, step],
    };
    const v = d[e.key];
    if (!v) return;
    e.preventDefault();
    const p = place(n, i);
    const next = clamp(p.x + v[0], p.y + v[1]);
    run(() => putItem(db, 'notes', { ...n, ...next }));
  };
  const add = () => {
    const i = data.notes.length;
    const p = clamp(20 + (i % 4) * (W + 20), 20 + Math.floor(i / 4) * 200);
    run(() =>
      putItem(db, 'notes', {
        id: newId(),
        title: 'Post-it',
        text: '',
        color,
        ...p,
        createdAt: Date.now(),
      }),
    );
  };
  return (
    <>
      <div className="row board-bar">
        <button className="btn primary" onClick={add}>
          Novo post-it
        </button>
        <span className="row" role="radiogroup" aria-label="Cor do novo post-it">
          {SWATCHES.map((c) => (
            <button
              key={c}
              role="radio"
              aria-checked={color === c}
              aria-label={`Cor ${c}`}
              className={color === c ? 'swatch on' : 'swatch'}
              style={{ background: c }}
              onClick={() => {
                setColor(c);
              }}
            />
          ))}
        </span>
        <span className="muted small">
          Arraste pelo cabeçalho (ou use as setas com o foco nele). Clique no papel para escrever.
        </span>
      </div>
      {error && (
        <p className="msg" role="alert">
          {error}
        </p>
      )}
      <div className="board" ref={boardRef}>
        {data.notes.length === 0 && (
          <p className="board-empty">O quadro está vazio. Crie o primeiro post-it.</p>
        )}
        {data.notes.map((n, i) => {
          const p = drag?.id === n.id ? drag : place(n, i);
          return (
            <div
              key={n.id}
              className={drag?.id === n.id ? 'postit dragging' : 'postit'}
              style={{ left: p.x, top: p.y, background: n.color, width: W }}
            >
              <div
                className="postit-head"
                role="button"
                tabIndex={0}
                aria-label={`Mover post-it ${n.title}`}
                onPointerDown={(e) => {
                  down(e, n, i);
                }}
                onPointerMove={(e) => {
                  move(e, n);
                }}
                onPointerUp={() => {
                  up(n);
                }}
                onKeyDown={(e) => {
                  key(e, n, i);
                }}
              >
                <span className="postit-title">{n.title}</span>
                {pendingDel === n.id ? (
                  <span>
                    <button
                      className="mini"
                      aria-label={`Confirmar exclusão do post-it ${n.title}`}
                      onPointerDown={(e) => {
                        e.stopPropagation();
                      }}
                      onClick={() => {
                        setPendingDel(null);
                        run(() => removeItem(db, 'notes', n.id));
                      }}
                    >
                      Excluir?
                    </button>
                    <button
                      className="mini"
                      aria-label="Cancelar"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                      }}
                      onClick={() => {
                        setPendingDel(null);
                      }}
                    >
                      Não
                    </button>
                  </span>
                ) : (
                  <button
                    className="mini"
                    aria-label={`Excluir post-it ${n.title}`}
                    onPointerDown={(e) => {
                      e.stopPropagation();
                    }}
                    onClick={() => {
                      setPendingDel(n.id);
                    }}
                  >
                    ×
                  </button>
                )}
              </div>
              <textarea
                aria-label={`Texto do post-it ${n.title}`}
                defaultValue={n.text}
                maxLength={500}
                placeholder="Escreva aqui…"
                onBlur={(e) => {
                  const text = e.target.value;
                  if (text !== n.text) run(() => putItem(db, 'notes', { ...n, text }));
                }}
              />
              <div className="postit-colors">
                {SWATCHES.map((c) => (
                  <button
                    key={c}
                    aria-label={`Mudar cor para ${c}`}
                    className="swatch tiny"
                    style={{ background: c }}
                    onClick={() => {
                      run(() => putItem(db, 'notes', { ...n, color: c }));
                    }}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}
