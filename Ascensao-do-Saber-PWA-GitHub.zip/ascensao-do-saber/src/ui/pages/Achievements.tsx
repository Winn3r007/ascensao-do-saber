import { ACHIEVEMENTS } from '../../domain/achievements/achievements';
import type { Data } from '../useData';

export function Achievements({ data }: { data: Data }) {
  const got = new Map(data.achievements.map((a) => [a.id, a.unlockedAt]));
  return (
    <>
      <h1>Conquistas</h1>
      <ul className="list">
        {ACHIEVEMENTS.map((a) => {
          const at = got.get(a.id);
          return (
            <li key={a.id}>
              <span>
                <b>{a.title}</b> <span className="muted">{a.description}</span>
              </span>
              <span className={at === undefined ? 'muted' : ''}>
                {at === undefined
                  ? 'Bloqueada'
                  : `Desbloqueada em ${new Date(at).toLocaleDateString('pt-BR')}`}
              </span>
            </li>
          );
        })}
      </ul>
    </>
  );
}
