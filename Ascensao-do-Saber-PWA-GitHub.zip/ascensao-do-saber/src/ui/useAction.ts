import { useState } from 'react';

// Executa uma ação assíncrona, recarrega os dados e mostra uma mensagem clara em caso de falha.
export function useAction(reload: () => Promise<void>) {
  const [error, setError] = useState<string | null>(null);
  const run = (task: () => Promise<unknown>, failure = 'Verifique os campos e tente de novo.') => {
    setError(null);
    Promise.resolve()
      .then(task)
      .then(reload)
      .catch(() => {
        setError(failure);
      });
  };
  return { error, run };
}
