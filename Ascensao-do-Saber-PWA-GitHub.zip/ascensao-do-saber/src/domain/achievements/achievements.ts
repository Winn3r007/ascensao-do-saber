export interface AchievementContext {
  completed: { subjectId: string; activeMs: number }[];
  goalsDone: number;
  reviewsMastered: number;
  longestStreak: number;
}
export const ACHIEVEMENTS = [
  {
    id: 'first-session',
    title: 'Primeira sessão',
    description: 'Conclua sua primeira sessão de estudo.',
    met: (c: AchievementContext) => c.completed.length >= 1,
  },
  {
    id: 'sessions-50',
    title: '50 sessões',
    description: 'Conclua 50 sessões de estudo.',
    met: (c: AchievementContext) => c.completed.length >= 50,
  },
  {
    id: 'streak-7',
    title: 'Primeira semana',
    description: 'Estude 7 dias seguidos.',
    met: (c: AchievementContext) => c.longestStreak >= 7,
  },
  {
    id: 'subject-10h',
    title: '10 horas em uma matéria',
    description: 'Acumule 10 horas em uma mesma matéria.',
    met: (c: AchievementContext) => {
      const by = new Map<string, number>();
      for (const s of c.completed) by.set(s.subjectId, (by.get(s.subjectId) ?? 0) + s.activeMs);
      return [...by.values()].some((ms) => ms >= 10 * 3_600_000);
    },
  },
  {
    id: 'first-goal',
    title: 'Primeira meta',
    description: 'Conclua sua primeira meta.',
    met: (c: AchievementContext) => c.goalsDone >= 1,
  },
  {
    id: 'first-mastered',
    title: 'Assunto dominado',
    description: 'Marque um assunto de revisão como dominado.',
    met: (c: AchievementContext) => c.reviewsMastered >= 1,
  },
] as const;
export const evaluateAchievements = (c: AchievementContext): string[] =>
  ACHIEVEMENTS.filter((a) => a.met(c)).map((a) => a.id);
