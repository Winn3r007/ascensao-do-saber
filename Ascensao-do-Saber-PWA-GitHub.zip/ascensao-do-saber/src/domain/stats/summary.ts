export interface SessionLike {
  subjectId: string;
  startedAt: number;
  endedAt: number;
  activeMs: number;
  status: string;
}

export const isoDay = (ts: number): string => {
  const d = new Date(ts);
  return `${String(d.getFullYear())}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
const dayNum = (key: string): number => {
  const [y, m, d] = key.split('-').map(Number);
  return Date.UTC(y ?? 0, (m ?? 1) - 1, d ?? 1) / 86_400_000;
};

// Divide uma sessão que atravessa a meia-noite, proporcionalmente ao tempo de relógio em cada dia.
export function splitByDay(
  startedAt: number,
  endedAt: number,
  activeMs: number,
): Map<string, number> {
  const out = new Map<string, number>();
  const wall = endedAt - startedAt;
  if (wall <= 0 || isoDay(startedAt) === isoDay(endedAt))
    return out.set(isoDay(startedAt), activeMs);
  let cursor = startedAt;
  while (cursor < endedAt) {
    const d = new Date(cursor);
    const next = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1).getTime();
    const end = Math.min(next, endedAt);
    out.set(isoDay(cursor), (out.get(isoDay(cursor)) ?? 0) + (activeMs * (end - cursor)) / wall);
    cursor = end;
  }
  return out;
}

export function streaks(
  days: ReadonlySet<string>,
  today: string,
): { current: number; longest: number } {
  const nums = [...days].map(dayNum).sort((a, b) => a - b);
  let longest = 0,
    run = 0,
    prev = Number.NaN;
  for (const n of nums) {
    run = n === prev + 1 ? run + 1 : 1;
    longest = Math.max(longest, run);
    prev = n;
  }
  const set = new Set(nums);
  let cursor = dayNum(today);
  if (!set.has(cursor)) cursor -= 1; // hoje ainda sem estudo não quebra a sequência
  let current = 0;
  while (set.has(cursor)) {
    current++;
    cursor--;
  }
  return { current, longest };
}

export function computeStats(sessions: readonly SessionLike[], now: number) {
  const done = sessions.filter((s) => s.status === 'completed');
  const perDay = new Map<string, number>();
  const bySubject = new Map<string, number>();
  const weekday = Array<number>(7).fill(0);
  const hour = Array<number>(24).fill(0);
  let total = 0;
  for (const s of done) {
    for (const [k, ms] of splitByDay(s.startedAt, s.endedAt, s.activeMs))
      perDay.set(k, (perDay.get(k) ?? 0) + ms);
    bySubject.set(s.subjectId, (bySubject.get(s.subjectId) ?? 0) + s.activeMs);
    const wd = new Date(s.startedAt).getDay();
    const hr = new Date(s.startedAt).getHours();
    weekday[wd] = (weekday[wd] ?? 0) + s.activeMs;
    hour[hr] = (hour[hr] ?? 0) + s.activeMs;
    total += s.activeMs;
  }
  const today = isoDay(now);
  const sumSince = (fromKey: string) =>
    [...perDay].filter(([k]) => k >= fromKey).reduce((a, [, v]) => a + v, 0);
  const weekStart = isoDay(now - 6 * 86_400_000);
  const monthStart = `${today.slice(0, 7)}-01`;
  const best = (a: number[]) => (Math.max(...a) > 0 ? a.indexOf(Math.max(...a)) : null);
  return {
    today: perDay.get(today) ?? 0,
    week: sumSince(weekStart),
    month: sumSince(monthStart),
    total,
    averagePerStudyDay: perDay.size ? total / perDay.size : 0,
    bySubject,
    weekday,
    hour,
    bestWeekday: best(weekday),
    bestHour: best(hour),
    ...streaks(new Set(perDay.keys()), today),
  };
}
