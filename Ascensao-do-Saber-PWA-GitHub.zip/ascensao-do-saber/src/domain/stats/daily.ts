// Dia LOCAL de uma sessão = dia local do início (divisão na meia-noite virá na Etapa de estatísticas).
export const localDayKey = (ts: number): string => {
  const d = new Date(ts);
  return `${String(d.getFullYear())}-${String(d.getMonth() + 1)}-${String(d.getDate())}`;
};

export function studiedMsOnDay(
  sessions: readonly { startedAt: number; activeMs: number; status: string }[],
  ts: number,
): number {
  const key = localDayKey(ts);
  return sessions
    .filter((s) => s.status === 'completed' && localDayKey(s.startedAt) === key)
    .reduce((sum, s) => sum + s.activeMs, 0);
}
