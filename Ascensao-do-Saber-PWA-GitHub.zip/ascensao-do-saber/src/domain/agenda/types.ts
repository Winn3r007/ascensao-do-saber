export interface EventType {
  id: string;
  name: string;
  color: string;
  builtin: boolean;
}
export const BUILTIN_TYPES: readonly EventType[] = [
  { id: 'compromisso', name: 'Compromisso', color: '#d98b4a', builtin: true },
  { id: 'prova', name: 'Prova', color: '#e0706b', builtin: true },
  { id: 'trabalho', name: 'Trabalho', color: '#5b9bd5', builtin: true },
  { id: 'lembrete', name: 'Lembrete', color: '#d878a8', builtin: true },
];
// Os tipos originais nunca somem; só a cor deles pode ser trocada. Tipos personalizados vêm do perfil.
export function resolveTypes(p: {
  eventTypes?: { id: string; name: string; color: string }[] | undefined;
  typeColors?: Record<string, string> | undefined;
}): EventType[] {
  const base = BUILTIN_TYPES.map((t) => ({ ...t, color: p.typeColors?.[t.id] ?? t.color }));
  return [
    ...base,
    ...(p.eventTypes ?? []).map((t) => ({
      ...t,
      color: p.typeColors?.[t.id] ?? t.color,
      builtin: false,
    })),
  ];
}
export const typeOf = (types: readonly EventType[], id: string): EventType =>
  types.find((t) => t.id === id) ?? { id, name: 'Tipo removido', color: '#7a7f87', builtin: false };
