import type { Goal } from '../../validation/schemas';
import type { SessionLike } from '../stats/summary';

export type GoalStatus = 'concluida' | 'atrasada' | 'em_andamento';
// Progresso 100% derivado das sessões concluídas depois da criação da meta (nada é digitado à mão).
export function goalProgress(goal: Goal, sessions: readonly SessionLike[], todayKey: string) {
  const value = sessions
    .filter(
      (s) =>
        s.status === 'completed' &&
        s.startedAt >= goal.createdAt &&
        (!goal.subjectId || s.subjectId === goal.subjectId),
    )
    .reduce((sum, s) => sum + (goal.metric === 'minutes' ? Math.floor(s.activeMs / 60_000) : 1), 0);
  const status: GoalStatus =
    value >= goal.target ? 'concluida' : goal.deadline < todayKey ? 'atrasada' : 'em_andamento';
  return { value, status };
}
