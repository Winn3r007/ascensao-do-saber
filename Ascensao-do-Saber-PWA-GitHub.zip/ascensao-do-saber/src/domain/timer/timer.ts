// Máquina de estados do cronômetro. Pura: o relógio entra como parâmetro (epoch ms).
export type TimerState =
  | { status: 'idle' }
  | { status: 'running'; startedAt: number; accumulatedMs: number; runningSince: number }
  | { status: 'paused'; startedAt: number; accumulatedMs: number };

export interface FinishedSession {
  startedAt: number;
  endedAt: number;
  activeMs: number;
  outcome: 'completed' | 'cancelled';
}

function assertTime(now: number): void {
  if (!Number.isFinite(now) || now < 0) throw new RangeError('Instante inválido.');
}
// Relógio que volta no tempo nunca gera duração negativa.
const span = (since: number, now: number): number => Math.max(0, now - since);

export const startTimer = (now: number): TimerState => {
  assertTime(now);
  return { status: 'running', startedAt: now, accumulatedMs: 0, runningSince: now };
};

export function pauseTimer(s: TimerState, now: number): TimerState {
  assertTime(now);
  if (s.status !== 'running') throw new Error('Só é possível pausar um cronômetro em execução.');
  return {
    status: 'paused',
    startedAt: s.startedAt,
    accumulatedMs: s.accumulatedMs + span(s.runningSince, now),
  };
}

export function resumeTimer(s: TimerState, now: number): TimerState {
  assertTime(now);
  if (s.status !== 'paused') throw new Error('Só é possível retomar um cronômetro pausado.');
  return { ...s, status: 'running', runningSince: now };
}

export function elapsedMs(s: TimerState, now: number): number {
  if (s.status === 'idle') return 0;
  if (s.status === 'paused') return s.accumulatedMs;
  return s.accumulatedMs + span(s.runningSince, now);
}

function close(
  s: TimerState,
  now: number,
  outcome: FinishedSession['outcome'],
): { state: TimerState; session: FinishedSession } {
  assertTime(now);
  if (s.status === 'idle') throw new Error('Nenhuma sessão em andamento.');
  const session = { startedAt: s.startedAt, endedAt: now, activeMs: elapsedMs(s, now), outcome };
  return { state: { status: 'idle' }, session };
}

export const finishTimer = (s: TimerState, now: number) => close(s, now, 'completed');
export const cancelTimer = (s: TimerState, now: number) => close(s, now, 'cancelled');
