// Regras centralizadas de XP e nível (configuráveis aqui; ver ROADMAP/ARCHITECTURE).
export const XP_PER_MINUTE = 1;
export const MIN_SESSION_MINUTES = 5;
const LEVEL_FACTOR = 60;

export interface SessionForXp {
  id: string;
  status: 'completed' | 'cancelled' | 'interrupted';
  activeMs: number;
}
export interface XpEntry {
  id: string;
  sessionId: string;
  ruleId: string;
  amount: number;
}
export const RULE_SESSION_COMPLETED = 'session-completed-v1';

export function xpForSession(s: SessionForXp): number {
  if (!Number.isFinite(s.activeMs) || s.activeMs < 0) throw new RangeError('Duração inválida.');
  const minutes = Math.floor(s.activeMs / 60_000);
  if (s.status !== 'completed' || minutes < MIN_SESSION_MINUTES) return 0;
  return minutes * XP_PER_MINUTE;
}

// Idempotente: a mesma (sessionId, ruleId) nunca gera dois lançamentos.
export function grantSessionXp(ledger: readonly XpEntry[], s: SessionForXp): readonly XpEntry[] {
  const amount = xpForSession(s);
  const id = `${s.id}:${RULE_SESSION_COMPLETED}`;
  if (amount === 0 || ledger.some((e) => e.id === id)) return ledger;
  return [...ledger, { id, sessionId: s.id, ruleId: RULE_SESSION_COMPLETED, amount }];
}

export const totalXp = (ledger: readonly XpEntry[]): number =>
  ledger.reduce((sum, e) => sum + e.amount, 0);

function assertXp(xp: number): void {
  if (!Number.isFinite(xp) || xp < 0) throw new RangeError('XP inválido.');
}
// XP acumulado necessário para ATINGIR o nível L: 60 × (L−1)².
export const levelThreshold = (level: number): number => {
  if (!Number.isInteger(level) || level < 1) throw new RangeError('Nível inválido.');
  return LEVEL_FACTOR * (level - 1) ** 2;
};

export function levelFromXp(xp: number): number {
  assertXp(xp);
  let level = Math.floor(Math.sqrt(xp / LEVEL_FACTOR)) + 1;
  while (levelThreshold(level + 1) <= xp) level++; // corrige erro de ponto flutuante
  while (level > 1 && levelThreshold(level) > xp) level--;
  return level;
}

export function levelProgress(xp: number) {
  const level = levelFromXp(xp);
  const floor = levelThreshold(level);
  const needed = levelThreshold(level + 1) - floor;
  return { level, intoLevel: xp - floor, needed, fraction: (xp - floor) / needed };
}
