export interface AttributeInput {
  completedSessions: { activeMs: number }[];
  reviewsMastered: number;
  goalsDone: number;
  tasksDone: number;
  longestStreak: number;
}
// Regras transparentes: cada atributo é uma contagem derivada de registros reais (não cresce arbitrariamente).
export const ATTRIBUTE_RULES = [
  {
    id: 'raciocinio',
    name: 'Raciocínio',
    rule: '1 ponto por meta concluída e por trabalho entregue.',
  },
  { id: 'memoria', name: 'Memória', rule: '1 ponto por assunto de revisão marcado como dominado.' },
  {
    id: 'disciplina',
    name: 'Disciplina',
    rule: '1 ponto por dia da sua maior sequência de estudo.',
  },
  {
    id: 'concentracao',
    name: 'Concentração',
    rule: '1 ponto por sessão concluída de 25 minutos ou mais.',
  },
] as const;
export function computeAttributes(
  i: AttributeInput,
): Record<(typeof ATTRIBUTE_RULES)[number]['id'], number> {
  return {
    raciocinio: i.goalsDone + i.tasksDone,
    memoria: i.reviewsMastered,
    disciplina: i.longestStreak,
    concentracao: i.completedSessions.filter((s) => s.activeMs >= 25 * 60_000).length,
  };
}
