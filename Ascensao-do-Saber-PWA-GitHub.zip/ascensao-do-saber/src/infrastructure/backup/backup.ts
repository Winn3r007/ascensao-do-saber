import { grantSessionXp, type XpEntry } from '../../domain/progression/rules';
import { backupSchema, type Backup } from '../../validation/schemas';
import type { Db } from '../db/db';
import { listItems, getProfile } from '../db/items';
import { listSessions, listSubjects } from '../db/repository';

export const MAX_BACKUP_BYTES = 5 * 1024 * 1024;
export class BackupError extends Error {}

export async function exportBackup(db: Db): Promise<string> {
  const data: Backup = {
    format: 'ascensao-do-saber-backup',
    version: 2,
    exportedAt: Date.now(),
    profile: await getProfile(db),
    subjects: await listSubjects(db),
    sessions: await listSessions(db),
    events: await listItems(db, 'events'),
    goals: await listItems(db, 'goals'),
    reviews: await listItems(db, 'reviews'),
    notes: await listItems(db, 'notes'),
  };
  return JSON.stringify(data);
}

// Valida tudo ANTES de tocar no banco. XP e conquistas NÃO vêm do arquivo: são recalculados
// a partir das sessões (impede injetar XP por backup adulterado).
export function parseBackup(text: string): Backup {
  if (new Blob([text]).size > MAX_BACKUP_BYTES)
    throw new BackupError('Arquivo grande demais (máximo 5 MB).');
  let json: unknown;
  try {
    json = JSON.parse(text);
  } catch {
    throw new BackupError('O arquivo não é um JSON válido.');
  }
  const parsed = backupSchema.safeParse(json);
  if (!parsed.success)
    throw new BackupError('Arquivo de backup inválido ou de versão não suportada.');
  const ids = new Set(parsed.data.subjects.map((s) => s.id));
  if (parsed.data.sessions.some((s) => !ids.has(s.subjectId))) {
    throw new BackupError('Backup inconsistente: sessão ligada a matéria inexistente.');
  }
  return parsed.data;
}

const ALL = [
  'subjects',
  'sessions',
  'xpLedger',
  'activeTimer',
  'events',
  'goals',
  'reviews',
  'notes',
  'achievements',
  'profile',
] as const;

export async function importBackup(db: Db, text: string): Promise<void> {
  const b = parseBackup(text);
  const tx = db.transaction([...ALL], 'readwrite');
  for (const name of ALL) await tx.objectStore(name).clear();
  await tx.objectStore('profile').put(b.profile);
  for (const x of b.subjects) await tx.objectStore('subjects').put(x);
  for (const x of b.events) await tx.objectStore('events').put(x);
  for (const x of b.goals) await tx.objectStore('goals').put(x);
  for (const x of b.reviews) await tx.objectStore('reviews').put(x);
  for (const x of b.notes) await tx.objectStore('notes').put(x);
  let ledger: readonly XpEntry[] = [];
  for (const s of b.sessions) {
    await tx.objectStore('sessions').put(s);
    ledger = grantSessionXp(ledger, { id: s.id, status: s.status, activeMs: s.activeMs });
  }
  for (const e of ledger) await tx.objectStore('xpLedger').put(e);
  await tx.done;
}

export async function deleteAllData(db: Db): Promise<void> {
  const tx = db.transaction([...ALL], 'readwrite');
  for (const name of ALL) await tx.objectStore(name).clear();
  await tx.done;
}
