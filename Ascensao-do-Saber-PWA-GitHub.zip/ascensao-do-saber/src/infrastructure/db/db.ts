import { openDB, type DBSchema, type IDBPDatabase } from 'idb';
import type {
  AchievementRow,
  ActiveTimer,
  AppEvent,
  Goal,
  Note,
  Profile,
  Review,
  Session,
  Subject,
  XpRow,
} from '../../validation/schemas';

interface AppSchema extends DBSchema {
  subjects: { key: string; value: Subject };
  sessions: { key: string; value: Session; indexes: { bySubject: string } };
  xpLedger: { key: string; value: XpRow };
  activeTimer: { key: string; value: ActiveTimer };
  events: { key: string; value: AppEvent };
  goals: { key: string; value: Goal };
  reviews: { key: string; value: Review };
  notes: { key: string; value: Note };
  achievements: { key: string; value: AchievementRow };
  profile: { key: string; value: Profile };
}
export type Db = IDBPDatabase<AppSchema>;
export const DB_VERSION = 2;

// Migrações: acrescente um bloco `if (oldVersion < N)` por versão, nunca altere os antigos.
export const openAppDb = (name = 'ascensao-do-saber'): Promise<Db> =>
  openDB<AppSchema>(name, DB_VERSION, {
    upgrade(db, oldVersion) {
      if (oldVersion < 1) {
        db.createObjectStore('subjects', { keyPath: 'id' });
        const sessions = db.createObjectStore('sessions', { keyPath: 'id' });
        sessions.createIndex('bySubject', 'subjectId');
        db.createObjectStore('xpLedger', { keyPath: 'id' });
        db.createObjectStore('activeTimer', { keyPath: 'key' });
      }
      if (oldVersion < 2) {
        for (const name of ['events', 'goals', 'reviews', 'notes', 'achievements'] as const) {
          db.createObjectStore(name, { keyPath: 'id' });
        }
        db.createObjectStore('profile', { keyPath: 'key' });
      }
    },
  });
