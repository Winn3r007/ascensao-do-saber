import type { z } from 'zod';
import { grantSessionXp } from '../../domain/progression/rules';
import type { FinishedSession, TimerState } from '../../domain/timer/timer';
import {
  activeTimerSchema,
  sessionSchema,
  subjectInputSchema,
  subjectSchema,
  xpEntrySchema,
  type Session,
  type Subject,
} from '../../validation/schemas';
import type { Db } from './db';

export class CorruptDataError extends Error {
  constructor(readonly store: string) {
    super(`Dados corrompidos no armazenamento "${store}".`); // sem vazar o conteúdo
    this.name = 'CorruptDataError';
  }
}

function parseAll<T>(store: string, schema: z.ZodType<T>, rows: unknown[]): T[] {
  return rows.map((row) => {
    const parsed = schema.safeParse(row);
    if (!parsed.success) throw new CorruptDataError(store);
    return parsed.data;
  });
}

export async function addSubject(db: Db, input: { name: string; color: string }): Promise<Subject> {
  const data = subjectInputSchema.parse(input);
  const subject = subjectSchema.parse({ ...data, id: crypto.randomUUID(), createdAt: Date.now() });
  await db.add('subjects', subject);
  return subject;
}

export async function listSubjects(db: Db): Promise<Subject[]> {
  const rows: unknown[] = await db.getAll('subjects');
  return parseAll('subjects', subjectSchema, rows);
}

export async function renameSubject(db: Db, id: string, input: { name: string; color: string }) {
  const data = subjectInputSchema.parse(input);
  const tx = db.transaction('subjects', 'readwrite');
  const current: unknown = await tx.store.get(id);
  if (current === undefined) throw new Error('Matéria não encontrada.');
  const [subject] = parseAll('subjects', subjectSchema, [current]);
  await tx.store.put(subjectSchema.parse({ ...subject, ...data }));
  await tx.done;
}

// Política: matéria com sessões registradas não pode ser excluída (preserva histórico e estatísticas).
export async function deleteSubject(db: Db, id: string): Promise<void> {
  const tx = db.transaction(['subjects', 'sessions'], 'readwrite');
  if ((await tx.objectStore('sessions').index('bySubject').count(id)) > 0) {
    throw new Error('Matéria possui sessões registradas e não pode ser excluída.');
  }
  await tx.objectStore('subjects').delete(id);
  await tx.done;
}

export async function saveActiveTimer(
  db: Db,
  subjectId: string,
  state: TimerState,
  targetMs?: number,
  topic?: string,
) {
  if (state.status === 'idle') throw new Error('Não há estado ativo para salvar.');
  await db.put(
    'activeTimer',
    activeTimerSchema.parse({
      key: 'current',
      subjectId,
      state,
      ...(targetMs === undefined ? {} : { targetMs }),
      ...(topic ? { topic } : {}),
    }),
  );
}

export async function loadActiveTimer(db: Db) {
  const row: unknown = await db.get('activeTimer', 'current');
  return row === undefined ? null : (parseAll('activeTimer', activeTimerSchema, [row])[0] ?? null);
}

// Atômico: sessão + XP + limpeza do cronômetro numa só transação. Idempotente pelo id da sessão.
export async function finalizeSession(
  db: Db,
  subjectId: string,
  finished: FinishedSession,
  interrupted = false,
  topic?: string,
): Promise<{ session: Session; duplicate: boolean }> {
  const status = interrupted ? 'interrupted' : finished.outcome;
  const session = sessionSchema.parse({
    id: `s-${String(finished.startedAt)}-${subjectId}`,
    subjectId,
    startedAt: finished.startedAt,
    endedAt: finished.endedAt,
    activeMs: finished.activeMs,
    status,
    ...(topic ? { topic } : {}),
  });
  const tx = db.transaction(['subjects', 'sessions', 'xpLedger', 'activeTimer'], 'readwrite');
  if ((await tx.objectStore('subjects').get(subjectId)) === undefined) {
    throw new Error('Matéria não encontrada.');
  }
  const existing: unknown = await tx.objectStore('sessions').get(session.id);
  if (existing !== undefined) {
    await tx.done;
    return {
      session: parseAll('sessions', sessionSchema, [existing])[0] ?? session,
      duplicate: true,
    };
  }
  await tx.objectStore('sessions').put(session);
  const rows: unknown[] = await tx.objectStore('xpLedger').getAll();
  const ledger = parseAll('xpLedger', xpEntrySchema, rows);
  const next = grantSessionXp(ledger, { id: session.id, status, activeMs: session.activeMs });
  const added = next[next.length - 1];
  if (next.length > ledger.length && added)
    await tx.objectStore('xpLedger').put(xpEntrySchema.parse(added));
  await tx.objectStore('activeTimer').delete('current');
  await tx.done;
  return { session, duplicate: false };
}

export async function totalXpStored(db: Db): Promise<number> {
  const rows: unknown[] = await db.getAll('xpLedger');
  return parseAll('xpLedger', xpEntrySchema, rows).reduce((s, e) => s + e.amount, 0);
}

export async function listSessions(db: Db): Promise<Session[]> {
  const rows: unknown[] = await db.getAll('sessions');
  return parseAll('sessions', sessionSchema, rows);
}
