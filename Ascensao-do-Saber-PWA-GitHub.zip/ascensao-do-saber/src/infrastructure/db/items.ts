import type { IDBPDatabase } from 'idb';
import type { z } from 'zod';
import {
  DEFAULT_PROFILE,
  achievementRowSchema,
  eventSchema,
  goalSchema,
  noteSchema,
  profileSchema,
  reviewSchema,
  type AchievementRow,
  type Profile,
} from '../../validation/schemas';
import type { Db } from './db';
import { CorruptDataError } from './repository';

const SCHEMAS = {
  events: eventSchema,
  goals: goalSchema,
  reviews: reviewSchema,
  notes: noteSchema,
} as const;
export type ItemStore = keyof typeof SCHEMAS;
type Item<S extends ItemStore> = z.infer<(typeof SCHEMAS)[S]>;
const raw = (db: Db) => db as unknown as IDBPDatabase;

export const newId = (): string => crypto.randomUUID();

export async function listItems<S extends ItemStore>(db: Db, store: S): Promise<Item<S>[]> {
  const rows: unknown[] = await raw(db).getAll(store);
  return rows.map((r) => {
    const p = SCHEMAS[store].safeParse(r);
    if (!p.success) throw new CorruptDataError(store);
    return p.data as Item<S>;
  });
}
// Valida na fronteira antes de gravar (cria ou atualiza).
export async function putItem(db: Db, store: ItemStore, value: unknown): Promise<void> {
  await raw(db).put(store, SCHEMAS[store].parse(value));
}
export async function removeItem(db: Db, store: ItemStore, id: string): Promise<void> {
  await raw(db).delete(store, id);
}

export async function getProfile(db: Db): Promise<Profile> {
  const row: unknown = await db.get('profile', 'profile');
  if (row === undefined) return { ...DEFAULT_PROFILE };
  const p = profileSchema.safeParse(row);
  if (!p.success) throw new CorruptDataError('profile');
  return p.data;
}
export async function saveProfile(db: Db, value: unknown): Promise<void> {
  await db.put('profile', profileSchema.parse(value));
}

export async function listAchievements(db: Db): Promise<AchievementRow[]> {
  const rows: unknown[] = await db.getAll('achievements');
  return rows.map((r) => {
    const p = achievementRowSchema.safeParse(r);
    if (!p.success) throw new CorruptDataError('achievements');
    return p.data;
  });
}
// Registro permanente e sem duplicação: só grava se ainda não existir.
export async function unlockAchievements(db: Db, ids: string[], now: number): Promise<void> {
  const tx = db.transaction('achievements', 'readwrite');
  for (const id of ids) {
    if ((await tx.store.get(id)) === undefined)
      await tx.store.put(achievementRowSchema.parse({ id, unlockedAt: now }));
  }
  await tx.done;
}
