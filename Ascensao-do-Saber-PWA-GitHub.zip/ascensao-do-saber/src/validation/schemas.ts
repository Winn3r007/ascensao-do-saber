import { z } from 'zod';

const id = z.string().min(1).max(64);
const ts = z.number().int().nonnegative();

export const subjectSchema = z.strictObject({
  id,
  name: z.string().trim().min(1).max(60),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  createdAt: ts,
});
export const subjectInputSchema = subjectSchema.pick({ name: true, color: true });
export const sessionSchema = z.strictObject({
  id,
  subjectId: id,
  startedAt: ts,
  endedAt: ts,
  activeMs: ts,
  status: z.enum(['completed', 'cancelled', 'interrupted']),
  topic: z.string().trim().min(1).max(80).optional(),
});
// id do lançamento = `${sessionId}:${ruleId}` (até 64 + 1 + 64 caracteres)
export const xpEntrySchema = z.strictObject({
  id: z.string().min(1).max(129),
  sessionId: id,
  ruleId: id,
  amount: ts,
});
export const activeTimerSchema = z.strictObject({
  key: z.literal('current'),
  subjectId: id,
  targetMs: ts.optional(),
  topic: z.string().trim().min(1).max(80).optional(),
  state: z.discriminatedUnion('status', [
    z.strictObject({
      status: z.literal('running'),
      startedAt: ts,
      accumulatedMs: ts,
      runningSince: ts,
    }),
    z.strictObject({ status: z.literal('paused'), startedAt: ts, accumulatedMs: ts }),
  ]),
});

export type Subject = z.infer<typeof subjectSchema>;
export type Session = z.infer<typeof sessionSchema>;
export type XpRow = z.infer<typeof xpEntrySchema>;
export type ActiveTimer = z.infer<typeof activeTimerSchema>;

const day = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
const text = (n: number) => z.string().trim().min(1).max(n);
const color = z.string().regex(/^#[0-9a-fA-F]{6}$/);
export const eventSchema = z.strictObject({
  id,
  kind: z.enum(['compromisso', 'prova', 'trabalho', 'lembrete']),
  title: text(100),
  subjectId: id.optional(),
  date: day,
  time: z
    .string()
    .regex(/^\d{2}:\d{2}$/)
    .optional(),
  content: z.string().max(1000).optional(),
  done: z.boolean(),
});
export const goalSchema = z.strictObject({
  id,
  title: text(100),
  metric: z.enum(['minutes', 'sessions']),
  target: z.number().int().positive().max(1_000_000),
  deadline: day,
  subjectId: id.optional(),
  createdAt: ts,
});
export const reviewSchema = z.strictObject({
  id,
  topic: text(100),
  subjectId: id.optional(),
  state: z.enum(['precisa_revisar', 'estudando', 'dominado']),
});
export const noteSchema = z.strictObject({
  id,
  title: text(100),
  text: z.string().max(5000),
  color,
  subjectId: id.optional(),
  createdAt: ts,
});
export const achievementRowSchema = z.strictObject({ id, unlockedAt: ts });
export const profileSchema = z.strictObject({
  key: z.literal('profile'),
  characterName: text(30),
  pomodoroMinutes: z.number().int().min(1).max(180),
  alerts: z.boolean().optional(),
});
export const DEFAULT_PROFILE = {
  key: 'profile',
  characterName: 'Aprendiz',
  pomodoroMinutes: 25,
} as const;
export const backupSchema = z.strictObject({
  format: z.literal('ascensao-do-saber-backup'),
  version: z.literal(2),
  exportedAt: ts,
  profile: profileSchema,
  subjects: z.array(subjectSchema).max(500),
  sessions: z.array(sessionSchema).max(100_000),
  events: z.array(eventSchema).max(10_000),
  goals: z.array(goalSchema).max(5_000),
  reviews: z.array(reviewSchema).max(10_000),
  notes: z.array(noteSchema).max(10_000),
});
export type AppEvent = z.infer<typeof eventSchema>;
export type Goal = z.infer<typeof goalSchema>;
export type Review = z.infer<typeof reviewSchema>;
export type Note = z.infer<typeof noteSchema>;
export type Profile = z.infer<typeof profileSchema>;
export type AchievementRow = z.infer<typeof achievementRowSchema>;
export type Backup = z.infer<typeof backupSchema>;
