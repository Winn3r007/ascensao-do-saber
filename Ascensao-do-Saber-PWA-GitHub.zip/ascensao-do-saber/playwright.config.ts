import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: 'tests/e2e',
  fullyParallel: true,
  retries: 0,
  reporter: [['list']],
  use: {
    baseURL: 'http://127.0.0.1:4173',
    trace: 'retain-on-failure',
    // Opcional: aponta para um Chromium já instalado (útil quando a revisão baixada pelo
    // Playwright não está disponível). Sem a variável, usa o navegador padrão do Playwright.
    ...(process.env['PW_CHROMIUM_PATH']
      ? { launchOptions: { executablePath: process.env['PW_CHROMIUM_PATH'] } }
      : {}),
  },
  // Os testes E2E rodam contra o BUILD DE PRODUÇÃO (CSP estrita), não contra o servidor de dev.
  webServer: {
    command: 'npm run build && npm run preview',
    url: 'http://127.0.0.1:4173',
    reuseExistingServer: false,
    timeout: 120_000,
  },
  projects: [
    { name: 'desktop', use: { ...devices['Desktop Chrome'] } },
    { name: 'mobile', use: { ...devices['Pixel 7'] } },
  ],
});
