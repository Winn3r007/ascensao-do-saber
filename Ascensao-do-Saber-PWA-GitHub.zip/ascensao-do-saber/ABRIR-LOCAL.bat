@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js nao encontrado. Instale Node.js 22.19 ou superior em https://nodejs.org/ && pause && exit /b 1)
where npm >nul 2>nul || (echo npm nao encontrado. Reinstale o Node.js incluindo npm. && pause && exit /b 1)
echo Instalando dependencias (primeira execucao)...
call npm ci
if errorlevel 1 (echo Falha ao instalar dependencias. Verifique a conexao e a versao do Node.js. & pause & exit /b 1)
echo Abrindo Ascensao do Saber...
start "Ascensao do Saber" cmd /k "npm run dev -- --host 127.0.0.1"
timeout /t 3 >nul
start http://127.0.0.1:5173
